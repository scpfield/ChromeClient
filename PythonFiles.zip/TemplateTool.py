import sys, os, json, re

SectionSearchMap        = None
GroupSearchMap          = None
SectionFieldSearchMap   = None
GroupFieldSearchMap     = None
DataEditMap             = None
ActionType              = ""
InputFile               = ""
OutputFile              = ""


def FindObjects(ObjectList, SearchExprList):

    #print("FindObjects - Searching for: " + str(SearchExprList))
    #print(ObjectList)
    
    FoundObjects = []
    #print("Count of ObjectDict in ObjectList: " + str(len(ObjectList)))
    
    for ObjectDict in ObjectList:
        Found = False
        for SearchKey, SearchValue in SearchExprList.items():
            if SearchKey in ObjectDict:
                #print("SearchKey: " + str(SearchKey) + " was found in the target ObjectDict")
                #print("Searching ObjDict value: " + str(ObjectDict[SearchKey]) + " using search term: " + str(SearchValue))
                SearchResult = re.search(   str(SearchValue), 
                                            str(ObjectDict[SearchKey]), 
                                            flags=(re.IGNORECASE + re.ASCII + re.MULTILINE))

                if (SearchResult):
                    #print("Found match")
                    Found = True
                    continue
                else:
                    #print("Did not find match")
                    Found = False
                    break
            else:
                #print("SearchKey: " + SearchKey + " not found in the target ObjectDict")
                Found = False
                
        if (Found):
            #print("Adding found item to return list")
            FoundObjects.append(ObjectDict)
            
    return(FoundObjects)
   
#end

def ProcessTemplate():

    global SectionSearchMap
    global GroupSearchMap
    global FieldSearchMap
    global DataEditMap
    global ActionType
    global OutputFile
    global InputFile
        
    with open(InputFile, 'r', newline='', encoding='utf-8') as JSONFile:
        JSONData = json.load(JSONFile)
        if (not JSONData):
            print("Failed to load input file: " + InputFile)
        JSONFile.flush()
        JSONFile.close()    

    AllSections = []
    AllGroups = []
    FoundSections = []
    FoundGroups = []
    FoundSectionFields = []
    FoundGroupFields = []
    
    FoundSectionCount = 0
    FoundGroupCount = 0
    FoundSectionFieldCount = 0
    FoundGroupFieldCount = 0
    
    EditedSectionCount = 0
    EditedGroupCount = 0
    EditedSectionFieldCount = 0
    EditedGroupFieldCount = 0
    
    DeletedSectionCount = 0
    DeletedGroupCount = 0
    DeletedSectionFieldCount = 0
    DeletedGroupFieldCount = 0
    
    GroupFieldType = { 'isGroup' : 'True' }
    SectionFieldType = { 'fieldGroupName' : None }  
    
    # Keep list of all sections
    AllSections = JSONData['sections']

    # Keep a lookup list of all the groups
    if (AllSections):
        for Section in AllSections:
            if 'fields' in Section:
                FieldList = Section['fields']
                AllGroups.extend(FindObjects(FieldList, GroupFieldType))


    # Search for Sections
    if (SectionSearchMap):
        FoundSections.extend(FindObjects(AllSections, SectionSearchMap))
       
    # Search for Field Groups
    # In all sections or only the ones matching user criteria
    if (GroupSearchMap):
        SectionSearchList = FoundSections if SectionSearchMap else AllSections
        for Section in SectionSearchList:
            if 'fields' in Section:
                FieldList = Section['fields']
                SectionGroups = FindObjects(FieldList, GroupFieldType)
                FoundGroups.extend(FindObjects(SectionGroups, GroupSearchMap))


    # Search for Fields in Sections
    # In all sections or only the ones matching user criteria
    if (SectionFieldSearchMap):
        SectionSearchList = FoundSections if SectionSearchMap else AllSections
        for Section in SectionSearchList:
            if 'fields' in Section:
                FieldList = Section['fields']
                SectionFields = FindObjects( FieldList, SectionFieldType )
                FoundSectionFields.extend(FindObjects(SectionFields, SectionFieldSearchMap ))
                 

    # Search for Fields in Groups
    # In all sections+groups or only the ones matching user criteria
    if (GroupFieldSearchMap):
        SectionSearchList = FoundSections if SectionSearchMap else AllSections
        GroupSearchList = FoundGroups if GroupSearchMap else AllGroups
        for Section in SectionSearchList:
            if 'fields' in Section:
                FieldList = Section['fields']
                SectionGroups = FindObjects(FieldList, GroupFieldType)
                for Group in SectionGroups:
                    if Group in GroupSearchList:
                        GroupFields = Group['groupFields']
                        FoundGroupFields.extend(FindObjects(GroupFields, GroupFieldSearchMap ))
                                  

    
    # Perform actions on Sections
    if  ((SectionSearchMap) and 
        (not GroupSearchMap) and 
        (not SectionFieldSearchMap) and 
        (not GroupFieldSearchMap)):
            for Section in FoundSections:
                print(  "[" + ActionType + "] " +
                        "section=" + '"' + str(Section['title']) + '"' + ", " + 
                        "sectionKey=" + '"' + str(Section['sectionKey'] + '"'))
                match (ActionType):
                    case 'find':
                        FoundSectionCount += 1
                    case 'delete':                       
                        AllSections.remove(Section)
                        DeletedSectionCount += 1
                    case 'edit':
                        for EditKey, EditValue in DataEditMap.items():
                            if (EditKey in Section):
                                Section[EditKey] = EditValue
                                EditedSectionCount += 1                        
                        
                        
    # Perform actions on Section Fields
    if  (SectionFieldSearchMap):
            SectionSearchList = FoundSections if SectionSearchMap else AllSections
            for SectionField in FoundSectionFields:
                for Section in SectionSearchList:
                    if SectionField in Section['fields']:
                        print(  "[" + ActionType + "] " +
                                "section=" + '"' + str(Section['title']) + '"' + ", " +
                                "field=" + '"' + str(SectionField['displayName']) + '"')
                        match (ActionType):
                            case 'find':
                                FoundSectionFieldCount += 1
                            case 'delete':                        
                                Section['fields'].remove(SectionField)
                                DeletedSectionFieldCount += 1
                            case 'edit':
                                for EditKey, EditValue in DataEditMap.items():
                                    if (EditKey in Group):
                                        SectionField[EditKey] = EditValue
                                        EditedSectionFieldCount += 1


    # Perform actions on Groups
    if  ((GroupSearchMap) and
        (not GroupFieldSearchMap)):
            SectionSearchList = FoundSections if SectionSearchMap else AllSections
            for Section in SectionSearchList:
                for Group in FoundGroups:
                    if Group in Section['fields']:
                        print(  "[" + ActionType + "] " +
                                "section=" + '"' + str(Section["title"]) + '"' + ", " +
                                "group=" + '"' + str(Group["name"]) + '"')
                        match (ActionType):
                            case 'find':
                                FoundGroupCount += 1
                            case 'delete':                        
                                Section['fields'].remove(Group)
                                DeletedGroupCount += 1
                            case 'edit':
                                for EditKey, EditValue in DataEditMap.items():
                                    if (EditKey in Group):
                                        Group[EditKey] = EditValue
                                        EditedGroupCount += 1
                                
                                
    # Perform actions on Group Fields
    if (GroupFieldSearchMap):
        SectionSearchList = FoundSections if SectionSearchMap else AllSections
        GroupSearchList = FoundGroups if GroupSearchMap else AllGroups
        for Section in SectionSearchList:
            for Group in GroupSearchList:
                if Group in Section['fields']:
                    GroupFields = Group['groupFields']
                    for FoundGroupField in FoundGroupFields:
                        if FoundGroupField in GroupFields:
                            print(  "[" + ActionType + "] " +
                                "section=" + '"' + str(Section['title']) + '"' + ", " +
                                "group=" + '"' + str(Group['name']) + '"' + ", " +
                                "groupfield=" + '"' + str(FoundGroupField['displayName']) + '"')
                            match (ActionType):
                                case 'find':
                                    FoundGroupFieldCount += 1
                                case 'delete':                        
                                    Group['groupFields'].remove(FoundGroupField)
                                    DeletedGroupFieldCount += 1
                                case 'edit':
                                    for EditKey, EditValue in DataEditMap.items():
                                        if (EditKey in FoundGroupField):
                                            FoundGroupField[EditKey] = EditValue
                                            EditedGroupFieldCount += 1


    print("")
    
    if (ActionType == 'find'):
        if (FoundSectionCount > 0):
            print(str(FoundSectionCount) + " sections found")
        if (FoundGroupCount > 0):
            print(str(FoundGroupCount) + " groups found")
        if (FoundSectionFieldCount > 0):
            print(str(FoundSectionFieldCount) + " section fields found")
        if (FoundGroupFieldCount > 0):
            print(str(FoundGroupFieldCount) + " group fields found")            
    
    if (ActionType == 'delete'):
        if (DeletedSectionCount > 0):
            print(str(DeletedSectionCount) + " sections deleted")
        if (DeletedGroupCount > 0):
            print(str(DeletedGroupCount) + " groups deleted")
        if (DeletedSectionFieldCount > 0):
            print(str(DeletedSectionFieldCount) + " section fields deleted")
        if (DeletedGroupFieldCount > 0):
            print(str(DeletedGroupFieldCount) + " group fields deleted")            
        
    if (ActionType == 'edit'):
        if (EditedSectionCount > 0):
            print(str(EditedSectionCount) + " sections edited")
        if (EditedGroupCount > 0):
            print(str(EditedGroupCount) + " groups edited")
        if (EditedSectionFieldCount > 0):
            print(str(EditedSectionFieldCount) + " section fields edited")
        if (EditedGroupFieldCount > 0):
            print(str(EditedGroupFieldCount) + " group fields edited")


    if os.path.exists(OutputFile):
        os.remove(OutputFile)
        
    if (ActionType in ['edit','delete']):
        with open(OutputFile, 'w+', newline='', encoding='utf-8') as OutputJSONFile:
            print("Writing output file: " + OutputFile)
            OutputJSONData = json.dumps(JSONData, indent=2)
            OutputJSONFile.write(OutputJSONData)
            OutputJSONFile.flush()
            OutputJSONFile.close()



def ParseArgs():

    if (len(sys.argv) < 5):
        print("Fewer arguments provided than required")
        exit()

    global InputFile
    global OutputFile
    global ActionType
    InputFile = sys.argv[1]
    OutputFile = sys.argv[2]
    ActionType = sys.argv[3]    
    
    if (not os.path.exists(InputFile)):
        print("")
        print("Input file does not exist")
        print("")
        exit()
        
    if (ActionType not in ['find','edit','delete']):
        print("")
        print("Action must be find, edit, or delete")
        print("")
        exit()

    StartIndex = 4
    MaxIndex = ( len( sys.argv ) - 1 )
    
    for Index in range(StartIndex, MaxIndex):
        Arg         = sys.argv[Index]
        Map         = None
        match Arg:
            case '--sections':
                global SectionSearchMap
                SectionSearchMap = {}
                Map = SectionSearchMap
            case '--groups':
                global GroupSearchMap
                GroupSearchMap = {}
                Map = GroupSearchMap
            case '--sectionfields': 
                global SectionFieldSearchMap
                SectionFieldSearchMap = {}
                Map = SectionFieldSearchMap
            case '--groupfields': 
                global GroupFieldSearchMap
                GroupFieldSearchMap = {}
                Map = GroupFieldSearchMap
            case '--data':
                global DataEditMap
                DataEditMap = {}
                Map = DataEditMap
            case _:
                continue
     
        if ( (Index + 1) > MaxIndex ):
            print("")
            print("Insufficient number of arguments provided")
            print("")
            exit()

        ArgValue = sys.argv[Index + 1]

        if (ArgValue.startswith("--")):
            print("")
            print("Invalid argument value")
            print("")
            exit()
    
        for Item in ArgValue.split(','):
            if Item:
                Key = None
                Value = None
                Pair = []
                Pair = Item.split('=')
                if (len(Pair) < 2):
                    Pair = Item.split(':')
                    if (len(Pair) < 2):
                        print("")
                        print("Invalid value for argument: " + ArgValue)
                        print("")
                        exit()
                Key = Pair[0]
                Value = Pair[1]
                #Value = re.escape(Value)
                match Value:
                    case "" | "None" | "null":
                        Value = None
                    case "True" | "true":
                        Value = True
                    case "False" | "false":
                        Value = False
                Map[Key] = Value

            else:
                print("")
                print("Missing value for argument: " + ArgValue)
                print("")
                exit()

    if ((ActionType == 'edit') and (not DataEditMap)):
        print("")
        print("Must provide Data Edit items for edit action")
        print("")
        exit()
# end


ParseArgs()

print("")
print("Arguments:")
print("----------")
print("Input File           : " + InputFile)
print("Output File          : " + OutputFile)
print("Action Type          : " + ActionType)
print("Section Filter       : " + str(SectionSearchMap))
print("Group Filter         : " + str(GroupSearchMap))
print("Section Field Filter : " + str(SectionFieldSearchMap))
print("Group Field Filter   : " + str(GroupFieldSearchMap))
print("Edit Data            : " + str(DataEditMap))
print("")

ProcessTemplate()




