import sys, os, copy
from util import *


MyList = [ 'Sc\n\nript', 'Global' ]

MyStr = "abc\nasdf\nsadf\n"

print( f'{MyList.replace("\\n","").strip()}' )



