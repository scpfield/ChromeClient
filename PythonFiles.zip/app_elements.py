import sys, io, time, random, json, copy, gc, linecache, inspect
from more_itertools import ncycles

import app_config
import apps
import app_pages
from util import *

from    selenium.webdriver.common.devtools.v110 import *
import  selenium.webdriver
from    selenium.webdriver.common.keys import Keys
from    selenium.webdriver.common.action_chains import ActionChains
from    selenium.webdriver.common.actions import interaction
from    selenium.webdriver.common.actions.action_builder import ActionBuilder
from    selenium.webdriver.common.actions.mouse_button import MouseButton
from    selenium.webdriver.common.actions.pointer_input import PointerInput
from    selenium.webdriver.common.actions.key_input import KeyInput
from    selenium.webdriver.common.actions.wheel_input import WheelInput
from    selenium.webdriver.common.keys import *
from    selenium.webdriver.remote.command import *
from    selenium.webdriver.common.by import By
from    selenium.webdriver.support.expected_conditions import *
from    selenium.common.exceptions import *
from    selenium.webdriver.support.wait import WebDriverWait
from    selenium.webdriver.remote.webelement import WebElement
import  appium.webdriver
from    appium.webdriver.webelement import WebElement

AndroidAttributeNames = [
    'resource-id', 'name', 'text', 'original-text', 
    'class', 'package', 'displayed', 'checkable', 
    'checked', 'clickable', 'content-desc', 'enabled', 
    'focusable', 'focused', 'longClickable', 'password', 
    'scrollable', 'selection-start', 'selection-end', 
    'selected', 'hint', 'extras', 'bounds' ]

AndroidPropertyNames = [
    'id', 'location', 'size', 'accessible_name',
    'aria_role', 'tag_name', 'shadow_root' ]
  

class NoIterListsException(Exception):
    ...
  
class AppElement():

    def __init__( self, *args, **kwargs ):
            
            
        for Arg, ArgValue in kwargs.items():
            if Arg == 'Attributes' and ArgValue:
                for Key, Value in ArgValue.items():
                    #print("Setting Arg: " + Key)
                    setattr(self, Key, Value)
                    #FixedKey = str(Key.replace('-','_'))
                    #setattr(self, FixedKey, Value)
            else:
                setattr(self, Arg, ArgValue)

        self.IterLists = []
        self.InitializeW3CActions()
        ...
   
    def __copy__( self ):
            
        CopyObj      = type( self )(
          Name       = copy.copy(self.Name),
          Tag        = copy.copy(self.Tag),
          Text       = copy.copy(self.Text),
          Tail       = copy.copy(self.Tail),
          Attributes = copy.copy(self.Attributes),
          ObjPath    = copy.copy(self.ObjPath),
          XPath      = copy.copy(self.XPath),
          Selector   = copy.copy(self.Selector),
          Locator    = copy.copy(self.Locator),
          Instance   = None )
 
        if 'Parent' in self.__dict__:
            setattr( CopyObj, 'Parent', self.Parent )
            
        #if 'Parent' in self.__dict__:
        #    setattr( CopyObj, 'Parent', copy.copy( self.Parent ))
            
        for ChildObj in self:
            setattr( CopyObj, ChildObj.Name, ChildObj )
        
        return CopyObj
        ...


    # method for 
    def Ancestors( self, MaxHeight = None ):
       
        # sub-function for traversal of object tree
        # using this instance as the starting point
        # the reason is to flatten a tree into a list
        
        def TraverseNodes( CurrentNode = None, NodeList = None, Height = None ):
            
            if CurrentNode   == None: CurrentNode   = self
            if NodeList      == None: NodeList      = []
            if Height        == None: Height         = 0
            if Height > 0:   NodeList.append( CurrentNode )
            
            if hasattr(CurrentNode, 'Parent'):
                ParentNode = CurrentNode.Parent
                if ParentNode:
                    if ( MaxHeight != None ) and ( Height > MaxHeight ):
                        ...
                    else:
                        TraverseNodes(  ParentNode, NodeList, ( Height + 1) )

        # end of TraverseNodes sub-function
        
        # perform upward recursion to find parent nodes
        # of this node in the tree and add them to a list
        AncestorList = []
        TraverseNodes( self, AncestorList )
        
        # make a new dictionary with the data
        NewListEntry = {}
        NewListEntry['StackHash']   = hash(Stack(Print = False))
        NewListEntry['ListData']    = AncestorList
        NewListEntry['ListPtr']     = 0
        
        # add to the list of the lists
        # of lists that callers are iterating upon
        self.IterLists.append(NewListEntry)
        return self
        ...

    def Descendants( self, MaxDepth = None ):
       
        # sub-function for traversal of object tree
        # using this instance as the starting point
        # the reason is to flatten a tree into a list
        
        def TraverseNodes( CurrentNode = None, NodeList = None, Depth = None ):
            
            if CurrentNode   == None: CurrentNode   = self
            if NodeList      == None: NodeList      = []
            if Depth         == None: Depth         = 0
            if Depth > 0:    NodeList.append( CurrentNode )
            
            for Key in CurrentNode.__dict__:
                if isinstance( CurrentNode.__dict__[Key], AppElement ):
                    if Key != 'Parent':
                        if ( MaxDepth != None ) and ( Depth > MaxDepth ):
                            continue
                        ChildNode = CurrentNode.__dict__[Key]
                        TraverseNodes(  ChildNode, NodeList, ( Depth + 1) )

        # end of TraverseNodes sub-function
        
        # perform downward recursion to find child nodes
        # of this node in the tree and add them to a list
        DescendantList = []
        TraverseNodes( self, DescendantList )
            
        # make a new dictionary with the data
        NewListEntry = {}
        NewListEntry['StackHash']   = hash(Stack(Print = False))
        NewListEntry['ListData']    = DescendantList
        NewListEntry['ListPtr']     = 0

        # add to a book-keeping list of the lists
        # that callers are iterating upon
        self.IterLists.append(NewListEntry)
        return self
        ...

        
    def __call__(self, MyMethod):
        return MyMethod()
        
    #  __iter__ is called by python once at the beginning
    #  of a 'for / in' loop for any initialization.
    #  we don't have any, so just return ourself
    def __iter__(self):        
        if len( self.IterLists ) == 0:
            raise NoIterListsException
        return self    

    # __next__ is called by python for each iteration
    # of a 'for / in' loop
    # we don't remove items in any given data list
    # during an iteration of it, only at the end 
    # we remove the whole list from our list of lists
    def __next__(self):
        if len( self.IterLists ) > 0:
            ListEntry   = self.IterLists[ -1 ]
            ListPtr     = ListEntry.get( 'ListPtr' )
            ListData    = ListEntry.get( 'ListData' )
            if  ListPtr > ( len( ListData ) - 1 ):
                self.IterLists.pop()
                raise StopIteration
            else:
                Value = ListData[ ListPtr ]
                ListEntry[ 'ListPtr' ] += 1
                return Value
        else: raise StopIteration
        ...
        
    # __len__ is called by python when using len()
    # it returns the length of the current data list    
    def __len__( self ):
        if len( self.IterLists ) > 0:
            ListEntry   = self.IterLists[ -1 ]
            ListData    = ListEntry.get( 'ListData' )
            Value       = len( ListData )
            return Value
        else: return 0
        ...
      
    # __getitem__ is called by python when using 
    # bracket notation to access items in a list by
    # index, or dictionary by key, such as: object[5]
    # weird thing is if this is being called by list
    # comprehension it just keeps incrementing the index
    # until you raise StopIteration
    # also getitem is called when using the "reversed" iterator
    def __getitem__(self, Index):
    
        print("__getitem__: " + str(Index))
        if len( self.IterLists ) > 0:
            ListEntry   = self.IterLists[-1]
            ListData    = ListEntry.get( 'ListData' )
            if Index < ( len( ListData )):
                return ListData[Index]
            else: raise StopIteration
        else: return None
        ...
   
    # this is to implement "if / in" functionality
    def __contains__( self, Arg ):
    
        #print("__contains__: " + str(Arg))
        
        if not Arg: return False
        
        SearchDescendants   = False
        Depth               = 0
        Items               = None
        
        if  isinstance( Arg, tuple ):
            if  len( Arg ) < 2:
                Items = Arg[ 0 ]
            else:
                Items = Arg[ 0 ]
                if      Arg[ 1 ]:
                        SearchDescendants = True
                        Depth             = None
        else: Items = Arg
        
        if  not isinstance( Items, list ):
            Items = [ Items ]
        
        for Item in Items:
        
            # Search for Element objects
            if isinstance( Item, AppElement ):
                Result = ([   
                            Element.ObjPath
                            for Element in self.Descendants( Depth )
                            if  Element == Item 
                          ])
                
                #print(f"{len(Result)} exist in Node / Descendants")
                if     len( Result ) > 0: continue
                else:  return False            

            # Search for Attribute Names using strings
            if isinstance( Item, str ):
                Result = ([   
                            Element.ObjPath
                            for Element in self.Descendants()
                            if ((   not SearchDescendants       )   and
                                (   Item in self.__dict__       ))  
                                or
                                ((  SearchDescendants           )   and
                                ((  Item  in  self.__dict__     )   or
                                 (  Item  in  Element.__dict__  )))
                         ])
                
                # print(f"{len(Result)} exist in Node / Descendants")
                if     len( Result ) > 0: continue
                else:  return False

            # Search for Attributes Names + Values using Dictionary
            if isinstance( Item, dict ):
                
                SearchElements = [ self ]
                
                if SearchDescendants:
                    SearchElements.extend( self.Descendants() )
                    
                for Key, Value in Item.items():

                    Elements = ([   Element 
                                    for  Element in SearchElements
                                    if   Element.__dict__.get(Key) == Value
                                ])
                    
                    if    Elements: SearchElements = Elements
                    else: return False
                        
                    
                #print(f"{len(Elements)} element exists in Node / Descendants")
                
                if     len( Elements ) > 0: continue
                else:  return False
                
                
        return True
        ...
    

    def __lt__( self, Other ):
        
        return ( len(self.ObjPath.split('.')) < 
                 len(Other.ObjPath.split('.')))
        
    def __gt__( self, Other ):
        
        return ( len(self.ObjPath.split('.')) > 
                 len(Other.ObjPath.split('.')))

        
    def __repr__( self ):
        return str( self.__dict__ )
    
    def __bool__( self ):
        return True
        
    def __str__( self ):
        return str( self.__dict__)
    
    def __eq__( self, Other ):
    
        if isinstance( Other, AppElement ):
            if self.ObjPath == Other.ObjPath:
                return True
            else:
                return False
        else:
            return False
        ...
            
    def __hash__( self ):
        return hash( self.ObjPath )
        ...
        
    def InitializeW3CActions( self ):
        ...

    def CreateDriverInstance( self ):
        
        PollFrequencySec = 0.25
        Timeout = 2000
        ConditionFunction = presence_of_element_located

        WaitFor = WebDriverWait(
                    driver = app_config.Driver,
                    timeout = Timeout,
                    poll_frequency = PollFrequencySec,
                    ignored_exceptions = [
                        NoSuchElementException,
                        StaleElementReferenceException ] )
        
        try:
            Instance = WaitFor.until(
                        ConditionFunction(
                            (self.Locator,
                            (self.Selector))))
                
            if ( ( isinstance(
                    Instance, 
                    selenium.webdriver.remote.webelement.WebElement )) or
                 ( isinstance(
                    Instance, 
                    appium.webdriver.webelement.WebElement ))):
                self.Instance = Instance
                return True
            else:
                return False

        except TimeoutException as te:
            print('Exceeded timeout while waiting')
            GetExceptionInfo(te)
            Pause()
            return False
            
        except BaseException as be:
            print('Exception')
            GetExceptionInfo(be)
            Pause()
            return False        
            
        ...

    def ClearW3CActions(self):    
        if hasattr(self, 'KeyInputSource'):
            self.KeyInputSource.clear_actions()
        if hasattr(self, 'WheelInputSource'):
            self.WheelInputSource.clear_actions()
        if hasattr(self, 'TouchInputSource'):
            self.TouchInputSource.clear_actions()
        if hasattr(self, 'PenInputSource'):
            self.PenInputSource.clear_actions()  
        if hasattr(self, 'MouseInputSource'):
            self.MouseInputSource.clear_actions()             
        ...

...  # end of AppElement class


class ScrollableElement():

    SCROLL_RESULT_SCROLLED  = 1
    SCROLL_RESULT_EOL       = 2
    SCROLL_RESULT_ERROR     = 3

    def __init__( self ):
        ...
    
    def ScrollToStart( self, Duration ):
        ...
    
    def ScrollToEnd( self, Duration ):
        ...
    
    def ScrollForward( self, Duration ):
        ...
    
    def ScrollBackward( self, Duration ):
        ...

    def VerifyScroll( self ):
        ...

class FocusableElement():

    def __init__( self ):
        ...
    
    def Hover( self ):
    
        self.ClearW3CActions()
        
        Rect = self.GetBoundingClientRect()
        
        if not Rect:
            print('Rect is bad again')
            return False
            
        Bottom = Rect.get('bottom')
        Height = Rect.get('height')
        Left   = Rect.get('left')
        Right  = Rect.get('right')
        Top    = Rect.get('top')
        Width  = Rect.get('width')
        X      = Rect.get('x')
        Y      = Rect.get('y')
        CenterX = int( ( Width  / 2)  + X )
        CenterY = int( ( Height / 2 ) + Y )
        
        print(f"Rect: {Rect}")
        print(f"move_to: x = {CenterX}, y = {CenterY}")
        
        self.PointerAction.move_to_location(
                            x = CenterX, 
                            y = CenterY, 
                            duration = 50 )
        self.InputActions.perform()
        return True

    def SetFocus( self ):
    
        self.ClearW3CActions()
        
        DTF     = apps.WebApp.DevToolsFunc
        CI      = self.ChromeInfo
        Result  = None
        
        #Result = self.HighlightNode()
        
        Result = self.ScrollIntoView()
        print("ScrollIntoView Result = " + str(Result))
        
        Result  = DTF(  dom.focus, 
                        object_id = self.GetRemoteObjectID().object_id )
        
        print(Result)
        return Result
 
        
    def UnFocus( self ):

        self.ClearW3CActions()

        self.KeyAction.key_down( Keys.TAB )
        self.KeyAction.key_up( Keys.TAB )
        self.KeyAction.pause(0.1)
        self.InputActions.perform()
        
        return True
        ...
        
        
class EditableElement():

    def __init__( self ):
        ...
        
    def SendKeys( self, Text ):    
        self.ClearW3CActions()
        if not self.Instance:
            if not self.CreateDriverInstance():
                return False
        self.Instance.send_keys( Text )
        
        
    def TypeKeys( self, Text):
    
        self.ClearW3CActions()
        
        self.SetFocus()
        
        for Char in Text:
            self.KeyAction.key_down(Char)
            self.KeyAction.key_up(Char)
            self.KeyAction.pause(0.05)
        self.InputActions.perform()
        
        self.UnFocus()
        
        return True
        
        
    def SetValue( self, Value ):
        self.ClearW3CActions()
        Script = ( f"return document.querySelector('{self.Selector}').value = '{Value}');" )
        Result = self.SetAttribute('value', Value) 
        Result = self.RunScript( Script )
        return Result


    def GetValue( self ):
        Script = ( f"return document.querySelector('{self.Selector}').value;" )
        Result = self.RunScript( Script )
        return Result
        
        
        
class ClickableElement():

    def __init__( self, *args, **kwargs ):
        print("CLICKABLE_ELEMENT CONSTRUCTOR") 
        ...
        
    def SeleniumClick( self ):
        
        self.ScrollIntoView()
        if not self.Instance:
            if not self.CreateDriverInstance():
                print("Failed to create Driver Instance")
                return False
            else:
                print("CREATED NEW INSTANCE")
        
        print("Button ID: " + str(self.Instance.id))
        self.Instance.click()

    
    def Click( self ):
        # mousePressed, mouseReleased, mouseMoved, mouseWheel
        
        self.ClearW3CActions()
        
        DTF     = apps.WebApp.DevToolsFunc
        CI      = self.ChromeInfo
        Result  = None
        
        #Result = self.MyHighlightNode()
        Result = self.ScrollIntoView()
        print("ScrollIntoView Result: " + str(Result))
        
        CenterX, CenterY     = self.GetCenterXY()
        BotRightX, BotRightY = self.GetInsideLowerRightXY(
                                    OffsetPixels = 5)
        
        Result  = DTF(  input_.dispatch_mouse_event, 
                type_ = 'mouseMoved',
                timestamp = input_.TimeSinceEpoch(time.time()),
                x = BotRightX,
                y = BotRightY,
                button = input_.MouseButton.NONE,
                buttons = 0,
                click_count = 0,
                pointer_type = 'mouse')

        Result  = DTF(  input_.dispatch_mouse_event, 
                        type_ = 'mousePressed',
                        timestamp = input_.TimeSinceEpoch(time.time()),
                        x = BotRightX,
                        y = BotRightY,
                        button = input_.MouseButton.LEFT,
                        buttons = 1,
                        click_count = 1,
                        pointer_type = 'mouse')
        
        Result  = DTF(  input_.dispatch_mouse_event, 
                        type_ = 'mouseReleased',
                        timestamp = input_.TimeSinceEpoch(time.time()),
                        x = BotRightX,
                        y = BotRightY,
                        button = input_.MouseButton.LEFT,
                        buttons = 1,
                        click_count = 1,
                        pointer_type = 'mouse')                        
        
        print(Result)
        

class MobileElement( AppElement ):

    def __init__( self, *args, **kwargs ):
        super().__init__( *args, **kwargs )
    ...
        
    def InitializeW3CActions( self ):
    
        self.KeyInputSource             =   KeyInput( 
                                                interaction.KEY )
        self.WheelInputSource           =   WheelInput(
                                                interaction.WHEEL)                                                
        self.TouchInputSource           =   PointerInput(
                                                interaction.POINTER_TOUCH, 
                                                RandomString(10) )
        self.PenInputSource             =   PointerInput(
                                                interaction.POINTER_PEN, 
                                                RandomString(10) )                                                
        self.MouseInputSource           =   PointerInput(
                                                interaction.POINTER_MOUSE, 
                                                RandomString(10) )                                            
                                                
        self.PointerInputSource         =   self.MouseInputSource
        self.InputActions               =   ActionChains( app_config.Driver )
        self.InputActions.w3c_actions   =   ActionBuilder(
                                              app_config.Driver,
                                              keyboard = self.KeyInputSource,
                                              wheel    = self.WheelInputSource,
                                              mouse    = self.PointerInputSource )

        self.PointerAction              = self.InputActions.w3c_actions.pointer_action
        self.KeyAction                  = self.InputActions.w3c_actions.key_action
        self.WheelAction                = self.InputActions.w3c_actions.wheel_action

        self.ClearW3CActions()
        
        return True
        ...

...  # end of MobileElement class


class ScrollableAndroidElement( ScrollableElement ):
    
    def __init__( self ):
    
        super().__init__()


    def Initialize( self, IndexParentElement = None, ScrollingChildIDs = None ):

        print("Initializing ScrollableAndroidElement with:")
        print("IndexParentElement: " + IndexParentElement.Name)
        print("ScrollingChildIDs: " + str(ScrollingChildIDs))
        
        self.AssociatedElements                     = app_config.Container()
        self.AssociatedElements.IndexParentElement  = IndexParentElement
        self.AssociatedElements.ScrollingChildIDs   = ScrollingChildIDs
        
        print(self.AssociatedElements.IndexParentElement.Name)
        print(str(self.AssociatedElements.ScrollingChildIDs))
        
        ...


    def ScrollToStart( self, Duration = 250 ):
        
        print('Called')

        while True:

            Result = self.ScrollBackward( Duration )
            
            match Result:
                case ScrollableElement.SCROLL_RESULT_SCROLLED:
                    print('SCROLL_RESULT_SCROLLED')
                case ScrollableElement.SCROLL_RESULT_EOL:
                    print('SCROLL_RESULT_EOL')
                    return True
                case ScrollableElement.SCROLL_RESULT_ERROR:
                    print('SCROLL_RESULT_ERROR')
                    return False
        ...

    def ScrollToEnd( self, Duration = 250 ):
        
        print('Called')
        
        while True:
            
            Result = self.ScrollForward( Duration )           
            
            match Result:
                case ScrollableElement.SCROLL_RESULT_SCROLLED:
                    print('SCROLL_RESULT_SCROLLED')
                case ScrollableElement.SCROLL_RESULT_EOL:
                    print('SCROLL_RESULT_EOL')
                    return True
                case ScrollableElement.SCROLL_RESULT_ERROR:
                    print('SCROLL_RESULT_ERROR')
                    return False
        ...


    def ScrollForward( self, Duration = 250 ):
        
        print('Called') 
        
        StartX   = self.bounds.get('CenterX')
        StartY   = self.bounds.get('Y2')
        EndX     = self.bounds.get('CenterX')
        EndY     = self.bounds.get('Y1') * 0.90
        Result   = None
        # print(f'{StartX}, {StartY}, {EndX}, {EndY}')
        
        try:
        
            self.PointerAction.move_to_location(
                 x = StartX, 
                 y = StartY, 
                 duration = Duration )
            self.PointerAction.pointer_down(
                 duration = 0 )
            self.PointerAction.move_to_location( 
                 x = EndX, 
                 y = EndY, 
                 duration = Duration )
            self.PointerAction.pointer_up()
            self.PointerAction.pause()
            self.InputActions.perform()
            
            return self.VerifyScroll()
                
        except Exception as e:
            GetExceptionInfo(e)
            return False
            
        return True
        ...


    def ScrollBackward( self, Duration = 250 ):
    
        print('Called') 
        
        StartX   = self.bounds.get('CenterX')
        StartY   = self.bounds.get('Y1')
        EndX     = self.bounds.get('CenterX')
        EndY     = self.bounds.get('Y2') * 0.90
        Result   = None
        # print(f'{StartX}, {StartY}, {EndX}, {EndY}')
        
        try:
        
            self.PointerAction.move_to_location(
                 x = StartX, 
                 y = StartY, 
                 duration = Duration )
            self.PointerAction.pointer_down(
                 duration = 0 )
            self.PointerAction.move_to_location( 
                 x = EndX, 
                 y = EndY, 
                 duration = Duration )
            self.PointerAction.pointer_up()
            self.PointerAction.pause()
            self.InputActions.perform()
            
            return self.VerifyScroll()
                
        except Exception as e:
            GetExceptionInfo(e)
            return False
            
        return True
        ...

    def VerifyScroll(self):
    
        # Current page tree and ScrollIndexParentElement
        CurrentElementTree       = app_config.CurrentPage.PageElementTree
        CurrentScrollIndexParent = self.AssociatedElements.IndexParentElement
        
        # Get a new ElementTree from server
        NewElementTree           = app_pages.AndroidAppPage.CreateElementTree()
        
        # Find matching scroll elements in new element tree
        # The test for equality is custom using __eq___
        NewScrollableElement     = [ Element 
                                     for Element in NewElementTree.Descendants()
                                     if  Element == self ][0]
        
        NewIndexParentElement    = [ Element 
                                     for Element in NewElementTree.Descendants() 
                                     if  Element == CurrentScrollIndexParent ][0]
                                      
        
        if not NewScrollableElement:
            print('Unable to locate NewScrollableElement in NewElementTree')
            return ScrollableElement.SCROLL_RESULT_ERROR
        
        if not NewIndexParentElement:
            print('Unable to locate NewIndexParentElement in NewElementTree')
            return ScrollableElement.SCROLL_RESULT_ERROR
        
        
        print('GETTING CURRENT INDEX ELEMENTS')

        AllCurrentScrollIndexElements   = set( list(
                                        Element
                                        for Element in CurrentScrollIndexParent.Descendants(0)
                                        if  Element.Parent == CurrentScrollIndexParent ))
                                             
        AllCurrentScrollIndexValues     = set( list(
                                        Element.index
                                        for Element in AllCurrentScrollIndexElements ))
                                        
        CurrentVisibleScrollIndexValues = set( list(
                                          Element.index
                                          for Element in AllCurrentScrollIndexElements
                                          if  Element.displayed == True ))

        print('GETTING NEW INDEX ELEMENTS')
       
        AllNewScrollingIndexElements    = set( list(
                                          Element
                                          for Element in NewIndexParentElement.Descendants(0)
                                          if Element.Parent == NewIndexParentElement ))
        
        AllNewScrollingIndexValues      = set( list(
                                          Element.index
                                          for Element in AllNewScrollingIndexElements ))
        
        SymmetricDifference             = set( 
                                          CurrentVisibleScrollIndexValues ^ 
                                          AllNewScrollingIndexValues )
        
        print("All Current Scrolling    : " + str( AllCurrentScrollIndexValues ))
        print("Current Visible          : " + str( CurrentVisibleScrollIndexValues ))
        print("All New Scrolling        : " + str( AllNewScrollingIndexValues ))
        print("Difference               : " + str( SymmetricDifference ))
        print('Difference Length        : ' + str(len( SymmetricDifference )))
        
        if len( SymmetricDifference ) > 0:
            Result = ScrollableElement.SCROLL_RESULT_SCROLLED
        else:
            Result = ScrollableElement.SCROLL_RESULT_EOL
            
        # update element tree
        # first, set all scrolling index elements to non-visible
        for Element in AllCurrentScrollIndexElements:
            #print('Resetting current scrolling element to non-visible: ' + Element.Name)
            setattr( Element, 'displayed', False )
        
        # replace current elements with new elements
        for Element in AllNewScrollingIndexElements:
            #print('Replacing current scrolling element with new: ' + Element.Name)
            setattr( Element, 'Parent', CurrentScrollIndexParent)
            setattr( CurrentScrollIndexParent, Element.Name, Element )
 
        return Result
        ...

    def GetScrollingElementIndexValues( self, IndexParentElement = None ):
        
        if IndexParentElement  ==  None:
            IndexParentElement  =  self.AssociatedElements.IndexParentElement
                                      
        return sorted( list(
                       Element.index 
                       for Element in IndexParentElement.Descendants(0)
                       if  Element.Parent == IndexParentElement ))
                       #if not self.IsPartialScrollingElement( Element ) ))
    
        
    def FindAllScrollingIndexElements( self, Duration = 250 ):
    
        Total = 0

        # First, scroll to start of list
        
        if not self.ScrollToStart( Duration = Duration ):
            print("Failed to ScrollToStart")
            return ScrollableElement.SCROLL_RESULT_ERROR

        ScrollingIndexElements = self.GetScrollingElements()
        
        if not ScrollingIndexElements:
            print("Failed to GetScrollingElements")
            return ScrollableElement.SCROLL_RESULT_ERROR
        
        print(f'Total Scrolling Elements = ' + 
              f'{len(ScrollingIndexElements)}')
        
        # now scroll in stages, checking for new scroll child elements
        ScrollFunctionList = [ self.ScrollForward, 
                               self.ScrollBackward ]
        Result  = False
        Gap     = False
        
        for ScrollFunction in ncycles( ScrollFunctionList, 10 ):
    
            while True:

                Result = ScrollFunction( Duration = Duration )

                match Result:
                    case ScrollableElement.SCROLL_RESULT_SCROLLED:
                        print('SCROLL_RESULT_SCROLLED')
                    case ScrollableElement.SCROLL_RESULT_EOL:
                        print('SCROLL_RESULT_EOL')
                        break
                    case ScrollableElement.SCROLL_RESULT_ERROR:
                        print('SCROLL_RESULT_ERROR')
                        return False
                
                ScrollingIndexElements = self.GetScrollingElements()
                
                if not ScrollingIndexElements:
                    print("Failed to GetScrollingElements")
                    return ScrollableElement.SCROLL_RESULT_ERROR
                    
                print(f'Total Scrolling Elements = ' + 
                      f'{len(ScrollingIndexElements)}')
            ...        

            ScrollingIndexElements = self.GetScrollingElements()

            if not ScrollingIndexElements:
                print("Failed to GetScrollingElements")
                return ScrollableElement.SCROLL_RESULT_ERROR
                                     
            print(f'Total Scrolling Elements = ' + 
                  f'{len(ScrollingIndexElements)}')

            # get sorted list of all scroll elements found
            
            SortedIndexValues = self.GetScrollingElementIndexValues()
            
            if not SortedIndexValues:
                print("Failed to GetScrollingElements")
                return ScrollableElement.SCROLL_RESULT_ERROR
            
            # check for gaps
            # sometimes the list can start with 1 instead of 0
            # first check is for start gaps
            
            #if SortedIndexValues[0] > 1:
            #    Gap = True
            #else:
            
            # Use set dynamic difference to show other gaps
            FullRangeSet = set(range(SortedIndexValues[0],
                                     SortedIndexValues[-1] + 1))
            
            DynamicDifference = set( set(SortedIndexValues) ^ FullRangeSet )
            
            if len(DynamicDifference) > 0:
            
                Gap = True
                print('Gaps detected in Scrolling Index Elements:')
                print(str(DynamicDifference))
                
            else:
                Result = True
                print('No gaps found')
                break
                
            print("Switching directions to fill gaps")
            
        return Result
        ...
        
    
    def IsPartialScrollingElement( self, ScrollingIndexElement = None,
                                         IndexParentElement    = None ):
        
        if not IndexParentElement:
               IndexParentElement = self.AssociatedElements.IndexParentElement
        
        ChildResourceIDs          = self.AssociatedElements.ScrollingChildIDs
        
        FoundChildElements        = [ ( Element, ResourceID )
                                      for Element in ScrollingIndexElement.Descendants()
                                      for ResourceID in ChildResourceIDs
                                      if  ResourceID in Element.resource_id ]

        if len( FoundChildElements ) < len( ChildResourceIDs ):
            print("FOUND PARTIAL: ", ScrollingIndexElement.Name)
            
        return len( FoundChildElements ) < len( ChildResourceIDs )
            
        
    def GetScrollingElementByIndex( self, ScrollingElementIndex ):
        
        print("GetScrollingElementByIndex called")
        IndexParentElement = self.AssociatedElements.IndexParentElement
        
        return [ Element
                 for Element in self.AssociatedElements.IndexParentElement.Descendants(0)
                 if  Element.Parent == IndexParentElement
                 if  Element.index  == ScrollingElementIndex ][0]
        
    
    def GetScrollingElements( self, IndexParentElement = None ):
        
        if not IndexParentElement:
               IndexParentElement = self.AssociatedElements.IndexParentElement
        
        return [ Element 
                 for Element in IndexParentElement.Descendants(0)
                 if  Element.Parent == IndexParentElement ]
    
    def IsVisibleScrollingIndexElement( self, TargetElementIdx ):
        
        ScrollingIndexElements  = [ Element.index
                                    for Element in self.AssociatedElements.IndexParentElement.Descendants(0)
                                    if  Element.Parent == self.AssociatedElements.IndexParentElement ]
                           
        VisibleIndexValues      = sorted( list(
                                  Element.index 
                                  for Element in self.AssociatedElements.IndexParentElement.Descendants(0)
                                  if  Element.Parent == self.AssociatedElements.IndexParentElement
                                  if  Element.displayed == True ))

        FirstVisibleIdx         = VisibleIndexValues[0]
        LastVisibleIdx          = VisibleIndexValues[-1]
        Result                  = None

        if TargetElementIdx < FirstVisibleIdx:
            Distance    = TargetElementIdx - FirstVisibleIdx
            Result      = ( False, Distance )
            
        elif TargetElementIdx > LastVisibleIdx:
            Distance    = TargetElementIdx - LastVisibleIdx
            Result      = ( False, Distance )
            
        else:
            Distance    = 0
            #Distance    = int(( FirstVisibleIdx - LastVisibleIdx ) / 2 )
            Result      = ( True, Distance )
            
        
        print( f'FirstVisibleIdx   = {FirstVisibleIdx}'  )
        print( f'LastVisibleIdx    = {LastVisibleIdx}'   )
        print( f'TargetElementIdx  = {TargetElementIdx}' ) 
        print( f'Distance          = {Distance}'         )    
        
        if FirstVisibleIdx >= LastVisibleIdx:
            print()
            print( f'IsVisible ERROR: Indexes out of order' )
            Pause()
        
        return Result
    ...    

    def ScrollIntoViewByIndex( self, 
                        TargetElementIdx,
                        Duration = 250):

        print()
        print('--------------------------------------------------')
        print( f"ScrollIntoView called for: " + 
               f"{TargetElementIdx}" )
        
        Visible = False
        Partial = False
        ScrollFunction = None
        Result = None
        
        while not Visible:
            
            Visible, Distance = self.IsVisibleScrollingIndexElement( 
                                     TargetElementIdx )
            
            # break if element is visible and not partial
            if Visible: return True
            
            # choose scroll direction to find the element
            if Distance > 0:
                ScrollFunction = self.ScrollForward
                
            if Distance < 0:
                ScrollFunction = self.ScrollBackward
            
            # execute a scroll
            Result = ScrollFunction( Duration = Duration )
            
            match Result:
                case ScrollableElement.SCROLL_RESULT_SCROLLED:
                    print('SCROLL_RESULT_SCROLLED')
                case ScrollableElement.SCROLL_RESULT_EOL:
                    print('SCROLL_RESULT_EOL')
                case ScrollableElement.SCROLL_RESULT_ERROR:
                    print('SCROLL_RESULT_ERROR')
                    return False
                    
            # loop back again
        ...
        

class ClickableAndroidElement( ClickableElement ):

    def __init__( self ):
        ...

    def Click( self, RepeatCount = 1, Duration = 50 ):
        self.Tap( RepeatCount = RepeatCount, 
                  Duration = Duration)
                  
    def Tap( self, RepeatCount = 1, Duration = 50 ):
        
        print("Called")
        
        CenterX  = self.Attributes.get('bounds').get('CenterX')
        CenterY  = self.Attributes.get('bounds').get('CenterY')

        try:
        
            for x in range( RepeatCount ):
                
                self.PointerAction.move_to_location( 
                    x = CenterX, 
                    y = CenterY, 
                    duration = Duration )
                
                self.PointerAction.pointer_down( 
                    duration = Duration )
                    
                self.PointerAction.pointer_up()
                
                self.InputActions.perform()
                    
        except BaseException as e:
            GetExceptionInfo(e)
            #Pause()
            return False
            
        return True
    ...        
        
    
        
class FocusableAndroidElement( FocusableElement ):

    def __init__( self ):
        super().__init__()
        
    def SetFocus(self, RepeatCount = 1, Duration = 50):

        CenterX  = self.Attributes.get('bounds').get('CenterX')
        CenterY  = self.Attributes.get('bounds').get('CenterY')

        try:
        
            for x in range( RepeatCount ):
                
                self.PointerAction.move_to_location( 
                    x = CenterX, 
                    y = CenterY, 
                    duration = Duration )
                
                self.PointerAction.pointer_down( 
                    duration = Duration )
                
                self.InputActions.perform()
                    
        except BaseException as e:
            GetExceptionInfo(e)
            return False
            
        return True
    ...
    
class AndroidElement( MobileElement ):

    LOCATOR_ANDROID = '-android uiautomator'

    def __init__( self, *args, **kwargs ):
        super().__init__( *args, **kwargs )
    ...

    @classmethod
    def NewElement( cls, *args, **kwargs ):

        BaseClassSet    = set()
        ElementAttrs    = kwargs.get('Attributes')
        
        match ElementAttrs:
            case { 'scrollable' : True }:
                BaseClassSet.add( ScrollableAndroidElement )
            case { 'focusable' :  True }:
                BaseClassSet.add( FocusableAndroidElement )
            case { 'clickable' :  True }:
                BaseClassSet.add( ClickableAndroidElement )

        BaseClassTuple = ( AndroidElement, )
        
        for Item in BaseClassSet:
            BaseClassTuple += ( Item, )
            
        #print(f"Creating new: {BaseClassTuple}" )
        
        return ( type( 'AndroidElement', 
                        BaseClassTuple, 
                        {} )
                        ( *args, **kwargs ) )    

    
    def Swipe( self, 
               StartX = None, StartY= None, 
               EndX = None, EndY = None, 
               Duration = 250):
        print("Hello")
        
...   # end of AndroidElement class


class WebAppElement( AppElement ):

    LOCATOR_CSS     = 'css selector'

    def __init__( self, *args, **kwargs ):
        super().__init__( *args, **kwargs )
        self.ChromeInfo = app_config.Container()
        ...

    @classmethod
    def NewElement( cls, *args, **kwargs ):
      
        BaseClassSet    = set()
        ElementTag      = kwargs.get('Tag')
        ElementAttrs    = kwargs.get('Attributes')
        
        match ElementTag:
            case 'button' | 'input':
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )
            case 'textarea':
                BaseClassSet.add( EditableElement )
                BaseClassSet.add( FocusableElement )
            case 'body':
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )
            case 'html':
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )

        match ElementAttrs:
            case { 'role' : ( 'button' | 'checkbox' ) }:
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )
            case { 'type' : ( 'text' | 'password' ) }:
                BaseClassSet.add( EditableElement )
                BaseClassSet.add( FocusableElement )
            case { 'class' : Value } if Value and 'button' in Value:
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )
            case { 'href' : Value } if Value:
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )
            case { 'data-hash' : Value } if Value:
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )
            case { 'data-component-type' : Value } if Value:
                BaseClassSet.add( ClickableElement )
                BaseClassSet.add( FocusableElement )                
            
            
        BaseClassTuple = ( WebAppElement, )
        
        for Item in BaseClassSet:
            BaseClassTuple += ( Item, )
            
        #print(f"Creating new: {BaseClassTuple}" )
        
        return ( type( 'WebAppElement', 
                        BaseClassTuple, 
                        {} )
                        ( *args, **kwargs ) )

    def InitializeW3CActions( self ):
    
        # print('InitializingW3CActions')
        
        self.KeyInputSource             =   KeyInput( 
                                                interaction.KEY )
        self.WheelInputSource           =   WheelInput(
                                                interaction.WHEEL )
        self.MouseInputSource           =   PointerInput(
                                                interaction.POINTER_MOUSE, 
                                                interaction.POINTER_MOUSE )
        self.PointerInputSource         =   self.MouseInputSource
        self.InputActions               =   ActionChains( app_config.Driver )
        self.InputActions.w3c_actions   =   ActionBuilder(
                                                app_config.Driver,
                                                keyboard    = self.KeyInputSource,
                                                wheel       = self.WheelInputSource,
                                                mouse       = self.PointerInputSource )
                                                
        self.PointerAction              = self.InputActions.w3c_actions.pointer_action
        self.KeyAction                  = self.InputActions.w3c_actions.key_action
        self.WheelAction                = self.InputActions.w3c_actions.wheel_action

        self.ClearW3CActions()
        
        return True
        ...

    def GetChromeInfo( self ):
    
        # Pause("Start")
        '''
        DTF = apps.WebApp.DevToolsFunc
        
        self.ChromeInfo = app_config.Container()
        CI = self.ChromeInfo
        
        DocRoot = DTF( dom.get_document, depth = 0, pierce = False)
        
        CI.DocumentRoot = DocRoot
                
        NodeID = DTF( dom.query_selector, 
                    node_id = DocRoot.node_id,
                    selector = self.Selector )

        if NodeID != 0:
            CI.NodeID = dom.NodeId(NodeID)
        else:
            NodeID = dom.NodeId(1)
            CI.NodeID = NodeID
            
        DescribedNode = DTF( dom.describe_node, 
                            node_id = NodeID,
                            depth = 0, pierce = False )
        
     
        CI.DescribedNode = DescribedNode
        CI.NodeType = str(app_config.NodeTypes( DescribedNode.node_type ))
        
        if NodeID > 1:
        
            NodeAttributes = DTF( dom.get_attributes,
                                node_id = NodeID )
            
            CI.NodeAttributes = NodeAttributes
            
        else:
        
            CI.NodeAttributes = {}
            
        
        RemoteObject = DTF( dom.resolve_node,
                            node_id = NodeID,
                            object_group = 'MyGroup' )
                            
        CI.RemoteObject = RemoteObject
        
        
        
        ContentQuads    = DTF( dom.get_content_quads,
                               node_id = NodeID )        
        CI.ContentQuads = ContentQuads


        CI.BoxModel = []
        
        try:

            BoxModel    = DTF(  dom.get_box_model,
                                node_id = NodeID )

            CI.BoxModel = BoxModel 
        except BaseException as e:
            ...

        CI.RelayoutBoundary = []
    
        if NodeID > 1:
            
            try:
            
                RelayoutBoundary    = DTF(  dom.get_relayout_boundary,
                                            node_id = NodeID )
            
                CI.RelayoutBoundary = RelayoutBoundary
        
            except BaseException as e:
                print('Exception thrown for RelayoutBoundary')
                ...
        
        CI.EventListeners = []

        try:
        
            EventListeners      = DTF( dom_debugger.get_event_listeners,
                                    object_id = RemoteObject.object_id,
                                    depth = 0,
                                    pierce = False )
        
            CI.EventListeners = EventListeners
        
        except BaseException as e:
            print('Exception thrown for get_event_listeners')
            ...
            
        
        #Info(self)
        #Info(CI)
        
        # Pause("Next")
        '''

    def MyHideHighlight( self ):
    
        CI              = self.ChromeInfo
        DTF             = apps.WebApp.DevToolsFunc
        DocRoot         = DTF(  dom.get_document, 
                                depth = 0, 
                                pierce = False)
        NodeID          = DTF(  dom.query_selector, 
                                node_id = DocRoot.node_id,
                                selector = self.Selector )
        Result          = DTF(  dom.hide_highlight,
                                node_id = NodeID )
        CI.NodeID       = NodeID
                            
        return Result


    def MyHighlightNode( self ):
    
        CI              = self.ChromeInfo
        DTF             = apps.WebApp.DevToolsFunc
        ADTF            = apps.WebApp.RunAsync
        DocRoot         = DTF(  dom.get_document, 
                                depth = 0, 
                                pierce = False)
        NodeID          = DTF(  dom.query_selector, 
                                node_id = DocRoot.node_id,
                                selector = self.Selector )

        
        
        ContentColor = dom.RGBA(r = 150, g = 150, b = 150, a = 255 )
        PaddingColor = dom.RGBA(r = 150, g = 150, b = 150, a = 255 )
        BorderColor = dom.RGBA(r = 150, g = 150, b = 150, a = 255 )
        MarginColor = dom.RGBA(r = 150, g = 150, b = 150, a = 255 )
        EventTargetColor = dom.RGBA(r = 255, g = 0, b = 0, a = 255 )
        ShapeColor = dom.RGBA(r = 150, g = 150, b = 150, a = 255 )
        ShapeMarginColor = dom.RGBA(r = 150, g = 150, b = 150, a = 255 )
        CSSGridColor = dom.RGBA(r = 150, g = 150, b = 150, a = 255 )
        
        NodeConfig = overlay.HighlightConfig(
                        show_info = True,
                        show_styles = True,
                        show_rulers = True,
                        show_accessibility_info = True,
                        show_extension_lines = True,
                        content_color = ContentColor,
                        padding_color = PaddingColor,
                        border_color = BorderColor,
                        margin_color = MarginColor,
                        event_target_color = EventTargetColor,
                        shape_color = ShapeColor, 
                        shape_margin_color = ShapeMarginColor,
                        css_grid_color = CSSGridColor,
                        color_format = overlay.ColorFormat.RGB,
                        grid_highlight_config = overlay.GridHighlightConfig(),
                        flex_container_highlight_config = overlay.FlexContainerHighlightConfig(),
                        flex_item_highlight_config = overlay.FlexItemHighlightConfig(),
                        contrast_algorithm = overlay.ContrastAlgorithm(value='aa'),
                        container_query_container_highlight_config = overlay.ContainerQueryContainerHighlightConfig())
                        
                                         

       # Result          = DTF( overlay.enable )
        
                                         
        Result          = ADTF( overlay.highlight_node,
                                highlight_config = NodeConfig,
                                node_id = NodeID )
                                
        return Result
    
    
    def MyHighlightRect( self ):
    
        CI              = self.ChromeInfo
        DTF             = apps.WebApp.DevToolsFunc
        DocRoot         = DTF(  dom.get_document, 
                                depth = 0, 
                                pierce = False)
        NodeID          = DTF(  dom.query_selector, 
                                node_id = DocRoot.node_id,
                                selector = self.Selector )
        
        Quad            = self.GetContentQuad()
        
        if not Quad:
            Quad        = self.GetBoxModel()
            
        RectX           = Quad[0][0]
        RectY           = Quad[0][1]
        Width           = Quad[0][2] - Quad[0][0]
        Height          = Quad[0][7] - Quad[0][1]

        Rectangle       = dom.Rect( RectX, RectY, Width, Height )
                        
        Result          = DTF(  overlay.highlight_rect,
                                rect = Rectangle )
                                
        CI.NodeID       = NodeID
                            
        return Result  
    
    
    def GetTargets( self ):
    
        CI              = self.ChromeInfo
        DTF             = apps.WebApp.DevToolsFunc
        DocRoot         = DTF(  target.get_targets, 
                                depth = 10, 
                                pierce = False)
                                
        print("**************************************")
        quit()
        NodeID          = DTF(  dom.query_selector, 
                                node_id = DocRoot.node_id,
                                selector = self.Selector )
                        
        Result          = DTF( get_targets )
        return Result
        
        
    
    def GetRemoteObjectID( self ):
    
        CI              = self.ChromeInfo
        DTF             = apps.WebApp.DevToolsFunc
        DocRoot         = DTF(  dom.get_document, 
                                depth = 0, 
                                pierce = False)
        NodeID          = DTF(  dom.query_selector, 
                                node_id = DocRoot.node_id,
                                selector = self.Selector )
                        
        CI.RemoteObject = DTF(  dom.resolve_node,
                                node_id = NodeID )
        CI.NodeID       = NodeID
                            
        return CI.RemoteObject

                    
    def GetCenterXY( self ):
    
        # quads are 4 x,y coordinates in
        # clockwise order, Y axis values are backwards
        # 
        # BoxModel(content=Quad([
        # top-left:  x1 = 677, y1 = 566.7999877929688, 
        # top-right: x2 = 827, y2 = 566.7999877929688, 
        # bot-right: x3 = 827, y3 = 601.7999877929688, 
        # bot-left : x4 = 677, y4 = 601.7999877929688])
        
        if not self.GetContentQuad():
            if not self.GetBoxModel():
                return False
        
        CI      = self.ChromeInfo
        Quad    = None
        
        if CI.ContentQuad:
            Quad = CI.ContentQuad[0]
        else:
            if CI.BoxModel:
                Quad = CI.BoxModel.content
            else:
                print('Unable to find coordinates')
                return None
        
        TopLeft_X1  = Quad[0]
        TopLeft_Y1  = Quad[1]
        
        TopRight_X2 = Quad[2]
        TopRight_Y2 = Quad[3]
        
        BotRight_X3 = Quad[4]
        BotRight_Y3 = Quad[5]
        
        BotLeft_X4  = Quad[6]
        BotLeft_Y4  = Quad[7]

        Center_X    = (( TopRight_X2 - TopLeft_X1 ) / 2 ) + TopLeft_X1
        Center_Y    = (( BotLeft_Y4  - TopLeft_Y1 ) / 2 ) + TopLeft_Y1
        
        return Center_X, Center_Y
        ...

    def GetInsideLowerRightXY( self, OffsetPixels = None ):
    
        # quads are 4 x,y coordinates in
        # clockwise order, Y axis values are backwards
        # 
        # BoxModel(content=Quad([
        # top-left:  x1 = 677, y1 = 566.7999877929688, 
        # top-right: x2 = 827, y2 = 566.7999877929688, 
        # bot-right: x3 = 827, y3 = 601.7999877929688, 
        # bot-left : x4 = 677, y4 = 601.7999877929688])
        
        if not self.GetContentQuad():
            if not self.GetBoxModel():
                return False
        
        CI      = self.ChromeInfo
        Quad    = None
        
        if CI.ContentQuad:
            Quad = CI.ContentQuad[0]
        else:
            if CI.BoxModel:
                Quad = CI.BoxModel.content
            else:
                print('Unable to find coordinates')
                return None
                
        BotRight_X3 = Quad[4]
        BotRight_Y3 = Quad[5]
        
        BotRight_X3_Offset = BotRight_X3 - OffsetPixels
        BotRight_Y3_Offset = BotRight_Y3 - OffsetPixels
        
        return BotRight_X3_Offset, BotRight_Y3_Offset
        ...
        
    def GetInnerHTML( self ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}')." +
                   f"innerHTML;" )
        
        try:
        
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  })
                          
        except BaseException as e:
            #GetExceptionInfo(e)
            #Pause()
            return False
        
        if Result:  return Result.get('value')
        else:       return False
            
            
    def SetInnerHTML( self, Text = None ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}')." +
                   f'innerHTML = "{Text}");' )
        
        try:
        
            print(Script)
            
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  })
                          
        except BaseException as e:
            GetExceptionInfo(e)
            Pause()
            return False
        
        if Result:  return Result.get('value')
        else:       return False


    def GetOuterHTML( self ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}').outerHTML;" )
        
        try:
        
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  })
                          
        except BaseException as e:
            GetExceptionInfo(e)
            Pause()
            return False
        
        if Result:  return Result.get('value')
        else:       return False            


 
            

    def GetAttributes( self ):
    
        Result = None
        Script = f"return document.querySelector('{self.Selector}').attributes"
        
        try:
        
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  } ) 

        except BaseException as e:
            #Pause("GetAttributes Exception:")
            #GetExceptionInfo(e)
            return None
        
        if Result:  return Result.get('value')
        else:       return None
    
    def GetNodeName( self ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}').nodeName;" )
        
        try:
            print(Script)
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  } ) 

        except BaseException as e:
            GetExceptionInfo(e)
            Pause()
            return None
        
        if Result:  return Result.get('value')
        else:       return None    
    
    
    
            
    def GetContentQuad( self ):
    
        DTF     = apps.WebApp.DevToolsFunc
        CI      = self.ChromeInfo
        Result  = None

        CI.ContentQuad = []
        
        try:
            
            DocRoot         = DTF(  dom.get_document, 
                                    depth = 0, 
                                    pierce = True )
                
            NodeID          = DTF(  dom.query_selector, 
                                    node_id = DocRoot.node_id,
                                    selector = self.Selector )            
            
            CI.ContentQuad  = DTF(  dom.get_content_quads,
                                    node_id = NodeID )
            
            CI.NodeID       = NodeID
            
            return  CI.ContentQuad
                                    
        except BaseException as e:
            return None
            ...
            

    def GetBoxModel( self ):
    
        DTF     = apps.WebApp.DevToolsFunc
        CI      = self.ChromeInfo
        Result  = None

        CI.BoxModel = []

        try:
            
            DocRoot     = DTF(  dom.get_document, 
                                depth = 0, 
                                pierce = True)
                
            NodeID      = DTF(  dom.query_selector, 
                                node_id = DocRoot.node_id,
                                selector = self.Selector )            
            
            CI.BoxModel = DTF(  dom.get_box_model,
                                node_id = NodeID )
            
            CI.NodeID   = NodeID
            
            return CI.BoxModel
                                 
        except BaseException as e:
            return None
            ...
        
        
    @classmethod
    def RunScript( cls, Script, Args = None ):
    
        if Args == None: Args = []
        Result = None    
        
        try:
        
            print(Script)
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : Args  } ) 

        except BaseException as e:
            #GetExceptionInfo(e)
            ...
            
        if    Result:  
              return   Result.get('value')
        else: return   None
    
    
    
    def ScrollIntoView( self ):

        DTF     = apps.WebApp.DevToolsFunc
        CI      = self.ChromeInfo
        Result  = None
        
        try:
            
            DocRoot         = DTF(  dom.get_document, 
                                    depth = 0, 
                                    pierce = True )
                
            NodeID          = DTF(  dom.query_selector, 
                                    node_id = DocRoot.node_id,
                                    selector = self.Selector )            
            
            Result          = DTF(  dom.scroll_into_view_if_needed,
                                    node_id = NodeID )
                                    
            CI.NodeID       = NodeID
                                    
            return  Result
                                    
        except BaseException as e:
            return None
            ...
            
        
        
    def GetNodeValue( self ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}').nodeValue;" )
        
        try:
            print(Script)
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  } ) 

        except BaseException as e:
            GetExceptionInfo(e)
            Pause()
            return None
        
        if Result:  return Result.get('value')
        else:       return None
        
        
    def GetNodeType( self ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}').nodeType;" )
        
        try:
            print(Script)
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  } ) 

        except BaseException as e:
            GetExceptionInfo(e)
            Pause()
            return None
        
        if Result:  return Result.get('value')
        else:       return None


    def GetComputedStyle( self ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}')." +
                   f"getComputedStyle();" )
        
        try:
        
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  } ) 

        except BaseException as e:
            #GetExceptionInfo(e)
            #Pause()
            return None
        
        if Result:  return Result.get('value')
        else:       return None
        
        
    def GetAttribute( self, Name ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}')." +
                   f"getAttribute('{Name}');" )
        
        try:
        
            Result = app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  } ) 

        except BaseException as e:
            #GetExceptionInfo(e)
            #Pause()
            return None
        
        if Result:  return Result.get('value')
        else:       return None
            
    
    def RemoveAttribute( self, Name ):
    
        Result = None
        Script = ( f"return document.querySelector('{self.Selector}')." +
                   f"removeAttribute('{Name}');" )
        
        CurrentValue = self.GetAttribute(Name)
        
        if not CurrentValue:
            print('Attribute does not exist, no need to remove')
            return True
        else:
            try:
            
                Result = app_config.Driver.execute( 
                            Command.W3C_EXECUTE_SCRIPT,
                            { 'script' : Script,
                              'args'   : []  } ) 

            except BaseException as e:
                GetExceptionInfo(e)
                Pause()
                return False
        
        if Result:
            
            print("old value: " + str(CurrentValue))
            print("new value: " + str(self.GetAttribute(Name)))
            
            if CurrentValue == self.GetAttribute(Name):
                return False
            else:
                return True
        
        return False
        
    def SetAttribute( self, Name, Value ):

        CurrentValue    = None
        NewValue        = None
        Result          = None
        
        CurrentValue    = self.GetAttribute( Name )
        
        if CurrentValue == None:
            ...
            #print('Failed to get Attribute')
            
        if CurrentValue:
            
            if not self.RemoveAttribute( Name ):
            
                print('Failed to remove existing Attribute: ' + 
                        str(CurrentValue))
                        
                return None
            
        Script = ( f"return document.querySelector('{self.Selector}')." +
                   f"setAttribute('{Name}','{Value}');" )
                   
        try:
        
            Result =  app_config.Driver.execute( 
                        Command.W3C_EXECUTE_SCRIPT,
                        { 'script' : Script,
                          'args'   : []  } ) 

        except BaseException as e:
            #GetExceptionInfo(e)
            #Pause()
            return None
        
        if Result:  
            NewValue = Result.get('value')
            #setattr(self, Name, Value)
            return NewValue
        else:
            return None

    
    def IsActiveElement(self):

        Result = None
        try:
            Result = None
            Script = f"return (document.querySelector('{self.Selector}') == document.activeElement)"
            Result = self.RunScript( Script )
        except BaseException as e:
            ...
            
        if Result:  return Result
        else:       return None
        ...
    
    # TODO:  Use the javascript toggle function
    def Hide( self ):
                
        Result        = None
        NewStyle      = None
        HideStyle     = "display: none;"
        CurrentStyle  = self.GetAttribute('style')
        
        if not CurrentStyle:
            NewStyle = HideStyle
        else:
            CurrentStyle = CurrentStyle.strip()
            CurrentStyle += f" {HideStyle}"

        return self.SetAttribute('style', HideStyle)
                

    def Show( self ):
    
        Result        = None
        HideStyle     = "display: none;"
        NewStyle      = None
        CurrentStyle  = self.GetAttribute('style')
        
        if not CurrentStyle:
            return True
        else:
            if HideStyle in CurrentStyle:
                NewStyle = ( 
                    CurrentStyle.replace(HideStyle, '').strip() )
                    
                return self.SetAttribute('style', NewStyle)
            else:
                return False


# Custom JSON Serializer stand-alone function            
def JSONSerializer(Obj):
        
    if isinstance( Obj, AppElement ):
       
        # make an object copy
        ObjCopy = copy.copy(Obj)
        ObjDict = ObjCopy.__dict__
        
        # to prevent circular loops, remove children of parent

        Parent = ObjDict.get('Parent')
        if Parent:
        
            ParentChildDeleteItems = []
            for Key, Value in Parent.__dict__.items():
                
                #print(Key, type(Value))
                
                if Key == 'Parent':
                    continue
                
                if not isinstance( Value, AppElement ):
                    continue
                
                #print('Appending to ParentChildDeleteItems: ' + Key)
                ParentChildDeleteItems.append(Key)

            for Item in ParentChildDeleteItems:
                #print('Deleting parent key: ' + Item)
                del Parent.__dict__[Item]


        KeepItems = [ 'Name', 'Tag', 'Text', 'Tail',
                      'Attributes', 'ObjPath', 'XPath',
                      'Selector', 'Locator' ]
                      
              
        DeleteItems = []
        
        for Key, Value in ObjDict.items():
        
            #print(Key, type(Value))
            
            if Key in KeepItems:
                continue
                
            if isinstance( Value, AppElement ):
                continue
                
            #print('Appending to self DeleteItems: ' + Key)
            DeleteItems.append(Key)
                
        for Item in DeleteItems:
            #print('Deleting self key: ' + Item)
            del ObjDict[Item]
        
        return(ObjDict)
    
...



if __name__ == '__main__':
    print('Hello, world')



'''

# BoxModel(
content=Quad(
[top-left:  x1 = 677, y1 = 566.7999877929688, 
top-right: x2 = 827, y2 = 566.7999877929688, 
bot-right: x3 = 827, y3 = 601.7999877929688, 
bot-left : x4 = 677, y4 = 601.7999877929688]), 

padding=Quad(
[677, 566.7999877929688, 
827, 566.7999877929688, 
827, 601.7999877929688, 
677, 601.7999877929688]), 

border=Quad(
[677, 566.7999877929688, 
827, 566.7999877929688, 
827, 601.7999877929688, 
677, 601.7999877929688]), 

margin=Quad(
[677, 566.7999877929688, 
827, 566.7999877929688, 
827, 601.7999877929688, 
677, 601.7999877929688]), 

width=150, 
height=35, 
shape_outside=None)


'''

'''
self.ScrollIntoView()

Rect = self.GetBoundingClientRect()
if not Rect:
print('Rect is bad again')
return False
print(str(Rect))

Bottom  = Rect.get('bottom')
Height  = Rect.get('height')
Left    = Rect.get('left')
Right   = Rect.get('right')
Top     = Rect.get('top')
Width   = Rect.get('width')
X       = Rect.get('x')
Y       = Rect.get('y')
CenterX = int( ( Width  / 2)  + X )
CenterY = int( ( Height / 2 ) + Y )
Result = None

print(f"Rect: {Rect}, CenterX: {CenterX}, CenterY: {CenterY}")


Script = ( f"return document.querySelector('{self.Selector}').click();" ) 
Result = self.RunScript( Script )
return Result

self.PointerAction.move_to_location(
x = int(CenterX), 
y = int(CenterY), 
duration = 0 )

self.PointerAction.pointer_down()
self.PointerAction.pointer_up()
self.InputActions.perform()    

return Result
'''

'''
Script = ( f"return document.createEvent('MouseEvents').initMouseEvent('mousemove', " +
"{" +
" 'bubbles': 'true'," +
" 'cancelable': 'true'," +
" 'composed': 'true'," +
f" 'clientX': '{CenterX}', " +
f" 'clientY': '{CenterY}', " +
" 'eventPhase': 1," +
" 'button': 0, " +
" 'buttons': 0, " +                    
" 'cancelBubble': 'false'," +
" 'returnValue': 'true'," +
" 'defaultPrevented': 'false'," +
" 'isTrusted': 'true'," +
" 'timeStamp': '999999999'," +
" 'initialized': 'true'," +
" 'view': document.defaultView," +
f" 'srcElement': '{self.Selector}', " +
f" 'currentTarget': '{self.Selector}', " +                      
f" 'target': '{self.Selector}' " +
"});" )

Result = self.RunScript( Script )
print(str(Result))


Script = ( f"return document.createEvent('MouseEvents').initMouseEvent('mousedown', " +
"{" +
" 'bubbles': 'true'," +
" 'cancelable': 'true'," +
" 'composed': 'true'," +
" 'button': 0, " +
" 'buttons': 1, " +
f" 'clientX': '{CenterX}', " +
f" 'clientY': '{CenterY}', " +
" 'eventPhase': 1," +
" 'cancelBubble': 'false'," +
" 'returnValue': 'true'," +
" 'defaultPrevented': 'false'," +
" 'isTrusted': 'true'," +
" 'timeStamp': '999999999'," +
" 'initialized': 'true'," +
" 'view': document.defaultView," +
f" 'srcElement': '{self.Selector}', " +
f" 'currentTarget': '{self.Selector}', " +                      
f" 'target': '{self.Selector}' " +
"});" )

Result = self.RunScript( Script )
print(str(Result))

Script = ( f"return document.createEvent('MouseEvents').initMouseEvent('mouseup', " +
"{" +
" 'bubbles': 'true'," +
" 'cancelable': 'true'," +
" 'composed': 'true'," +
" 'button': 0, " +
" 'buttons': 0, " +                  
f" 'clientX': '{CenterX}', " +
f" 'clientY': '{CenterY}', " +
" 'eventPhase': 1," +
" 'cancelBubble': 'false'," +
" 'returnValue': 'true'," +
" 'defaultPrevented': 'false'," +
" 'isTrusted': 'true'," +
" 'timeStamp': '999999999'," +
" 'initialized': 'true'," +
" 'view': document.defaultView," +
f" 'srcElement': '{self.Selector}', " +
f" 'currentTarget': '{self.Selector}', " +                      
f" 'target': '{self.Selector}' " +
"});" )

Result = self.RunScript( Script )
print(str(Result))

Script = ( f"return document." +
f"createEvent(new PointerEvent('click', " +
"{" +
" 'bubbles': 'click'," +
" 'cancelable': 'true'," +
" 'composed': 'true'," +
" 'eventPhase': 1," +
f" 'clientX': '{CenterX}', " +
f" 'clientY': '{CenterY}', " +                  
" 'cancelBubble': 'false'," +
" 'returnValue': 'true'," +
" 'defaultPrevented': 'false'," +
" 'isTrusted': 'true'," +
" 'timeStamp': '999999999'," +
" 'initialized': 'true'," +
" 'view': document.defaultView," +
f" 'srcElement': '{self.Selector}', " +
f" 'currentTarget': '{self.Selector}', " +                      
f" 'target': '{self.Selector}' " +
"}));" )

Result = self.RunScript( Script )
print(str(Result))

return Result
'''
