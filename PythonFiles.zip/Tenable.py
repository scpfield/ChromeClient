import sys, time, random
import  trio

from    selenium.webdriver.common.devtools.v110 import *
import signal
import  apps
from    apps import *
import  app_config
import  app_pages
import  app_elements
from    util import *


class TenableApp( WebApp ):

    def __init__( self, UseAppium = False ):
        super().__init__( UseAppium )     
    ...
    
    
    #async def Main(self):
    #    async with app_config.Driver.bidi_connection() as connection:
    #        session, devtools = connection.session, connection.devtools
            # await session.execute(devtools.fetch.enable())
    #        await session.execute(devtools.network.enable())
    
    #async with driver.bidi_connection() as connection:
    #    session, devtools = connection.session, connection.devtools

        # await session.execute(devtools.fetch.enable())
    #    await session.execute(devtools.network.enable())

        # listener = session.listen(devtools.fetch.RequestPaused)
    #    listener = session.listen(devtools.network.ResponseReceived)
    #    async with trio.open_nursery() as nursery:
    #        nursery.start_soon(start_listening, listener) # start_listening blocks, so we run it in another coroutine
    


    def Logon( self ):

        LogonURL    = 'https://localhost:8834/'
        WaitFor     = { 'Tag' : 'button', 'type' : 'submit' }
        
        if not self.LoadPage( PageName = "LogonPage",
                              Target = LogonURL, 
                              WaitFor = WaitFor ):
            print('Failed to load page: ' + LogonURL)
            return False


        LogonPageRoot   = self.CurrentPage.PageElementTree

        UsernameField = ([  Element
                            for  Element  in  LogonPageRoot.Descendants()
                            if   isinstance( Element, app_elements.EditableElement )
                            if   getattr(    Element, 'aria-label' ) == 'Username' ])[0]
        PasswordField = ([  Element
                            for  Element  in  LogonPageRoot.Descendants()
                            if   isinstance( Element, app_elements.EditableElement )
                            if   getattr(    Element, 'aria-label' ) == 'Password' ])[0]
        LogonButton   = ([  Element
                            for  Element  in  LogonPageRoot.Descendants()
                            if   isinstance( Element, app_elements.ClickableElement )
                            if   getattr(    Element, 'type' ) == 'submit' 
                            if   getattr(    Element.Parent, 'class' ) == 'login' ])[0]
    
    
    
    
        UsernameField.TypeKeys("scpfield")
        PasswordField.SetFocus()
        PasswordField.TypeKeys("admin")
        LogonButton.SetFocus()
        LogonButton.Click()
        
        return True
        
        #PasswordField.SetFocus()
        #LogonButton.SetFocus()
        #LogonButton.Hover()

        '''
        Result = app_config.Driver.execute_cdp_cmd("DOM.enable", {} )
        Result = app_config.Driver.execute_cdp_cmd("DOMSnapshot.enable", {} )
        Result = app_config.Driver.execute_cdp_cmd("Runtime.enable", {} )
        RootNode = app_config.Driver.execute_cdp_cmd("DOM.getDocument", { 'depth' : -1 } )
        time.sleep(5)
        RootNode = app_config.Driver.execute_cdp_cmd("DOM.getDocument", { 'depth' : -1 } )
        Desc = app_config.Driver.execute_cdp_cmd("DOM.describeNode", { 'nodeId' : 89 } )                    
        Script = f"return document.querySelectorAll('document.documentElement').getPageCache;"
        Result = app_elements.WebAppElement.RunScript(Script)
        print("Document:")
        Result = app_config.Driver.execute_cdp_cmd( "Runtime.evaluate", 
                                                    {'expression' : 'document'} )
        print("Emulation")
        Result = app_config.Driver.execute_cdp_cmd( "Emulation.canEmulate", {} )
        for Node in LogonPageRoot.Descendants():
            Result = app_config.Driver.execute_cdp_cmd("Runtime.evaluate", 
                                                    {'expression' : Node.DOMPath } )
            ObjectId = Result['result']['objectId']
            print(str( Result ))
            Result = app_config.Driver.execute_cdp_cmd("DOMDebugger.getEventListeners", 
                                                       { 'objectId' : ObjectId } )
            for Idx, Listener in enumerate(Result['listeners']):
                print(Idx, str(Listener))
            print(str(Result))
            # Pause()
        '''

    
    def CreateAllScans( self ):
    
        CategoryItemList = self.GetCategoryItems()
        
        if not CategoryItemList:
            print('Failed to get the list of Scan categories')
            return False
            
        for Item in CategoryItemList:
            
            ( Selector, Title ) = Item
            
            print()
            print("Creating Scan for: " + Title)
            print("Selector: " + Selector)
            print()
            
            WaitFor = { 'Tag' : 'div', 'class' : 'library' }
            if not self.LoadPage( PageName = "ScanTemplatesPage", WaitFor = WaitFor ):
                print('Failed to load ScanTemplatesPage');
                return False
        
            ScanTemplatesPageRoot  = self.CurrentPage.PageElementTree
            
            CategoryElement =  ([  Element
                                   for Element in ScanTemplatesPageRoot.Descendants()
                                   if isinstance(Element, app_elements.ClickableElement)
                                   if Element.Selector == Selector ])[0]
            
            CategoryElement.Click()
            
            if not ( self.CreateScan( Title )):
                return False
                
            WaitFor = { 'id' : 'new-scan' }
            if not self.LoadPage( PageName = "HomePage", WaitFor = WaitFor ):
                print('Failed to load HomePage');
                return False
                
            HomePageRoot    =     self.CurrentPage.PageElementTree
            NewScanButton   = ([  Element
                                  for  Element  in  HomePageRoot.Descendants()
                                  if   isinstance( Element, app_elements.ClickableElement )
                                  if   getattr(    Element, 'id' ) == 'new-scan' ])[0]
                                  
            time.sleep(2)
                                  
            if NewScanButton:
                NewScanButton.Click()
            else: return False
            

        return True
        '''
    
        WaitFor = { 'id' : 'new-scan' }        
        if not self.LoadPage( PageName = "HomePage", WaitFor = WaitFor ):
            print('Failed to load HomePage');
            return False
        
            # [1] section > a[class="button floatright secondary "][href="#/scans/reports/new"][id="new-scan"], a_0, html_0.body_0.section_2.section_0.a_0
           
           
        HomePageRoot    = self.HomePage.PageElementTree
        NewScanButton   = ([  Element
                              for  Element  in  HomePageRoot.Descendants()
                              if   isinstance( Element, app_elements.ClickableElement )
                              if   getattr(    Element, 'id' ) == 'new-scan' ])[0]

        if NewScanButton:
            NewScanButton.Click()
        else:
            return False

        WaitFor = { 'Tag' : 'div', 'class' : 'library' }
        
        if not self.LoadPage( PageName = "ScanTemplatesPage", WaitFor = WaitFor ):
            print('Failed to load ScanTemplatesPage');
            return False
        
        ScanTemplatesPageRoot  = self.ScanTemplatesPage.PageElementTree
        '''        
    

        
    

    def GetCategoryItems(self):
    
        WaitFor = { 'id' : 'new-scan' }
        if not self.LoadPage( PageName = "HomePage", WaitFor = WaitFor ):
            print('Failed to load HomePage');
            return False
            
        HomePageRoot    =     self.CurrentPage.PageElementTree
        NewScanButton   = ([  Element
                              for  Element  in  HomePageRoot.Descendants()
                              if   isinstance( Element, app_elements.ClickableElement )
                              if   getattr(    Element, 'id' ) == 'new-scan' ])[0]
        
        NewScanButton.Click()
        
        WaitFor = { 'class' : 'category-templates' }
        if not self.LoadPage( PageName = "ScanTemplatesPage", WaitFor = WaitFor ):
            print('Failed to load ScanTemplatesPage');
            return False
        
        ScanTemplatesPageRoot  = self.CurrentPage.PageElementTree

        Categories  = ([    Element
                            for  Element in ScanTemplatesPageRoot.Descendants()
                            if   hasattr( Element, 'data-category' )
                            if   getattr( Element, 'class' ) == 'category-templates' ])
        
        CategoryItemList = []
        
        for Category in Categories:
        
            CategoryName = getattr( Category, 'data-category' )
            print( f"Category: {CategoryName}" )
            
            CategoryItems = ([  (Element.Selector, Child.Text)
                                for  Element in Category.Descendants()
                                if   getattr( Element, 'data-category' ) == CategoryName
                                if   isinstance( Element, app_elements.ClickableElement )
                                if   ({ 'class' : 'banner' }, True) not in Element
                                for  Child in Element.Descendants()
                                if   getattr( Child, 'class' ) == 'title'
                             ])
            
            CategoryItemList.extend(CategoryItems)
            
        return CategoryItemList
        
        
    def CreateScan(self, CategoryTitle ):
        
        WaitFor = { 'aria-label' : 'Name', 'aria-label' : 'Targets' }
        if not self.LoadPage( PageName = "NewScanPage", WaitFor = WaitFor ):
            print('Failed to load NewScanPage');
            return False
        
        NewScanPageRoot = self.CurrentPage.PageElementTree
        NameField    = ([  Element
                           for Element in NewScanPageRoot.Descendants()
                           if isinstance( Element, app_elements.EditableElement )
                           if getattr( Element, 'aria-label' ) == 'Name' ])[0]
        
        TargetsField = ([ Element
                          for Element in NewScanPageRoot.Descendants()
                          if isinstance( Element, app_elements.EditableElement )
                          if getattr( Element, 'aria-label' ) == 'Targets' ])[0]
        
        if not NameField or not TargetsField:
            print('Failed to locate elements')
            return False        
        
        NameField.TypeKeys( 'My ' + CategoryTitle )
        TargetsField.TypeKeys( '172.16.0.35, 172.16.34.156' )

        if CategoryTitle == 'Advanced Dynamic Scan':
        
            DynamicPluginsButton  = (
                [   Element
                    for Element in NewScanPageRoot.Descendants()
                    if isinstance( Element, app_elements.ClickableElement )
                    if getattr( Element, 'data-name' ) == 'dynamic-plugins' ])[0]
                    
            DynamicPluginsButton.Click()
            
            WaitFor = { 'Tag' : 'input', 'data-name' : 'Result Filter Control Input' }
            if not self.LoadPage( PageName = "DynamicPluginsPage", WaitFor = WaitFor ):
                print('Failed to load DynamicPluginsPage');
                return False

            DynamicPluginsPageRoot = self.CurrentPage.PageElementTree
            
            CVEField    = ([ Element
                             for Element in DynamicPluginsPageRoot.Descendants()
                             if isinstance( Element, app_elements.EditableElement )
                             if getattr( Element, 'data-name' ) == 'Result Filter Control Input' ])[0]
                             
            CVEField.TypeKeys( 'CVE-2011-0018' )
        
        
        if (( CategoryTitle == 'Malware Scan' ) or
            ( CategoryTitle == 'Credentialed Patch Audit' )):
        
            CredentialsButton  = ([  Element
                                     for Element in NewScanPageRoot.Descendants()
                                     if isinstance( Element, app_elements.ClickableElement )
                                     if getattr( Element, 'data-name' ) == 'credentials' ])[0]
             
            CredentialsButton.Click()
            self.AddCredential()

        
        WaitFor = { 'data-action' : 'save' }
        if not self.LoadPage( PageName = "NewScanPage", WaitFor = WaitFor ):
            print('Failed to load NewScanPage');
            return False
        
        NewScanPageRoot = self.CurrentPage.PageElementTree
        SaveButton   = ([  Element
                           for Element in NewScanPageRoot.Descendants()
                           if isinstance( Element, app_elements.ClickableElement )
                           if getattr( Element, 'data-action' ) == 'save' ])[0]

        SaveButton.Click()
        return True
                
    
    
    def AddCredential( self ):
            
            WaitFor = { 'Tag' : 'li', 'data-name' : 'Windows' }
            if not self.LoadPage( PageName = "CredentialsPage", WaitFor = WaitFor ):
                print('Failed to load CredentialsPage');
                return False
                    
            CredentialsPageRoot = self.CurrentPage.PageElementTree
            WindowsButton   = ([  Element
                                  for Element in CredentialsPageRoot.Descendants()
                                  if isinstance( Element, app_elements.ClickableElement )
                                  if getattr( Element, 'data-name' ) == 'Windows' ])[0]
                                  
            WindowsButton.Click()
            
            WaitFor = { 'aria-label' : 'Username' }
            if not self.LoadPage( PageName = "WindowsPage", WaitFor = WaitFor ):
                print('Failed to load WindowsPage');
                return False
                
            WindowsPageRoot = self.CurrentPage.PageElementTree
                
            UsernameField = ([  Element
                                for  Element  in  WindowsPageRoot.Descendants()
                                if   isinstance( Element, app_elements.EditableElement )
                                if   getattr( Element, 'aria-label' ) == 'Username' 
                                for  Ancestor in  Element.Ancestors()
                                if   getattr( Ancestor, 'data-parent-id' ) == 'auth_method'
                                if   'hide' not in getattr( Ancestor, 'class' ) ])[0]

            PasswordField = ([  Element                            
                                for  Element  in  WindowsPageRoot.Descendants()
                                if   isinstance( Element, app_elements.EditableElement )
                                if   getattr( Element, 'aria-label' ) == 'Password' 
                                for  Ancestor in  Element.Ancestors()
                                if   getattr( Ancestor, 'data-parent-id' ) == 'auth_method'
                                if   'hide' not in getattr( Ancestor, 'class' ) ])[0]
                            
            UsernameField.TypeKeys('Administrator')
            PasswordField.TypeKeys('admin')

            return True
    
    
    
    def Test( self ):
        
        if not self.Logon():
            print('Failed to logon')
            self.ExitApp()
            quit()

        if not self.CreateAllScans():
            print('Failed to create scans')
        
        while True:
            print('In waiting loop..')
            time.sleep(1)
            
        #self.ExitApp()
        #quit()
    


def SignalHandler(Signal, Frame):
    # Pause()
    sys.exit(0)

def Main():

    MyTestApp = TenableApp()
    MyTestApp.Test()
    

if __name__ == '__main__':

    signal.signal(signal.SIGINT, SignalHandler)
    signal.signal(signal.SIGBREAK, SignalHandler)

              
    Main()

    


