import  sys, os
from    enum import Enum
from    selenium.webdriver.common.devtools.v110 import *

Driver                  = None
App                     = None
CurrentPageName         = None
CurrentPage             = None
CurrentActivity         = None
DevToolsFunc            = None
#AsyncEventConnection    = None
#AsyncCommandConnection  = None

# app_config.CurrentPage.PageElementTree

class NodeTypes(Enum):

    ELEMENT_NODE                = 1
    ATTRIBUTE_NODE              = 2
    TEXT_NODE                   = 3
    CDATA_SECTION_NODE          = 4
    ENTITY_REFERENCE_NODE       = 5
    ENTITY_NODE                 = 6
    PROCESSING_INSTRUCTION_NODE = 7
    COMMENT_NODE                = 8
    DOCUMENT_NODE               = 9
    DOCUMENT_TYPE_NODE          = 10
    DOCUMENT_FRAGMENT_NODE      = 11
    NOTATION_NODE               = 12
    
    DOCUMENT_POSITION_DISCONNECTED              = 1
    DOCUMENT_POSITION_PRECEDING                 = 2
    DOCUMENT_POSITION_FOLLOWING                 = 4
    DOCUMENT_POSITION_CONTAINS                  = 8
    DOCUMENT_POSITION_CONTAINED_BY              = 16
    DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC   = 32
...


# DevToolsEvents

class Container():

    def __iter__( self ):
        #print("iter called")
        self._ChildList = []
        for Key, Value in self.__dict__.items():
            #print("iter key in self dict: " + Key)
            if 'Element' in Value.__class__.__name__:
                self._ChildList.append( Value )
        return self
        
    def __next__( self ):    
        #print("next called")
        if len( self._ChildList ) > 0:
            return self._ChildList.pop( 0 )
        else:
            del self._ChildList
            raise StopIteration
    
    def __len__( self ):
        #print("len called")
        Length = 0
        for Key, Value in self.__dict__.items():
            if 'Element' in Value.__class__.__name__:
                Length += 1
        return Length
        
    def __contains__( self, SubStr ):
        for Key, Value in self.__dict__.items():
            if SubStr in Key:
                return True
        return False
        


DevToolsEvents = ((  
    accessibility.LoadComplete,
    accessibility.NodesUpdated,
    animation.AnimationCanceled,
    animation.AnimationCreated,
    animation.AnimationStarted,
    audits.IssueAdded,
    background_service.RecordingStateChanged,
    background_service.BackgroundServiceEventReceived,
    browser.DownloadWillBegin,
    browser.DownloadProgress,
    cast.SinksUpdated,
    cast.IssueUpdated,
    console.MessageAdded,
    css.FontsUpdated,
    css.MediaQueryResultChanged,
    css.StyleSheetAdded,
    css.StyleSheetChanged,
    css.StyleSheetRemoved,
    database.AddDatabase,
    debugger.BreakpointResolved,
    debugger.Paused,
    debugger.Resumed,
    debugger.ScriptFailedToParse,
    debugger.ScriptParsed,
    dom.AttributeModified,
    dom.AttributeRemoved,
    dom.CharacterDataModified,
    dom.ChildNodeCountUpdated,
    dom.ChildNodeInserted,
    dom.ChildNodeRemoved,
    dom.DistributedNodesUpdated,
    dom.DocumentUpdated,
    dom.InlineStyleInvalidated,
    dom.PseudoElementAdded,
    dom.TopLayerElementsUpdated,
    dom.PseudoElementRemoved,
    dom.SetChildNodes,
    dom.ShadowRootPopped,
    dom.ShadowRootPushed,
    dom_storage.DomStorageItemAdded,
    dom_storage.DomStorageItemRemoved,
    dom_storage.DomStorageItemUpdated,
    dom_storage.DomStorageItemsCleared,
    emulation.VirtualTimeBudgetExpired,
    fetch.RequestPaused,
    fetch.AuthRequired,
    heap_profiler.AddHeapSnapshotChunk,
    heap_profiler.HeapStatsUpdate,
    heap_profiler.LastSeenObjectId,
    heap_profiler.ReportHeapSnapshotProgress,
    heap_profiler.ResetProfiles,
    input_.DragIntercepted,
    inspector.Detached,
    inspector.TargetCrashed,
    inspector.TargetReloadedAfterCrash,
    layer_tree.LayerPainted,
    layer_tree.LayerTreeDidChange,
    log.EntryAdded,
    media.PlayerPropertiesChanged,
    media.PlayerEventsAdded,
    media.PlayerMessagesLogged,
    media.PlayerErrorsRaised,
    media.PlayersCreated,
    network.DataReceived,
    network.EventSourceMessageReceived,
    network.LoadingFailed,
    network.LoadingFinished,
    network.RequestIntercepted,
    network.RequestServedFromCache,
    network.RequestWillBeSent,
    network.ResourceChangedPriority,
    network.SignedExchangeReceived,
    network.ResponseReceived,
    network.WebSocketClosed,
    network.WebSocketCreated,
    network.WebSocketFrameError,
    network.WebSocketFrameReceived,
    network.WebSocketFrameSent,
    network.WebSocketHandshakeResponseReceived,
    network.WebSocketWillSendHandshakeRequest,
    network.WebTransportCreated,
    network.WebTransportConnectionEstablished,
    network.WebTransportClosed,
    network.RequestWillBeSentExtraInfo,
    network.ResponseReceivedExtraInfo,
    network.TrustTokenOperationDone,
    network.SubresourceWebBundleMetadataReceived,
    network.SubresourceWebBundleMetadataError,
    network.SubresourceWebBundleInnerResponseParsed,
    network.SubresourceWebBundleInnerResponseError,
    network.ReportingApiReportAdded,
    network.ReportingApiReportUpdated,
    network.ReportingApiEndpointsChangedForOrigin,
    overlay.InspectNodeRequested,
    overlay.NodeHighlightRequested,
    overlay.ScreenshotRequested,
    overlay.InspectModeCanceled,
    page.DomContentEventFired,
    page.FileChooserOpened,
    page.FrameAttached,
    page.FrameClearedScheduledNavigation,
    page.FrameDetached,
    page.FrameNavigated,
    page.DocumentOpened,
    page.FrameResized,
    page.FrameRequestedNavigation,
    page.FrameScheduledNavigation,
    page.FrameStartedLoading,
    page.FrameStoppedLoading,
    page.DownloadWillBegin,
    page.DownloadProgress,
    page.InterstitialHidden,
    page.InterstitialShown,
    page.JavascriptDialogClosed,
    page.JavascriptDialogOpening,
    page.LifecycleEvent,
    page.BackForwardCacheNotUsed,
    page.PrerenderAttemptCompleted,
    page.LoadEventFired,
    page.NavigatedWithinDocument,
    page.ScreencastFrame,
    page.ScreencastVisibilityChanged,
    page.WindowOpen,
    page.CompilationCacheProduced,
    performance.Metrics,
    performance_timeline.TimelineEventAdded,
    profiler.ConsoleProfileFinished,
    profiler.ConsoleProfileStarted,
    profiler.PreciseCoverageDeltaUpdate,
    runtime.BindingCalled,
    runtime.ConsoleAPICalled,
    runtime.ExceptionRevoked,
    runtime.ExceptionThrown,
    runtime.ExecutionContextCreated,
    runtime.ExecutionContextDestroyed,
    runtime.ExecutionContextsCleared,
    runtime.InspectRequested,
    security.CertificateError,
    security.VisibleSecurityStateChanged,
    security.SecurityStateChanged,
    service_worker.WorkerErrorReported,
    service_worker.WorkerRegistrationUpdated,
    service_worker.WorkerVersionUpdated,
    storage.CacheStorageContentUpdated,
    storage.CacheStorageListUpdated,
    storage.IndexedDBContentUpdated,
    storage.IndexedDBListUpdated,
    storage.InterestGroupAccessed,
    storage.SharedStorageAccessed,
    target.AttachedToTarget,
    target.DetachedFromTarget,
    target.ReceivedMessageFromTarget,
    target.TargetCreated,
    target.TargetDestroyed,
    target.TargetCrashed,
    target.TargetInfoChanged,
    tethering.Accepted,
    tracing.BufferUsage,
    tracing.DataCollected,
    tracing.TracingComplete,
    web_audio.ContextCreated,
    web_audio.ContextWillBeDestroyed,
    web_audio.ContextChanged,
    web_audio.AudioListenerCreated,
    web_audio.AudioListenerWillBeDestroyed,
    web_audio.AudioNodeCreated,
    web_audio.AudioNodeWillBeDestroyed,
    web_audio.AudioParamCreated,
    web_audio.AudioParamWillBeDestroyed,
    web_audio.NodesConnected,
    web_audio.NodesDisconnected,
    web_audio.NodeParamConnected,
    web_audio.NodeParamDisconnected,
    web_authn.CredentialAdded,
    web_authn.CredentialAsserted, ))
