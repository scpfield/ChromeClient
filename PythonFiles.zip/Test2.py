import sys, os


mydata = {
 "method": "Runtime.consoleAPICalled",
 "params": {
  "type": "log",
  "args": [
   {
    "type": "object",
    "className": "Object",
    "description": "Object",
    "objectId": "7033870105689552956.4.95050",
    "preview": {
     "type": "object",
     "description": "Object",
     "overflow": False,
     "properties": [
      {
       "name": "EventType",
       "type": "string",
       "value": "pointermove"
      }
     ]
    }
   },
   {
    "type": "object",
    "className": "Object",
    "description": "Object",
    "objectId": "7033870105689552956.4.95051",
    "preview": {
     "type": "object",
     "description": "Object",
     "overflow": False,
     "properties": [
      {
       "name": "TargetObj",
       "type": "object",
       "value": "body.nosession-wrapper",
       "subtype": "node"
      }
     ]
    }
   },
   {
    "type": "object",
    "className": "Object",
    "description": "Object",
    "objectId": "7033870105689552956.4.95052",
    "preview": {
     "type": "object",
     "description": "Object",
     "overflow": False,
     "properties": [
      {
       "name": "TargetName",
       "type": "string",
       "value": "BODY"
      }
     ]
    }
   },
   {
    "type": "object",
    "className": "Object",
    "description": "Object",
    "objectId": "7033870105689552956.4.95053",
    "preview": {
     "type": "object",
     "description": "Object",
     "overflow": False,
     "properties": [
      {
       "name": "TargetID",
       "type": "undefined",
       "value": "undefined"
      }
     ]
    }
   } ] } }
   


for Value in ['EventType', '
EventType =  [ Item.get('value')
                for  Arg in mydata.get('params').get('args')
                for  Item in Arg.get('preview').get('properties')
                if   Item.get('name') == 'EventType' ]




   
#for arg in mydata.get('params').get('args'):

#    for .get('preview').get('properties'):

   # for item in arg.get('preview').get('properties'):
        
#        print(arg)
