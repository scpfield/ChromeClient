import sys, os, re, json, copy, msvcrt
from colorama import init, Fore, Back, Style
from datetime import datetime
from datetime import timedelta

Options = {}
SyncMap = {}

action = 'action'
actionType = 'actionType'
altitude = 'altitude'
api = 'api'
assignedId = 'assignedId'
assignment = 'assignment'
azimuth = 'azimuth'
caption = 'caption'
capture_date = 'capture_date'
bucket = 'bucket'
path = 'path'
deleteProjects = 'deleteProjects'
description = 'description'
scclass = 'class' 
client = 'client'
controller = 'controller'
elevation_angle = 'elevation_angle'
fieldGroupId = 'fieldGroupId'
field_id = 'field_id'
groupEntryUuid = 'groupEntryUuid'
granteeMicrosite = 'granteeMicrosite'
projectId = 'projectId'
iOS = 'iOS'
iPadOS = 'iPadOS'
sync_id = 'sync_id'
id = 'id'
image = 'image'
image_version = 'image_version'
include_archived = 'include_archived'
isArchived = 'isArchived'
JSON = 'JSON'
last_template_download = 'last_template_download'
last_type_download = 'last_type_download'
latitude = 'latitude'
level = 'level'
longitude = 'longitude'
make = 'make'
marketList = 'marketList'
masterId = 'masterId'
max = 'max'
microsite = 'microsite'
model = 'model'
marketId = 'marketId'
msg = 'msg'
number_fields = 'number_fields'
number_media = 'number_media'
number_projects = 'number_projects'
offset = 'offset'
options = 'options'
order = 'order'
overrideProjectGrants = 'overrideProjectGrants'
placeholder = 'placeholder'
project = 'project'
reportId = 'reportId'
project_id = 'project_id'
source = 'source'
sku = 'sku'
search = 'search'
send = 'send'
sentToConsumer = 'sentToConsumer'
size = 'size'
sort = 'sort'
square = 'square'
statusList = 'statusList'
success = 'success'
syncID = 'syncID'
syncStatus = 'syncStatus'
thread = 'thread'
include_media = 'include_media'
field_keys = 'field_keys'
timestamp = 'timestamp'
token = 'token'
url = 'url'
user = 'user'
username = 'username'
uuid = 'uuid'
version = 'version'
templateDescription = 'templateDescription'
timestamp_str = 'timestamp_str'
originals = 'originals'
folders = 'folders'
timestampedPhotos = 'timestampedPhotos'
flaggedPhotos = 'flaggedPhotos'
data = 'data'
login_error = 'login_error'
watermark = 'watermark'
documents = 'documents'
userName = 'userName'
role = 'role'
file = 'file'
v243 = 'v243'
force = 'force'
fieldId = 'fieldId'
report_key = 'report_key'
defaultValue = 'defaultValue'
action_update = 'action_update'
action_update1 = '_action_update'
enabledOnly = 'enabledOnly'
enabledChoice = 'enabledChoice'
customerChoice = 'customerChoice'
include_project_summary = 'include_project_summary'
trialChoice = 'trialChoice'
searchTerm = 'searchTerm'
field_keys = 'field_keys'
features = 'features'
features1 = '['
CONDITIONAL_FIELDS = 'CONDITIONAL_FIELDS'
TYPE_MANAGEMENT = 'TYPE_MANAGEMENT'
ADVANCED_WORKFLOW = 'ADVANCED_WORKFLOW'
USER_SUBSCRIPTION_MANAGEMENT = 'USER_SUBSCRIPTION_MANAGEMENT'
REPORT_SHARE_LINK = 'REPORT_SHARE_LINK'
VENDOR_ASSIGNMENT = 'VENDOR_ASSIGNMENT'
SERVICE_MANAGEMENT = 'SERVICE_MANAGEMENT'
ACTIVITY_LOG = 'ACTIVITY_LOG'
HIGH_RES_PHOTOS = 'HIGH_RES_PHOTOS'
CONTAINERS_ON_MOBILE = 'CONTAINERS_ON_MOBILE'
VENDORS_CAN_CREATE = 'VENDORS_CAN_CREATE'
REPORT_CONFIG_UI = 'REPORT_CONFIG_UI'
MARKETS_REGIONS = 'MARKETS_REGIONS'
INTEGRATION = 'INTEGRATION'
SALESFORCE_INTEGRATION = 'SALESFORCE_INTEGRATION'
IMAGE_QUALITY = 'IMAGE_QUALITY'
PROJECT_DELETION = 'PROJECT_DELETION'
USER_TAGGING = 'USER_TAGGING'
CUSTOMER_MANAGEMENT = 'CUSTOMER_MANAGEMENT'
WATERMARK_PHOTOS = 'WATERMARK_PHOTOS'
DATA_VIEWS = 'DATA_VIEWS'
TENANT_INSPECTIONS = 'TENANT_INSPECTIONS'
GENERATE_URL = 'GENERATE_URL'
GENERATE_CUSTOMER_URL = 'GENERATE_CUSTOMER_URL'
REPORT_COLUMNS = 'REPORT_COLUMNS'
COPY_USER_VIEWS = 'COPY_USER_VIEWS]'
userRoles1 = '_userRoles'
userRoles = 'userRoles'
CUSTOMER = 'CUSTOMER'
WORKER = 'WORKER'
READ_ONLY_MANAGER = 'READ_ONLY_MANAGER'
MANAGER = 'MANAGER'
BASIC_ADMIN = 'BASIC_ADMIN]'
name = 'name'
description = 'description'
enabled1 = '_enabled'
enabled = 'enabled'
_customer = '_customer'
customer = 'customer'
_isTrial = '_isTrial'
isTrial = 'isTrial'
userName = 'userName'
numberOfPaidUsers = 'numberOfPaidUsers'
trialExpirationDate = 'trialExpirationDate'
trialExpirationDate_day = 'trialExpirationDate_day'
trialExpirationDate_month = 'trialExpirationDate_month'
trialExpirationDate_year = 'trialExpirationDate_year'
billingId = 'billingId'
application = 'application'
industry = 'industry'
hostNamePrefix = 'hostNamePrefix'
apiKey = 'apiKey'
apiThrottle1 = '_apiThrottle'
apiThrottle = 'apiThrottle'
timezone = 'timezone'
reportUrlExpirationDays = 'reportUrlExpirationDays'
projectDisplayName = 'projectDisplayName'
priorityType = 'priorityType'
showLabelsForHiddenConditionalFields1 = '_showLabelsForHiddenConditionalFields'
showLabelsForHiddenConditionalFields = 'showLabelsForHiddenConditionalFields'
canCreateFromMobile1 = '_canCreateFromMobile'
canCreateFromMobile = 'canCreateFromMobile'
canShareFromMobile1 = '_canShareFromMobile'
canShareFromMobile = 'canShareFromMobile'
allowAlbumPhotos1 = '_allowAlbumPhotos'
allowAlbumPhotos = 'allowAlbumPhotos'
maxProjectsMobile = 'maxProjectsMobile'
filterCompletedProjectsMobile1 = '_filterCompletedProjectsMobile'
mobileFilterStates = 'mobileFilterStates'
sortFieldMobile = 'sortFieldMobile'
sortAscendingMobile1 = '_sortAscendingMobile'
sortAscendingMobile = 'sortAscendingMobile'
showCompleteSyncingProjectsMobile1 = '_showCompleteSyncingProjectsMobile'
showCompleteSyncingProjectsMobile = 'showCompleteSyncingProjectsMobile'
aspectRatio = 'aspectRatio'
imageQuality = 'imageQuality'
restrictAdminProjectsOnMobile1 = '_restrictAdminProjectsOnMobile'
reportFolder = 'reportFolder'
reportFormat = 'reportFormat'
logo = 'logo'
custom1 = 'custom1'
custom2 = 'custom2'
custom3 = 'custom3'
custom4 = 'custom4'
consumerEmailSchedule = 'consumerEmailSchedule'
_features = '_features'
returning_token = 'returning token'
_vendorOnly = '_vendorOnly'
micrositeId = 'micrositeId'
userRealName = 'userRealName'
title = 'title'
externalId = 'externalId'
_archived = '_archived'
userRoleDisplay = 'userRoleDisplay'
_action_Update = '_action_Update'
email = 'email'
editUsername = 'editUsername'
key = 'key'
typeId = 'typeId'

t = 't'
POST = 'POST'
PUT = 'PUT'
DELETE = 'DELETE'
ONE = '1'
TWO = '2'
BRACKET = '['
THREE = '3'
FOUR = '4'
FIVE = '5'
SIX = '6'
SEVEN = '7'
EIGHT = '8'
F = 'F'
pp = 'pp'



NameValues  =   [action, actionType, altitude, api, assignedId, assignment, azimuth, caption, 
                capture_date, scclass, client, controller, elevation_angle, fieldGroupId, field_id, 
                groupEntryUuid, id, iOS, iPadOS, image, image_version, include_archived, isArchived, JSON, 
                last_template_download, last_type_download, latitude, level, longitude, make, 
                marketList, projectId, fieldId, masterId, max, microsite, model, msg, number_fields, number_media, 
                number_projects, offset, options, order, overrideProjectGrants, placeholder, 
                defaultValue, project, project_id, search, send, include_project_summary, include_media, sentToConsumer, 
                size, sort, field_keys, report_key, square, statusList, 
                success, syncID, syncStatus, thread, timestamp, token, url, user, username, uuid, 
                version, granteeMicrosite, t, login_error, originals, folders, timestampedPhotos, flaggedPhotos, data, bucket, path,
                watermark, marketId, userName, documents, file, v243, timestamp_str, role, reportId, v243, deleteProjects,
                enabledOnly, source, sku, enabledChoice, customerChoice, trialChoice, searchTerm, force,
                templateDescription, action_update, action_update1, sync_id,
                features,userRoles1,userRoles,CUSTOMER,WORKER,READ_ONLY_MANAGER,MANAGER,BASIC_ADMIN,name,description,
                enabled1,enabled,_customer,customer,isTrial,_isTrial,numberOfPaidUsers,trialExpirationDate,trialExpirationDate_day,
                trialExpirationDate_month,trialExpirationDate_year,billingId,application,industry,hostNamePrefix,apiKey,apiThrottle1,
                apiThrottle,timezone,reportUrlExpirationDays,projectDisplayName,priorityType,showLabelsForHiddenConditionalFields1,
                showLabelsForHiddenConditionalFields,canCreateFromMobile1,canCreateFromMobile,canShareFromMobile1,canShareFromMobile,
                allowAlbumPhotos1,allowAlbumPhotos,maxProjectsMobile,filterCompletedProjectsMobile1,mobileFilterStates,
                sortFieldMobile,sortAscendingMobile1,sortAscendingMobile,showCompleteSyncingProjectsMobile1,
                showCompleteSyncingProjectsMobile,aspectRatio,imageQuality,restrictAdminProjectsOnMobile1,reportFolder,reportFormat,
                logo,custom1,custom2,custom3,custom4,consumerEmailSchedule, returning_token, _vendorOnly,
                micrositeId, userRealName, userRealName, title, externalId, _archived, userRoleDisplay, _action_Update,
                email, editUsername, features1, _features, key, typeId]
                
JunkNames   =   [ pp, F, POST, PUT, DELETE, ONE, BRACKET, TWO, FOUR, THREE, SIX, FIVE, SEVEN, EIGHT,CONDITIONAL_FIELDS,TYPE_MANAGEMENT,ADVANCED_WORKFLOW,USER_SUBSCRIPTION_MANAGEMENT,REPORT_SHARE_LINK,VENDOR_ASSIGNMENT,SERVICE_MANAGEMENT,ACTIVITY_LOG,HIGH_RES_PHOTOS,CONTAINERS_ON_MOBILE,VENDORS_CAN_CREATE,REPORT_CONFIG_UI,MARKETS_REGIONS,INTEGRATION,SALESFORCE_INTEGRATION,IMAGE_QUALITY,PROJECT_DELETION,USER_TAGGING,CUSTOMER_MANAGEMENT,WATERMARK_PHOTOS,DATA_VIEWS,TENANT_INSPECTIONS,GENERATE_URL,GENERATE_CUSTOMER_URL,REPORT_COLUMNS,COPY_USER_VIEWS]


Line1 = [ success, api, action, scclass, controller ]
Line2 = [ user, microsite, project, client, make, model ]


def Find( SearchTerm, Data, WordMatch=False ):
    Expression = ''
    if WordMatch:
        Expression = '\b' + SearchTerm + '\b'
    else:
        Expression = SearchTerm
    CleanData = str(Data).strip()
    Result = re.search(Expression, CleanData, flags=re.IGNORECASE)
    # print(Result)
    if (Result):
        return True
    else:
        return False


def Pause():
    while not msvcrt.kbhit():
        key = msvcrt.getch()
        break

                
def ParseLine(Line):
        
    LineSplit = Line.split('|')    
    if (len(LineSplit) < 4):
        return None

    #print("-------------------------")
    #print(str(LineSplit))
    
    # First pass, cleanup whitespace
    for Idx in range(0, len(LineSplit)):
        Item = str(LineSplit[Idx])
        Item = Item.strip().strip("\n").strip('\n').strip('\r')
        LineSplit[Idx] = Item
    
    # Next pass, process the sub-data
    LineArray = []
    # print(str(LineSplit))
    for Idx in range(0, len(LineSplit)):
        if ( ('[' in LineSplit[Idx]) and
             (',' in LineSplit[Idx]) and
             (':' in LineSplit[Idx]) ):
                
                if ((LineSplit[3] == 'com.fotobabble.interceptors.APIInterception') or
                    (LineSplit[3] == 'grails.app.controllers.after') or 
                    (LineSplit[3] == 'grails.app.controllers.before')):
                        SubSplit = LineSplit[Idx].split(',')
                        for SubIdx in range(0, len(SubSplit)):
                            SubItem = str(SubSplit[SubIdx])
                            SubItem = SubItem.strip().strip("\n").strip('\n').strip('\r')
                            if ('] JSON' in SubItem):
                                SubItemSplit = SubItem.split('] ')
                                if (len(SubItemSplit) > 1):
                                    LineArray.append(SubItemSplit[0].strip())  # id:
                                    LineArray.append(SubItemSplit[1].strip())  # JSON:
                                    #print("Found JSON, adding: " + str(SubItemSplit[1]))
                                    continue
                            # print("Adding SubItem: " + str(SubItem))
                            LineArray.append(SubItem)
        
        elif (  (Idx == 3) and 
                (LineSplit[Idx] == 'com.fotobabble.api.mobile.LogApiController')):
                    LineArray.append(LineSplit[Idx])
                    #print("Found LogApiController")
                    SubSplit = LineSplit[Idx+1].split(',')
                    for SubIdx in range(0, len(SubSplit)):
                        SubItem = str(SubSplit[SubIdx])
                        SubItem = SubItem.strip().strip("\n").strip('\n').strip('\r')
                        #print("Adding Subitem = " + str(SubItem))
                        LineArray.append(SubItem)
                        # Pause()
                            
        elif ((len(LineSplit) == 11) and (Idx == 4)):
            
            LineArray.append(LineSplit[Idx])
            
            if 'new show project ID' in LineSplit[Idx]:
                ProjectID = LineSplit[Idx].split('new show project ID')[1].strip()
                LineArray.append('project:' + ProjectID)
                #print("adding project to LineArray")
                #print(str(LineArray))
            elif '403 error' in LineSplit[Idx]:
                if ('id:') in LineSplit[Idx]:
                    ProjectID = LineSplit[Idx].split('id:')[1].split(')')[0].strip()
                    LineArray.append('project:' + ProjectID)
                    
            '''
            if (LineSplit[3] == 'com.fotobabble.notification.StatusChangeNotificationService'):
                LineArray.append(LineSplit[Idx])
                print("StatusChangeNotificationService")
                # exit()
            if (LineSplit[3] == 'com.fotobabble.project.ProjectService'):
                LineArray.append(LineSplit[Idx])
                print("com.fotobabble.project.ProjectService")
                # exit()
            '''    
            #else:
            #    SubSplit = LineSplit[4].split(',')
            #    LineArray.extend(SubSplit)
        else:
            LineArray.append(LineSplit[Idx])
   
    
    # Next pass, handle more odds and ends
    for Idx in range(0, len(LineArray)):        
        Item = LineArray[Idx]
        if ((Item.startswith('[')) and 
            (']' not in Item)):
                LineArray[Idx] = Item.strip('[')
        if ((Item.endswith(']')) and 
            ('[' not in Item)):
                LineArray[Idx] = Item.strip(']')
        if (Item.endswith('{')):
            LineArray[Idx] = LineArray[Idx] + '}'
        if (Item.startswith('JSON: ')):
            LineArray[Idx] = Item.replace('JSON: ', 'JSON:')

    if (len(LineArray) < 8):
        return None

    #print("-------------------")
    #print(str(LineArray))
    #print("--------------------")
    
    # Make timestamp
    DateTimeStr = ( LineArray[0].split()[-2].strip() + ' ' +
                    LineArray[0].split()[-1].strip() )
    DateTimeObj =   datetime.strptime(DateTimeStr, '%Y-%m-%d %H:%M:%S,%f')
    
    # Add names to items in array that need it
    LineArray[0] = 'timestamp:' + str(DateTimeObj)    
    LineArray[1] = 'thread:'    + LineArray[1].strip('[').strip(']')
    LineArray[2] = 'level:'     + LineArray[2]
    LineArray[3] = 'class:'     + LineArray[3]    
  
    if (('action:' not in LineArray[4]) and
        ('controller:' not in LineArray[4]) and
        ('masterId:' not in LineArray[4]) and
        ('syncID:' not in LineArray[4]) and
        ('last_type_download:' not in LineArray[4]) and
        ('last_template_download:' not in LineArray[4]) and
        ('token:' not in LineArray[4]) and
        ('fieldGroupId:' not in LineArray[4]) and
        ('actionType:' not in LineArray[4])):
            if ('https' in LineArray[4]):
                LineArray[4] = 'url:' + LineArray[4]
            else:
                LineArray[4] = 'msg:' + LineArray[4]

    if (('action:' not in LineArray[5]) and
        ('controller:' not in LineArray[5]) and
        ('syncID:' not in LineArray[5]) and         
        ('masterId:' not in LineArray[5]) and
        ('actionType:' not in LineArray[5]) and
        ('square:' not in LineArray[5]) and
        ('project:' not in LineArray[5]) and
        ('microsite:' not in LineArray[5]) and
        ('number_fields:' not in LineArray[5]) and
        ('groupEntryUuid:' not in LineArray[5]) and
        ('JSON:' not in LineArray[5])):
            LineArray[5] = 'api:' + LineArray[5]

    # print(str(LineArray))
    # Split array items to make dictionary
    LineMap = {}
    LineMap['timestamp'] = DateTimeObj    
    for Idx in range(1, len(LineArray)):
        #print("Processing: " + str(LineArray[Idx]))
        #print(str(Line))
        
        if (':' in LineArray[Idx]):
        
            ItemSplit = LineArray[Idx].split(':', 1)
            
            if (len(ItemSplit) == 1):
                Name = ItemSplit[0].strip()
                if Name not in LineMap:
                    LineMap[Name] = ''
                if  ((Name not in NameValues) and
                     (Name not in JunkNames)):
                        print("1. FOUND NAME NOT DISCOVERED: '" + Name+ "'")
                        print(Line)
                        Pause()
                    
            elif (len(ItemSplit) == 2):
                Name = ItemSplit[0].strip().strip('[').strip(']')
                Value = ItemSplit[1].strip()
                if (Name == ''):
                    continue
                if Name not in LineMap:
                    LineMap[Name] = Value
                if  ((Name not in NameValues) and
                     (Name not in JunkNames)):
                        print("2. FOUND NAME NOT DISCOVERED: '" + Name + "'")
                        print("VALUE: '" + Value + "'")
                        print(Line)
                        Pause()
        else:
            #print(LineArray[Idx])
            Value = LineArray[Idx]
            Name = ''
            if 'iOS' in Value:
                Name = 'iOS'
            if 'iPadOS' in Value:
                Name = 'iPadOS'
            #Value = ''
            #if (len(LineArray[Idx]) > 1):
                #print(str(LineArray[Idx]))
                #print(str(Line))
                #Value = LineArray[Idx][1].strip()
                
            if ((Name) and (Name not in LineMap)):
                LineMap[Name] = Value
            if  ((Name) and (Name not in NameValues) and
                 (Name not in JunkNames)):
                    print("3. FOUND NAME NOT DISCOVERED: '" + Name + "'")
                    print("VALUE: " + Value)
                    print(str(Line))                    
                    print(str(LineArray))
                    print(str(LineMap))
                    Pause()       
          
    if action in LineMap:
        LineMap[action] = LineMap[action].strip('[').strip(']')
        
    if 'JSON' in LineMap:
        pass
        #print("Found JSON in LineMap")
        #print("before: '" + LineMap[JSON]+"'")
        #if (LineMap[JSON] == '{}'):
        #    LineMap[JSON] = ''
        #print("after: " + LineMap[JSON])
        #exit()
            
    if msg in LineMap:
        if 'writing original image to s3' in LineMap[msg]:
            LineMap[bucket] = LineMap[msg].split()[5].split('=')[1]
            LineMap[file] = LineMap[msg].split()[6].split('=')[1]
            LineMap[msg] = ' '.join(LineMap[msg].split()[0:5])
        if 's3 file not found at' in LineMap[msg]:
            LineMap[file] = LineMap[msg].split()[5]
            LineMap[file] = LineMap[msg].split()[7]
            LineMap[msg] = ' '.join(LineMap[msg].split()[0:4]) 
        if 'WAITING FOR IMAGE' in LineMap[msg]:
            LineMap[file] = LineMap[msg].split()[3]
            LineMap[msg] = ' '.join(LineMap[msg].split()[0:3])
            
    #print(str(LineMap))
    #print(str(LineArray))
    #print(str(LineMap))
    #print("--------------------")
    #for key,value in LineMap.items():
    #    print(key)
    #print("--------------------")
    
    return(LineMap)
    

def AddEmptyMapItems(LineMap):

    if (not LineMap):
        return
        
    for Name in NameValues:
        if (Name not in LineMap):
            #print("Adding: " + str(Name))
            LineMap[Name] = ''
        else:
            pass
            #print("Exists already: " + str(Name))
    
    #print(str(LineMap))
    return

def Colorize(LineMap):
    
    if (not LineMap):
        print("Colorize: LineMap is None")
        exit()

    ColorizedMap = {}
    ColorizedMap = copy.deepcopy(LineMap)
    del ColorizedMap[timestamp]
    del ColorizedMap[level]
    
    for Item in ColorizedMap:
        ColorizedMap[Item] = ColorizedMap[Item].strip()
            
    DefaultStyle = Style.BRIGHT
    DefaultFore  = Fore.CYAN
    DefaultBack  = Back.BLACK

    FailedStyle = Style.BRIGHT
    FailedFore  = Fore.WHITE
    FailedBack  = Back.RED

    SuccessStyle = Style.BRIGHT
    SuccessFore  = Fore.GREEN
    SuccessBack  = Back.GREEN


    #
    # Overrides
    #

                                   
    # success/fail
    if (LineMap[success] == 'false'):

        ColorizedMap['timestamp_str'] = ( Style.NORMAL + Back.BLUE + Style.NORMAL + Fore.WHITE + 
                                        '[' + str(LineMap[timestamp]) + ']' + 
                                        Style.RESET_ALL + Back.RESET + Fore.RESET )  
                                        
        ColorizedMap[success] = '*FAILED*'
        
        for Name in Line1:        
           if LineMap[Name] != '':  
                ColorizedMap[Name] = ( Style.NORMAL + Back.RED + Style.BRIGHT + Fore.WHITE + 
                                    '[' + Name + ':' + LineMap[Name] + ']' + 
                                    Style.RESET_ALL + Back.RESET + Fore.RESET )
                                      
    if ((LineMap[success] == 'true') or 
        (LineMap[success] == '')):

            ColorizedMap['timestamp_str'] = ( Style.NORMAL + Back.BLUE + Style.BRIGHT + Fore.WHITE + 
                                            '[' + str(LineMap[timestamp]) + ']' + 
                                            Style.RESET_ALL + Back.RESET + Fore.RESET )    

            for Name in Line1:
                if LineMap[Name] != '':
                    ColorizedMap[Name] = ( Style.BRIGHT + Back.GREEN + Style.BRIGHT + Fore.YELLOW + 
                                        '[' + Name + ':' + LineMap[Name] + ']' + 
                                        Style.RESET_ALL + Back.RESET + Fore.RESET )
                                        
            ColorizedMap[success] = ''

    if (LineMap[Name] == 'null'):
        ColorizedMap[Name] = ( FailedStyle + FailedBack + FailedFore + 
                             '[' + Name + ':' + LineMap[Name] + ']' + 
                             Style.RESET_ALL + Back.RESET + Fore.RESET )

                                   
    # microsite, user, client, make, model
    for Name in Line2:
        if (LineMap[Name] != ''):
            ColorizedMap[Name] = ( Style.NORMAL + Back.BLACK + Style.BRIGHT + Fore.CYAN + 
                                 '[' + Name + ':' + LineMap[Name] + ']' + 
                                 Style.RESET_ALL + Back.RESET + Fore.RESET )
                                    
    # sync
    for Name in [syncID, number_projects, number_fields, number_media]:
        if (LineMap[Name] != ''):
            ColorizedMap[Name] = (Style.NORMAL + Back.BLACK + Style.BRIGHT + Fore.RED + 
                                 '[' + Name + ':' + LineMap[Name] + ']' + 
                                 Style.RESET_ALL + Back.RESET + Fore.RESET )

    if (ColorizedMap[actionType] != ''):
        ColorizedMap[actionType] = ( Style.NORMAL + Back.BLACK + Style.BRIGHT + Fore.RED + 
                                    '[' + actionType + ':' + LineMap[actionType] + ']' + 
                                    Style.RESET_ALL + Back.RESET + Fore.RESET )

    # all else
    for Name in ColorizedMap:
        if (('timestamp' not in Name) and
            (Name not in Line1) and
            (Name not in Line2) and
            (Name not in [actionType, syncID, number_projects, number_fields, number_media] )):
                if ( ColorizedMap[Name] != ''):
                    ColorizedMap[Name] = (  Style.NORMAL + Back.BLACK + Style.NORMAL + Fore.CYAN + 
                                            '[' + Name + ':' + LineMap[Name] + ']' + 
                                            Style.RESET_ALL + Back.RESET + Fore.RESET )


    for Item in ColorizedMap:
        ColorizedMap[Item] = ColorizedMap[Item].strip()
        
    return(ColorizedMap)
    
    
def ProcessSyncLine(LineMap, ColorizedMap, LogLine):
    global SyncMap
    
    DuplicateSyncStart = False
    DuplicateSyncEnd = False
    
    #if ('sync_start' in LogLine):
        #print(str(LogLine))
        #print(str(LineMap))
        #Pause()
        
    if ((LineMap[syncID] != '') and 
        (LineMap[actionType] != '')):
    
        #print(str(LogLine))
        #print(str(LineMap))
        #Pause()
        SyncID = LineMap[syncID]
        SyncAction = LineMap[actionType]
        Timestamp = LineMap[timestamp]
        
        if ((SyncID) and (SyncAction)):
        
            SyncIDSplit = LineMap[ syncID ][ ::-1 ].split( '_', 2 )
            Username = ''
            if ( len( SyncIDSplit ) > 2 ): 
                if ( len( SyncIDSplit[ 1 ] ) == 12 ):
                    SubSplit = SyncIDSplit[ -1 ].split( '_' , 4 ) 
                    if ( len( SubSplit ) > 4 ): 
                        Username = SubSplit[ -1 ][ ::-1 ] 
                        LineMap[make] = 'iOS'
                        ColorizedMap[make] = ( Style.BRIGHT + Back.BLACK + Fore.CYAN + 
                                                '[' + LineMap[make] + '] ' + Style.RESET_ALL)
                        LineMap[user] = Username
                        ColorizedMap[user] = ( Style.BRIGHT + Back.BLACK + Fore.CYAN + 
                                                '[' + LineMap[user] + '] ' + Style.RESET_ALL)
                                                
                elif ( len( SyncIDSplit[ 1 ] ) == 16 ): 
                    Username = SyncIDSplit[ -1 ][ ::-1 ]
                    LineMap[make] = 'Android'
                    ColorizedMap[make] =    ( Style.BRIGHT + Back.BLACK + Fore.CYAN + 
                                            '[' + LineMap[make] + '] ' + Style.RESET_ALL)
                    LineMap[user] = Username
                    ColorizedMap[user] = ( Style.BRIGHT + Back.BLACK + Fore.CYAN + 
                                            '[' + LineMap[user] + '] ' + Style.RESET_ALL)                                            
                    

            else: 
                pass
                #print( str( LogLine ))
                #Pause()
            
            if (Username == ''):
                print("Got empty/unparseable Username from SyncID")
                return
            
            if Username not in SyncMap:
                SyncMap[Username] = {}
                
            if (SyncID in SyncMap[Username]):
            
                if ((SyncAction not in SyncMap[Username][SyncID])):
                    SyncMap[Username][SyncID][SyncAction] = Timestamp
                else:
                    if 'sync_start' in SyncAction:
                        DuplicateSyncStart = True
                    if 'sync_end' in SyncAction:
                        DuplicateSyncEnd = True
            else:
                SyncMap[Username][SyncID] = {}
                SyncMap[Username][SyncID][SyncAction] = Timestamp
                
            DurationSec = ''
            DurationLabel = ''

            if ((not DuplicateSyncStart) and
                (not DuplicateSyncEnd)):
                
                if (('sync_start' in SyncMap[Username][SyncID]) and
                     ('sync_end' in SyncMap[Username][SyncID])):
                    
                        DurationSec = str(  (SyncMap[Username][SyncID]['sync_end'] -
                                             SyncMap[Username][SyncID]['sync_start'] ) )
                        DurationLabel = 'Duration = '
                                
            SyncDurationColor = Style.BRIGHT + Fore.YELLOW
            DuplicateSyncColor = Style.BRIGHT + Fore.RED
            DuplicateLabel = ''
            ColorizedDuplicateLabel = ''
            if ((DuplicateSyncStart) or (DuplicateSyncEnd)):
                DuplicateLabel = ' [DUPLICATE_ID] '
                ColorizedDuplicateLabel = DuplicateSyncColor + DuplicateLabel + Style.RESET_ALL

            SyncStartCount = 0
            SyncEndCount = 0
            OverlappedCount = 0
            UnderlappedCount = 0
            if ((not DuplicateSyncStart) and
                (not DuplicateSyncEnd)):
                    for SyncID in SyncMap[Username]:
                        for SyncAction in SyncMap[Username][SyncID]:
                            if 'sync_start' in SyncAction:
                                SyncStartCount += 1
                            elif 'sync_end' in SyncAction:
                                SyncEndCount += 1                
                        if (SyncStartCount - SyncEndCount > 1):
                            OverlappedCount += 1
                        if (SyncEndCount - SyncStartCount > 1):
                            UnderlappedCount += 1

            OverlappedLabel = ''
            UnderlappedLabel = ''
            ColorizedOverlappedLabel = ''
            ColorizedUnderlappedLabel = ''
            OverlappedSyncColor = Style.BRIGHT + Fore.RED
            UnderlappedSyncColor = Style.BRIGHT + Fore.RED
            if (OverlappedCount):
                OverlappedLabel = '[OVERLAPPED_SYNC]'
                ColorizedOverlappedLabel = OverlappedSyncColor + OverlappedLabel + Style.RESET_ALL
            if (UnderlappedCount):
                UnderlappedLabel = '[UNDERLAPPED_SYNC]'
                ColorizedUnderlappedLabel = UnderlappedSyncColor + UnderlappedLabel + Style.RESET_ALL
                
        
            print(( ColorizedMap[timestamp_str] + 
                    ColorizedMap[scclass] + '\n' + 
                    ColorizedMap[actionType] + ' ' +
                    ColorizedMap[user] + 
                    ColorizedMap[make] + 
                    ColorizedMap[thread] + 
                    ColorizedMap[success] +
                    ColorizedMap[number_projects] +
                    ColorizedMap[number_fields] +
                    ColorizedMap[number_media] +
                    ColorizedDuplicateLabel + ' ' +
                    ColorizedOverlappedLabel + ' ' +
                    ColorizedUnderlappedLabel + ' ' +
                    SyncDurationColor + DurationLabel + str(DurationSec) + '\n' +
                    ColorizedMap[syncID]  + ' ' + ColorizedMap[userName] + Style.RESET_ALL + Fore.RESET ))
        
        
            #print(str(SyncMap))
            #Pause()
            
            with open('output.csv', 'a', newline='', encoding='utf-8') as OutputFile:
            
                OutputFile.write(str(LineMap[timestamp]) + ',' +
                                    LineMap[user] + ',' +
                                    LineMap[make] + ',' +
                                    LineMap[actionType] + ',' + 
                                    LineMap[thread] + ',' +
                                    LineMap[number_projects].strip(']').strip('[') + ',' +
                                    LineMap[number_fields].strip(']').strip('[')  + ',' +
                                    LineMap[number_media] + ',' +
                                    LineMap[syncID] + ',' +
                                    DuplicateLabel.strip() + ',' +
                                    OverlappedLabel.strip() + ',' +
                                    str(DurationSec) + '\n')
                
            
            print('\n')
            #Pause()
            return(True)
    else:
        return(False)
        

def ProcessLine(LogLine):

    LineMap         = {}
    ColorizedMap    = {}

    LineMap = ParseLine(LogLine)
    
    if not LineMap:
        return False
    
    #print(str(LogLine))
    AddEmptyMapItems(LineMap)
    ColorizedMap = Colorize(LineMap)
    
    #if (ProcessSyncLine(LineMap, ColorizedMap, LogLine)):
    #    return True
    #else:
    #    if (Options['SyncOnly']):
    #        return True

    
    # excludes
    ColorizedMap['level'] = ''
    
    print( ColorizedMap['timestamp_str'] )
    
    PrintedSomething = False
    
    for Item in Line1:
        if ( ColorizedMap[Item] != '' ):
            PrintedSomething = True
            print( ColorizedMap[Item] + ' ', end='' )

    if (PrintedSomething):
        print()
        PrintedSomething = False
    
    for Item in Line2:
        if ( ColorizedMap[Item] != '' ):
            PrintedSomething = True
            print( ColorizedMap[Item] + ' ', end='' )

    if (PrintedSomething):
        print()
        PrintedSomething = False
    
    for Item in ColorizedMap:
        if ((Item not in Line1) and
            (Item not in Line2) and
            ('timestamp' not in Item)):
                if ( ColorizedMap[Item] != ''):
                    PrintedSomething = True
                    print( ColorizedMap[Item] + ' ' )
                
    if (PrintedSomething):
        print()
        PrintedSomething = False
    else:
        print()

    
# end ProcessLine


def ProcessStdIn():
    
    SyncMap = {}
    PrevSequenceID = 0
    StdInLine = sys.stdin.readline()

    while StdInLine:

        LogLine         = ''
        SequenceID      = 0
        
        StdInLine       = sys.stdin.readline()
        
        if (not StdInLine):
            continue
        
        if (len(StdInLine) < 100):
            continue

        JSONLine        = json.loads(StdInLine)
        
        # https://test.fotonotes.com/app/#/project/show/508589
        
        if 'events' not in JSONLine:             # processing a saved log file case
            if 'message' in JSONLine:   
                LogLine         = JSONLine['message']
                SequenceID      = int(JSONLine['id'])
                
                # Papertrail headers:
                # program, id, received_at, generated_at, display_received_at,
                # source_id, source_ip, source_name, hostname, severity, facility
                
                
                if JSONLine['program'] != 'fotonotes.log':
                    continue
                    print("")
                    print(Style.BRIGHT + Fore.YELLOW + JSONLine['program'] + ': ', end='')
                    print(Style.BRIGHT + Fore.CYAN + LogLine + Style.RESET_ALL + Fore.RESET)
                    print("")
                    
                if (Options['IgnoreChat']):
                    if ( Find('chat', LogLine )):
                            print()
                            print("*********************Ignoring chat line*******************")
                            print()
                            continue
                
                if ( Find('fotobabble.performance', LogLine)):
                    continue

                if ( Find('fotonotesnew.IntegrationPushJob|integration.IntegrationService|' + 
                          'fotonotesnew.SalesforcePullJob|fotonotesnew.JobServerCheckJob|' +
                          'system.ConfigurationService|fotobabble.net.HttpService|' +
                          'fotonotesnew.ConsumerReminderJob|notification.ConsumerEmailService', LogLine)):
                    continue
                    
                ProcessLine(LogLine)
            
        
        if 'events' in JSONLine:
            for Event in JSONLine['events']:
                
                LogLine         = Event['message']
                SequenceID      = int(Event['id'])
                
                # Papertrail headers:
                # program, id, received_at, generated_at, display_received_at,
                # source_id, source_ip, source_name, hostname, severity, facility
                
                
                if Event['program'] != 'fotonotes.log':
                    continue
                    print("")
                    print(Style.BRIGHT + Fore.YELLOW + Event['program'] + ': ', end='')
                    print(Style.BRIGHT + Fore.CYAN + LogLine + Style.RESET_ALL + Fore.RESET)
                    print("")
                    
                if (Options['IgnoreChat']):
                    if ( Find('chat', LogLine )):
                            print()
                            print("*********************Ignoring chat line*******************")
                            print()
                            continue
                
                if ( Find('fotobabble.performance', LogLine)):
                    continue

                if ( Find('fotonotesnew.IntegrationPushJob|integration.IntegrationService|' + 
                          'fotonotesnew.SalesforcePullJob|fotonotesnew.JobServerCheckJob|' +
                          'system.ConfigurationService|fotobabble.net.HttpService|' +
                          'fotonotesnew.ConsumerReminderJob|notification.ConsumerEmailService', LogLine)):
                    continue
                    
                ProcessLine(LogLine)
            
            
# end ProcessStdIn            
            

def PrintHelp():
    print("")
    print("Optional Arguments:")
    print("--microsite <name>")
    print("--user <name>")
    print("--project <name>")
    print("--ignorechat <true|false")
    print("--WordMatch <true|false>")
    print("")
    exit()

def PrintInvalidArg( Arg = '', ArgValue = '' ):
    print("")
    print("Invalid or missing argument")
    print("Arg: " + str(Arg))
    print("Arg Value: " + str(ArgValue))
    print("")
    print("Try --help")
    print("")
    exit()

def ParseArgs():

    global Options

    Options['Microsite'] = ''
    Options['User'] = ''
    Options['Project'] = ''
    Options['WordMatch'] = False
    Options['IgnoreChat'] = True
    Options['SyncOnly'] = False
    Options['FollowMode'] = False

    StartIndex = 1
    MaxIndex = ( len( sys.argv ) - 1)

    if ('--help' in sys.argv):
        PrintHelp()
        exit()

    if (MaxIndex % 2 != 0):
        PrintInvalidArg()

    for Index in range(StartIndex, MaxIndex):

        Arg         = sys.argv[Index]
        ArgValue = sys.argv[Index + 1]

        if ('--' not in Arg):
            continue

        if  ('--' in Arg) and (
            ('--' in ArgValue) or
            (ArgValue == '')):
                PrintInvalidArg(Arg, ArgValue)
                exit()

        if ('--microsite' in Arg):
            Options['Microsite'] = ArgValue

        elif ('--user' in Arg):
            Options['User'] = ArgValue

        elif ('--project' in Arg):
            Options['Project'] = ArgValue

        elif ('--WordMatch' in Arg):
            if ( ('true' in ArgValue) or ('True' in ArgValue)):
                Options['WordMatch'] = True
                continue
            if ( ('false' in ArgValue) or ('False' in ArgValue)):
                Options['WordMatch'] = False
                continue
            PrintInvalidArg(Arg, ArgValue)
            exit()
            
        elif ('--followmode' in Arg):
            if ( ('true' in ArgValue) or ('True' in ArgValue)):
                Options['FollowMode'] = True
                continue
            if ( ('false' in ArgValue) or ('False' in ArgValue)):
                Options['FollowMode'] = False
                continue
            PrintInvalidArg(Arg, ArgValue)
            exit()            

        elif ('--synconly' in Arg):
            if ( ('true' in ArgValue) or ('True' in ArgValue)):
                Options['SyncOnly'] = True
                continue
            if ( ('false' in ArgValue) or ('False' in ArgValue)):
                Options['SyncOnly'] = False
                continue
            PrintInvalidArg(Arg, ArgValue)
            exit()

        elif ('--ignorechat' in Arg):
            if ( ('true' in ArgValue) or ('True' in ArgValue)):
                Options['IgnoreChat'] = True
                continue
            if ( ('false' in ArgValue) or ('False' in ArgValue)):
                Options['IgnoreChat'] = False
                continue
            PrintInvalidArg(Arg, ArgValue)
            exit()
            
# End ParseArgs





# Start of main
init(autoreset=True)
print("")
ParseArgs()
print(str(Options))
ProcessStdIn()

print("")
