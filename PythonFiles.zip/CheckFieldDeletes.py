import sys, os, subprocess, json
from datetime import datetime
from datetime import timedelta

InputFile               = ""
OutputFile              = ""

def CheckFieldDeletes():

    global InputFile
    global OutputFile
    
    print("Loading: " + InputFile)
    
    with open(InputFile, 'r', newline='', encoding='utf-8') as DataFile:
        
        FieldList = []
        FieldMap = {}
        
        for Line in DataFile:
            
            SplitByPipe = Line.split('|')
            CommaLine = ''.join(SplitByPipe).replace('\n', '').replace('\r','')
            SplitByCommaLine = CommaLine.split(',')
            OpenBracketLine =  ''.join(SplitByCommaLine).replace('\n', '').replace('\r','')
            SplitByOpenBracket = OpenBracketLine.split('[')
            CloseBracketLine = ''.join(SplitByOpenBracket).replace('\n', '').replace('\r','')
            SplitByCloseBracket =  CloseBracketLine.split(']')
            Line = ''.join(SplitByCloseBracket).replace('\n', '').replace('\r','')
            SplitLine = Line.split()
            Line = ' '.join(SplitLine).replace('\n', '').replace('\r','')
            TmpSplitLine = Line.split(':')
            TmpLine = ' '.join(TmpSplitLine)
            LookupSplitLine = TmpLine.split(':')
            LookupLine = ' '.join(LookupSplitLine)
            LookupSplitLine = LookupLine.split()


            DateStr = None
            TimeStr = None            
            if (len(SplitLine) > 2):
                DateStr = str(SplitLine[0]).strip()
                TimeStr = str(SplitLine[1]).strip()
            else:
                print("Line too short")
                continue
            
            Timestamp = datetime.fromisoformat(DateStr + " " + TimeStr)
            FieldId = ""
            UserId = ""
            ProjectId = ""
            MasterId = ""
            UUID = ""
            SyncStatus = 0
            Status = 0

            if ('imagePost.addMediaToField' in Line):

                # Find the field_id, break as soon as we found it
                for idx in range(0, len(SplitLine)):
                    if ('field_id' in SplitLine[idx]):
                        ColonSplit = SplitLine[idx].strip().split(':')
                        if (len(ColonSplit) > 1):
                            FieldId = ColonSplit[1]
                            FieldMap[FieldId] = {}
                            break

                if not FieldId:
                    print("No field_id in addMediaToField line")
                    continue
                    
                # Loop again to find success/fail
                for idx in range(0, len(SplitLine)):
                    if ('success:true' in SplitLine[idx]):
                        FieldMap[FieldId]["Success"] = [str(Timestamp),Line]
                        Status = 1
                        break
                    if ('success:false' in SplitLine[idx]):
                        FieldMap[FieldId]["Fail"] = [str(Timestamp),Line]
                        Status = 2
                        break
                    elif ('success:' in SplitLine[idx]):
                        FieldMap[FieldId]["Unknown"] = [str(Timestamp),Line]
                        Status = 3
                        break


                # Loop again to find UUID
                for idx in range(0, len(SplitLine)):
                    if ('uuid' in SplitLine[idx]):
                        ColonSplit = SplitLine[idx].strip().split('uuid:')
                        if (len(ColonSplit) > 0):
                            FieldMap[FieldId]['uuid'] = ColonSplit[0]
                            UUID = ColonSplit[0]
                            break
                            
                # Loop again to find SyncStatus
                for idx in range(0, len(SplitLine)):
                    if ('syncStatus' in SplitLine[idx]):
                        ColonSplit = SplitLine[idx].strip().split(':')
                        if (len(ColonSplit) > 1):
                            FieldMap[FieldId]['syncStatus'] = ColonSplit[1]
                            SyncStatus = ColonSplit[1]
                            break
                
                # Loop again to find masterID
                for idx in range(0, len(SplitLine)):
                    if ('masterId' in SplitLine[idx]):
                        ColonSplit = SplitLine[idx].strip().split(':')
                        if (len(ColonSplit) > 1):
                            MasterId = ColonSplit[1]
                            FieldMap[FieldId]['masterId'] = ColonSplit[1]
                            break
                            
                # Loop again to find project
                for idx in range(0, len(SplitLine)):
                    if ('project' in SplitLine[idx]):
                        ColonSplit = SplitLine[idx].strip().split(':')
                        if (len(ColonSplit) > 1):
                            ProjectId = ColonSplit[1]
                            FieldMap[FieldId]['project'] = ColonSplit[1]
                            #print(ProjectId)
                            break                      
    
                    # Loop again to find microsite
                for idx in range(0, len(SplitLine)):
                    if ('microsite' in SplitLine[idx]):
                        ColonSplit = SplitLine[idx].strip().split(':')
                        if (len(ColonSplit) > 1):
                            MicrositeIdxStart = LookupSplitLine.index('microsite')
                            UserIdxStart = LookupSplitLine.index('user')
                            Microsite = ""
                            for x in range(MicrositeIdxStart+1, UserIdxStart):
                                Microsite += LookupSplitLine[x] + " " 
                            FieldMap[FieldId]['microsite'] = Microsite
                            break    
    
                # Loop again to find user
                for idx in range(0, len(SplitLine)):
                    if ('user' in SplitLine[idx]):
                        ColonSplit = SplitLine[idx].strip().split(':')
                        if (len(ColonSplit) > 1):
                            UserIdxStart = LookupSplitLine.index('user')
                            ClientIdxStart = LookupSplitLine.index('client')
                            UserId = ""
                            for x in range(UserIdxStart+1, ClientIdxStart):
                                UserId += LookupSplitLine[x] + " " 
                            FieldMap[FieldId]['user'] = UserId
                            break     
    
                #print(FieldId, ProjectId, str(Status))
                
        #print(json.dumps(FieldMap,indent=2))
        
        for FieldId in FieldMap:
        
            #if FieldId == "705349359":

                #print("Found FieldId")
                #print(FieldMap[FieldId])
            
            ProjectId = ""
            if "user" in FieldMap[FieldId]:
                ProjectId = FieldMap[FieldId]["user"]

            UserId = ""
            if "project" in FieldMap[FieldId]:
                ProjectId = FieldMap[FieldId]["project"]

            Microsite = ""
            if "microsite" in FieldMap[FieldId]:
                Microsite = FieldMap[FieldId]["microsite"]

            #if (("Blue Raven" in Microsite) and ("5786653" in ProjectId)):
            if (FieldId == "705349359"):
                if "Success" in FieldMap[FieldId]:
                    print(FieldId + UserId + " " + Microsite + " " + ProjectId + " "  + ": Success: " + str(FieldMap[FieldId]["Success"][0]))
            
                if "Fail" in FieldMap[FieldId]:
                    print(FieldId + UserId + " " + Microsite + " " + ProjectId + " " + ": Fail: " + str(FieldMap[FieldId]["Fail"][0]))
                
                if "Unknown" in FieldMap[FieldId]:
                    print(FieldId + UserId + " " + Microsite + " " + ProjectId + " " + ": FieldId " + str(FieldMap[FieldId]["Unknown"][0]))

            
          


def ParseArgs():

    global InputFile
    global OutputFile

    if ((len(sys.argv) < 3)):
        print("")
        print("Insufficient parameters:")
        print("<Input File> <Output File> <PapertrailGroup (g3-prod-web/g3-prod-mobile)")
        print("")
        exit()

    InputFile = sys.argv[1]
    OutputFile = sys.argv[2]
    
    if (not os.path.exists(InputFile)):
        print("")
        print("Input file does not exist")
        print("")
        exit()
    
    #if (os.path.exists(OutputFile)):
    #    os.remove(OutputFile)





ParseArgs()
CheckFieldDeletes()
