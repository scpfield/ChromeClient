`const pageData = {"details":"Details","errorCode":"ERR_CONNECTION_REFUSED","fontfamily":"'Segoe UI', Tahoma, sans-serif","fontsize":"75%","heading":{"hostName":"localhost","msg":"This site can’t be reached"},"hideDetails":"Hide details","iconClass":"icon-generic","language":"en","reloadButton":{"msg":"Reload","reloadUrl":"http://localhost/"},"suggestionsDetails":[{"body":"Check any cables and reboot any routers, modems, or other network\
    devices you may be using.","header":"Check your Internet connection"},{"body":"If it is already listed as a program allowed to access the network, try\
      removing it from the list and adding it again.","header":"Allow Chrome to access the network in your firewall or antivirus\
          settings."},{"advancedTitle":"Show advanced settings…","body":"Check your proxy settings or contact your network administrator to\
      make sure the proxy server is working. If you don't believe you should\
      be using a proxy server:\
      Go to\
          the Chrome menu >\
          \\u003Cspan jscontent=\\"settingsTitle\\">\\u003C/span>\
          >\
          \\u003Cspan jscontent=\\"advancedTitle\\">\\u003C/span>\
          >\
          \\u003Cspan jscontent=\\"proxyTitle\\">\\u003C/span>\
          >\
          LAN Settings\
          and deselect \\"Use a proxy server for your LAN\\".","header":"If you use a proxy server…","proxyTitle":"Change proxy settings…","settingsTitle":"Settings"}],"suggestionsSummaryList":[{"summary":"Checking the connection"},{"summary":"\\u003Ca href=\\"#buttons\\" onclick=\\"toggleHelpBox()\\">Checking the proxy and the firewall\\u003C/a>"}],"suggestionsSummaryListHeader":"Try:","summary":{"failedUrl":"http://localhost/","hostName":"localhost","msg":"\\u003Cstrong jscontent=\\"hostName\\">\\u003C/strong> refused to connect."},"textdirection":"ltr","title":"localhost"};loadTimeData.data = pageData;var tp = document.getElementById('t');jstProcess(new JsEvalContext(pageData), tp);`