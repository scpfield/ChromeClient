import  sys, os, time, signal, random, json, websocket, ssl, socket, ctypes
import  multiprocessing as mp
import  multiprocessing.managers as mpm
import  multiprocessing.connection as mpc
import  cdp
from    websocket import ABNF
from    ChromeLauncher import ChromeLauncher
from    util import *
from    colorama import Fore, Back, Style, init as colorama_init
from    ChromeClient import *
from    JavaScriptInjections import *


def OSSignalHandler( Signal, Frame ):

    try:
        print( f'Caught Signal: ' +
               f'{signal.strsignal(Signal)}' )
        os._exit(0)
    except SystemExit:
        print('SystemExit')
    except InterruptedError:
        print('InterruptedError')        
    except BaseException as Failure:
        print( GetExceptionInfo(Failure) )
    finally:
        os._exit(0)
    
def Main():
    
    MyScreen = Screen()
    
    for x in range(0, 100):
        
        time.sleep(0.1)
        MyScreen.AddWindowItem( Screen.UpperWindow, str(x))
        MyScreen.AddWindowItem( Screen.LowerWindow, str(x))
        
    
    while True:
        print("Sleeping 1")
        time.sleep(1)
        

if __name__ == '__main__':

    signal.signal( signal.SIGINT,   OSSignalHandler )
    signal.signal( signal.SIGBREAK, OSSignalHandler )
    signal.signal( signal.SIGABRT,  OSSignalHandler )

    Main()
    
    
   