import sys, os, json, re

SectionSearchMap        = None
GroupSearchMap          = None
SectionFieldSearchMap   = None
GroupFieldSearchMap     = None
DataEditMap             = None
ActionType              = ""
InputFile               = ""
OutputFile              = ""


def FindObjects(ObjectList, SearchExprList):

    #print("FindObjects - Searching for: " + str(SearchExprList))
    #print(ObjectList)
    
    FoundObjects = []
    for ObjectDict in ObjectList:
        Found = False
        for SearchKey, SearchValue in SearchExprList.items():
            if SearchKey in ObjectDict:
                #print("SearchKey: " + str(SearchKey) + " was found in the target ObjectDict")
                #print("Searching ObjDict value for key: " + str(ObjectDict[SearchKey]) + " for the string: " + str(SearchValue))
                SearchResult = re.search(   str(SearchValue), 
                                            str(ObjectDict[SearchKey]), 
                                            flags=(re.IGNORECASE + re.ASCII + re.MULTILINE))

                if (SearchResult):
                    #print("Found match")
                    Found = True
                else:
                    #pass
                    #print("Did not find match, break")
                    Found = False
                    break
            else:
                #print("SearchKey: " + SearchKey + " not found in the target ObjectDict")
                pass
                
        if (Found):
            FoundObjects.append(ObjectDict)
            
    if (len(FoundObjects) > 0):
        return(FoundObjects)
    else:
        return(None)
#end

def ProcessTemplate():

    global SectionSearchMap
    global GroupSearchMap
    global FieldSearchMap
    global DataEditMap
    global ActionType
    global OutputFile
    global InputFile
        
    with open(InputFile, 'r', newline='', encoding='utf-8') as JSONFile:
        JSONData = json.load(JSONFile)
        if (not JSONData):
            print("Failed to load input file: " + InputFile)
        JSONFile.flush()
        JSONFile.close()
        print("Loaded input file: " + InputFile)
        
    FoundSections = None
    FoundGroups = None
    FoundFields = None
    FoundGroupFields = None
    SectionList = None
    GroupList = None
    FieldList = None
    AllFoundSections = []
    AllFoundGroups = []
    AllFoundSectionFields = []
    AllFoundGroupedFields = []
    FoundSectionCount = 0
    FoundGroupCount = 0
    FoundFieldCount = 0
    EditedSectionCount = 0
    EditedGroupCount = 0
    EditedFieldCount = 0
    DeletedSectionCount = 0
    DeletedGroupCount = 0
    DeletedFieldCount = 0
    TargetFlag = False
    
    
    # First search the sections
    if (SectionSearchMap):
        
        SectionList = JSONData["sections"]
        FoundSections = FindObjects(SectionList, SectionSearchMap)
        
        if (FoundSections):
            for Section in FoundSections: 
                # AllFoundSections.append(Section)
                AllFoundSections.append( [Section, SectionList] )

'''
                # only output if that is the only thing to search
                if ((not GroupSearchMap) and 
                    (not SectionFieldSearch) and 
                    (not GroupFieldSearchMap)):
                
                    print(  "[" + ActionType + "]:  " +
                            "section=" + '"' + str(Section["title"]) + '"' + ", " + 
                            "sectionKey=" + '"' + str(Section["sectionKey"] + '"')
                            )
                            
                
            if (ActionType == 'delete'):
                for Section in AllFoundSections:
                    DeletedSectionCount += 1
                    SectionList.remove(Section)
                    
            if (ActionType == 'edit'):
                for Section in AllFoundSections:
                    Edited = False
                    for EditKey, EditValue in EditData.items():
                        if (EditKey in Section):
                            Section[EditKey] = EditValue
                            Edited = True
                    if (Edited):
                        EditedSectionCount += 1
                            
                            
    
    if (GroupSearchList):
        TargetFlag = False
        AllFoundGroups = []
        if (not SectionSearchList):
            SectionList = JSONData["sections"]
        else:
            SectionList = AllFoundSections

        for SectionDict in SectionList:            
            if "fields" in SectionDict:
                FieldList = SectionDict["fields"]
                for Field in FieldList:
                    if "isGroup" in Field:
                        FoundGroups = FindObjects([Field], GroupSearchList)
                        if (FoundGroups):
                            for Group in FoundGroups:
                                AllFoundGroups.append(Group)
                                if (not FieldSearchList):
                                    print(  "[" + ActionType + "]:  " +
                                            "section=" + '"' + str(SectionDict["title"]) + '"' + ", " +
                                            "group=" + '"' + str(Group["name"]) + '"'
                                            # "groupKey=" + str(Group["groupKey"])
                                            )
                                    TargetFlag = True
                                    if (ActionType == 'edit'):
                                        Edited = False
                                        for EditKey, EditValue in EditData.items():
                                            if (EditKey in Group):
                                                Group[EditKey] = EditValue
                                                Edited = True
                                        if (Edited):
                                            EditedGroupCount += 1                                    

        if (TargetFlag):
            if (ActionType == 'find'):
                FoundGroupCount += len(AllFoundGroups)
            else:
                for SectionDict in SectionList:            
                    if "fields" in SectionDict:
                        FieldList = SectionDict["fields"]
                        for Field in FieldList:
                            if "isGroup" in Field:
                                for Group in AllFoundGroups:   
                                    if Group in FieldList:
                                        if (ActionType == 'delete'):   
                                            FieldList.remove(Group)                         
                                            DeletedGroupCount += 1
                                            
    if (FieldSearchList):
    
        if (not SectionSearchList):
            SectionList = JSONData["sections"]
        else:
            SectionList = AllFoundSections
    
        if (GroupSearchList):
            GroupList = AllFoundGroups

        AllFoundGroupedFields = []
        AllFoundSectionFields = []
            
        TargetFlag = False
        for SectionDict in SectionList:
            if "fields" in SectionDict:
                FieldList = SectionDict["fields"]
                # if we already have a list of searched/matching groups 
                # if there was no filter for groups
                # then search all groups
                for Field in FieldList:
                    if "isGroup" in Field:
                        # filter by previously selected groups
                        if ((GroupSearchList) and (Field not in AllFoundGroups)):
                            #print("USING PREVIOUS GROUP SEARCH RESULTS")
                            continue
                        GroupedFieldList = Field["groupFields"]
                        FoundGroupedFields = FindObjects(GroupedFieldList, FieldSearchList)
                        if (FoundGroupedFields):
                            for GroupedField in FoundGroupedFields:
                                AllFoundGroupedFields.append(GroupedField)
                                print(  "[" + ActionType + "]:  " + 
                                        "section=" + '"' + str(SectionDict["title"]) + '"' + ", " +
                                        "group=" + '"' + str(Field["name"]) + '"' + ", " +
                                        "field=" + '"' + str(GroupedField["displayName"]) + '"')
                                        #"fieldKey=" + str(GroupedField["fieldKey"]))
                                if (ActionType == 'edit'):
                                    EditedFieldCount += 1
                                    Edited = False
                                    for EditKey, EditValue in GroupedField.items():
                                        if (EditKey in GroupedField):
                                            GroupedField[EditKey] = EditValue
                                            Edited = True                                        
                                    TargetFlag = True                                        
                                    
                    else:
                        if GroupSearchList:
                            continue;
                        #print("SEARCHING SECTION FIELDS")
                        # non-group fields in section
                        FoundFields = FindObjects( [Field], FieldSearchList)
                        if (FoundFields):
                             for SectionField in FoundFields:
                                AllFoundSectionFields.append(SectionField)
                                print(  "[" + ActionType + "]:  " + 
                                        "section=" + '"' + str(SectionDict["title"]) + '"' + ", " +
                                        "field=" + '"' + str(SectionField["displayName"]) + '"' )
                                        #"fieldKey=" + str(SectionField["fieldKey"])  
                                if (ActionType == 'edit'):
                                    EditedFieldCount += 1
                                    Edited = False
                                    for EditKey, EditValue in EditData.items():
                                        if (EditKey in SectionField):
                                            SectionField[EditKey] = EditValue
                                            Edited = True                                        
                                            TargetFlag = True
                                    
                
#        if (TargetFlag):
        
        if (ActionType == 'find'):
            FoundFieldCount += len(AllFoundSectionFields)
            FoundFieldCount += len(AllFoundGroupedFields)
        
        if (ActionType == 'delete'):

            for SectionDict in SectionList:
                if "fields" in SectionDict:
                    FieldList = SectionDict["fields"]
                    for Field in FieldList:
                        if "isGroup" in Field: 
                            GroupedFieldList = Field["groupFields"]
                            for FoundGroupedField in AllFoundGroupedFields:
                                if FoundGroupedField in GroupedFieldList:                              
                                    if (ActionType == 'delete'):
                                        GroupedFieldList.remove(FoundGroupedField)
                                        DeletedFieldCount += 1                                    

            for SectionDict in SectionList:
                if "fields" in SectionDict:
                    FieldList = SectionDict["fields"]
                    for Field in FieldList:             
                        for FoundSectionField in AllFoundSectionFields:
                            if FoundSectionField in FieldList:
                                if (ActionType == 'delete'):
                                    FieldList.remove(FoundSectionField)
                                    DeletedFieldCount += 1

    print("")

    if (ActionType == 'find'):
        if (FoundSectionCount > 0):
            print(str(FoundSectionCount) + " sections found")
        if (FoundGroupCount > 0):
            print(str(FoundGroupCount) + " groups found")
        if (FoundFieldCount > 0):
            print(str(FoundFieldCount) + " fields found")
    
    if (ActionType == 'delete'):
        if (DeletedSectionCount > 0):
            print(str(DeletedSectionCount) + " sections deleted")
        if (DeletedGroupCount > 0):
            print(str(DeletedGroupCount) + " groups deleted")
        if (DeletedFieldCount > 0):
            print(str(DeletedFieldCount) + " fields deleted")
        
    if (ActionType == 'edit'):
        if (EditedSectionCount > 0):
            print(str(EditedSectionCount) + " sections edited")
        if (EditedGroupCount > 0):
            print(str(EditedGroupCount) + " groups edited")
        if (EditedFieldCount > 0):
            print(str(EditedFieldCount) + " fields edited")
    

    #if os.path.exists(OutputFile):
    #    os.remove(OutputFile)
        
    if ((ActionType == 'delete') or (ActionType == 'edit')):
        with open(OutputFile, 'w+', newline='', encoding='utf-8') as OutputJSONFile:
            print("Writing output file: " + OutputFile)
            OutputJSONData = json.dumps(JSONData, indent=2)
            OutputJSONFile.write(OutputJSONData)
            OutputJSONFile.flush()
            OutputJSONFile.close()

'''

def ParseArgs():

    if (len(sys.argv) < 5):
        print("Fewer arguments provided than required")
        exit()

    global InputFile
    global OutputFile
    global ActionType
    InputFile = sys.argv[1]
    OutputFile = sys.argv[2]
    ActionType = sys.argv[3]    
    
    if (not os.path.exists(InputFile)):
        print("")
        print("Input file does not exist")
        print("")
        exit()
        
    if (ActionType not in ['find','edit','delete']):
        print("")
        print("Action must be find, edit, or delete")
        print("")
        exit()

    StartIndex = 4
    MaxIndex = ( len( sys.argv ) - 1 )
    
    for Index in range(StartIndex, MaxIndex):
        Arg         = sys.argv[Index]
        Map         = None
        match Arg:
            case '--section':
                global SectionSearchMap
                SectionSearchMap = {}
                Map = SectionSearchMap
            case '--group':
                global GroupSearchMap
                GroupSearchMap = {}
                Map = GroupSearchMap
            case '--sectionfield': 
                global SectionFieldSearchMap
                SectionFieldSearchMap = {}
                Map = SectionFieldSearchMap
            case '--groupfield': 
                global GroupFieldSearchMap
                GroupFieldSearchMap = {}
                Map = GroupFieldSearchMap
            case '--data':
                global DataEditMap
                DataEditMap = {}
                Map = DataEditMap
            case _:
                continue
     
        if ( (Index + 1) > MaxIndex ):
            print("")
            print("Insufficient number of arguments provided")
            print("")
            exit()

        ArgValue = sys.argv[Index + 1]

        if (ArgValue.startswith("--")):
            print("")
            print("Invalid argument value")
            print("")
            exit()
    
        for Item in ArgValue.split(','):
            if Item:
                Key = None
                Value = None
                Pair = []
                Pair = Item.split('=')
                if (len(Pair) < 2):
                    Pair = Item.split(':')
                    if (len(Pair) < 2):
                        print("")
                        print("Invalid value for argument: " + ArgValue)
                        print("")
                        exit()
                        
                Key = Pair[0]
                Value = Pair[1]
                if ((Key) and (Value)):
                    Map[Key] = Value
                else:
                    print("")
                    print("Invalid value for argument: " + ArgValue)
                    print("")
                    exit()
            else:
                print("")
                print("Missing value for argument: " + ArgValue)
                print("")
                exit()

# end


ParseArgs()

print("")
print("Arguments:")
print("----------")
print("Input File           : " + InputFile)
print("Output File          : " + OutputFile)
print("Action Type          : " + ActionType)
print("Section Filter       : " + str(SectionSearchMap))
print("Group Filter         : " + str(GroupSearchMap))
print("Section Field Filter : " + str(SectionFieldSearchMap))
print("Group Field Filter   : " + str(GroupFieldSearchMap))
print("Edit Data            : " + str(DataEditMap))
print("")

ProcessTemplate()




