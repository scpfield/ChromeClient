import sys, os, re, json, copy, msvcrt
from colorama import init, Fore, Back, Style
from datetime import datetime
from datetime import timedelta


def ProcessStdIn():

    StdInLine = sys.stdin.readline()

    while StdInLine:

        StdInLine       = sys.stdin.readline()
        
        if (not StdInLine):
            continue
        
        if ('GoogleAuthUtil' in StdInLine):
            continue
            
        if ('Picasso' in StdInLine):
        
            if ('created' in StdInLine):
                StdInLine = (   Back.RESET + Style.BRIGHT + Fore.YELLOW + '\n' +
                                StdInLine.replace('{', '{\n\n' + Style.BRIGHT + Fore.YELLOW) +
                                Style.RESET_ALL + Back.RESET + Fore.RESET + '\n}\n\n' )
                
            elif ('completed' in StdInLine):
                if ('NETWORK' in StdInLine):
                    StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.RED + 
                        StdInLine.replace('\n', Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
                if ('DISK' in StdInLine):
                    StdInLine = Back.RESET + Style.BRIGHT + Fore.WHITE + Back.BLUE + StdInLine
                    StdInLine = StdInLine.replace('\n', Style.RESET_ALL + Fore.RESET + Back.RESET + '\n')
                if ('MEMORY' in StdInLine):
                    StdInLine = Back.RESET + Style.BRIGHT + Fore.WHITE + Back.GREEN + StdInLine
                    StdInLine = StdInLine.replace('\n', Style.RESET_ALL + Fore.RESET + Back.RESET + '\n')
            else:
                StdInLine = Back.RESET + Style.BRIGHT + Fore.WHITE + Back.YELLOW + StdInLine
                StdInLine = StdInLine.replace('\n', Style.RESET_ALL + Fore.RESET + Back.RESET + '\n')
        
        if ('sitecapture' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.MAGENTA + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        elif ('fotonotes' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.MAGENTA + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        elif ('okhttp' in StdInLine):
            StdInLine = ( Back.RESET + Style.DIM + Back.MAGENTA + Style.BRIGHT + Fore.YELLOW + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        elif ('BF/' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.MAGENTA + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        elif ('FN/' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.MAGENTA + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        elif ('FNSync' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.MAGENTA + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        elif ('StringCachingUtil' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.RED + Back.BLACK + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        elif ('Project' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.MAGENTA + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))

        elif ('Section' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.WHITE + Back.MAGENTA + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        if ('System.err' in StdInLine):
            StdInLine = ( Back.RESET + Style.BRIGHT + Fore.RED + Back.BLACK + 
                        StdInLine.replace('\n', 
                        Style.RESET_ALL + Fore.RESET + Back.RESET + '\n'))
        
        
        print(StdInLine, end='')
        
        
        


# Start of main
init(autoreset=False)

print("")
#ParseArgs()

ProcessStdIn()
