import sys, io, json, time, re, random, base64
import xml.etree.ElementTree
import lxml.html
import lxml.etree


import selenium.webdriver
import appium.webdriver


from Util import *



help(lxml)
lxml.html.fromstring('asdfasdfasdf')


quit()

Driver = selenium.webdriver.Chrome()
Driver.implicitly_wait(2000)
Driver.get("http://www.google.com")
print('dumping')
with open(
    'page_source.html', 
    'w+', 
    newline='', 
    encoding='utf-8') as OutputFile:
        OutputFile.write( 
            str(Driver.page_source) )


# El = Driver.find_element( by = 'css selector', value = 'meta[content="origin"]' )

El = Driver.find_elements( by = 'css selector', value = 'input[class="gLFyf"][name="q"][jsaction="paste\:puy29d\;"][type="text"][aria-label="Search"][role="combobox"]' )

#El = Driver.find_elements( by = 'css selector', value = 'div' )

#<input class="gLFyf" jsaction="paste:puy29d;" maxlength="2048" name="q" type="text" autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="" role="combobox" spellcheck="false" title="Search" value="" aria-label="Search" data-ved="0ahUKEwjTprObi-_9AhWkEVkFHfzgDkcQ39UDCAc"/>

for i in El:
    print(str(i.id))
    
#Info(El)

