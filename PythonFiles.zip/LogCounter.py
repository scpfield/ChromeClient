import sys, io, csv, json, re

class LogCounter:

    # Strings for dictionary keys
    TotalLines      = "TotalLogLines"
    TotalMatched    = "TotalLinesMatched"
    SearchTerms     = "SearchTerms"
    MatchedValues   = "MatchedValues"
    Verbose         = False
    LogDict         = {}
    
    def __init__(self, LogFile, SearchTerm):
        self.LogFile = LogFile
        self.SearchTerm = SearchTerm
    
    def SearchLog(self):
    
        TotalLines      = self.TotalLines
        TotalMatched    = self.TotalMatched
        SearchTerms     = self.SearchTerms
        MatchedValues   = self.MatchedValues
        LogDict         = self.LogDict
        TimeStampStr    = ""
        
        print("Input file: " + self.LogFile)
        print("Search term: " + self.SearchTerm)
        
        with open(  self.LogFile, 
                    #ewline=, 
                    encoding="ansi") as LogFile:
            
            for Line in LogFile:
                
                TimeStampStr = ""
                SplitLine = Line.split()
                
                # Check the timestamp of the log line 
                # and create a new dictionary entry if necessary

                if (len(SplitLine) > 2):
                    TimeStampStr = (str(SplitLine[0]) + " " + 
                                    str(SplitLine[1]))
                    
                    if TimeStampStr not in LogDict:
                        LogDict[TimeStampStr] = {}
                        LogDict[TimeStampStr][SearchTerms] = {}
                else:   
                    continue   # if we got mangled short line
            
                # Increment the line count for this timestamp entry
                if TimeStampStr in LogDict:
                    if TotalLines in LogDict[TimeStampStr]:
                        LogDict[TimeStampStr][TotalLines] += 1
                    else:
                        LogDict[TimeStampStr][TotalLines] = 1
                else:
                    print("This should not happen")
                    exit()
            
                
                #SearchTermABC = 'r' + "'" + SearchTerm + "'"
                #print(SearchTermABC)
                # "((imagePost[.]\w+)|(projectApi[.]\w+))(?=.*\bmicrosite:Blue Raven Solar\b)(?=.*user:Grant.Larson)"
                #  "(?<=TEMPLATE_CACHE cache miss)"\bmicrosite:[^|]*\b"
                #  "(?<=CLOSED).+(?=[|]).+(microsite:[^|]*\b)" -- group 2  (match[1])
                #  "(?<=TEMPLATE_CACHE).*(?=[^|]).*(microsite:[^|]*\b)"
                # "\bmicrosite:[^|]*\b
                # "(microsite:\w*.\w*.\w*)"
                # "\w(?<!=quartz)\w*(Exception)"
                # "(?<!quartz)(\w*Exception)"
                # "(microsite:.\w+[^|].\w+[^|])"   <--= thje one
                #  "microsite:\w+ \w+"
                # "projectApi[.]\w+(?=.*microsite.Freedom)"
                # "projectApi[.]\w+(?=.*microsite:Freedom Forever)(?=.*user:henrynguyen)"
                #  projectApi.createProject
                #  "(?<=projectApi[.]createProject).*(?=[^|]).*(project:[^|]*\b)"
                #  WORKS:  "(?<=MEDIA[_]DELETED).*[^|](?<=project)[^|](\w*.)"
                # Search and increment result counts
                #  "(?<=FIELD[_]NULLED for fieldValue.\b)[^|](.*\w)(?<=project)[^|](\w*.)"
                
                SearchResult = re.search(   SearchTerm,
                                            Line, 
                                            flags=(re.IGNORECASE + re.MULTILINE))

                #SearchResult = re.findall(   SearchTerm,
                #                            Line, 
                #                            flags=(re.IGNORECASE + re.MULTILINE))
                    
                if (SearchResult):
            
                    Match = None
                    
                    print(str(SearchResult))
                    
                    Groups = SearchResult.groups()
                    if not Groups:
                        Match = SearchResult.group()
                    else:
                        Match = Groups[0]
                    

                    print(SearchResult.groups())
                    print (SearchResult.group())
                    
                    
                    
                    #print("Match: " + str(SearchResult.groups()[0]))
                    
                    #if (Match == ""):
                    #    print(SearchResult.groups())
                        
                    #print(str("Original Line: " + Line))
                    
                    if (Verbose):    
                        #print("")
                        #print(SearchResult.group())
                        #print(SearchResult.groups())
                        print(str("Original Line: " + Line))
                        print("Full Match Value : " + SearchResult.string)
                        print("Match            : " + str(Match))
    
                    if TimeStampStr in LogDict:
                        if SearchTerm in LogDict[TimeStampStr][SearchTerms]:
                            LogDict[TimeStampStr][SearchTerms][SearchTerm][TotalMatched] += 1
                            if MatchedValues in LogDict[TimeStampStr][SearchTerms][SearchTerm]:
                                if Match in LogDict[TimeStampStr][SearchTerms][SearchTerm][MatchedValues]:
                                    LogDict[TimeStampStr][SearchTerms][SearchTerm][MatchedValues][Match] += 1
                                else:
                                    LogDict[TimeStampStr][SearchTerms][SearchTerm][MatchedValues][Match] = 1
                            else:
                                print("This should not happen")
                                exit()
                        else:
                            LogDict[TimeStampStr][SearchTerms][SearchTerm] = {}
                            LogDict[TimeStampStr][SearchTerms][SearchTerm][TotalMatched] = 1
                            LogDict[TimeStampStr][SearchTerms][SearchTerm][MatchedValues] = {}
                            LogDict[TimeStampStr][SearchTerms][SearchTerm][MatchedValues][Match] = 1
                    else:
                        print("This should not happen")
                        exit()
                #else:
                #    print("Nothing")
            print()

            
        #print(json.dumps(LogDict,indent=5))
        
        #self.PrintResults()
        self.PrintCSV()
        
        # SortedLog = sorted(LogDict.items(), key=lambda x:x[0])

    def PrintCSV(self):
    
            print("Generating CSV")
            
            TotalLines      = self.TotalLines
            TotalMatched    = self.TotalMatched
            SearchTerms     = self.SearchTerms
            MatchedValues   = self.MatchedValues
            LogDict         = self.LogDict
            OutputLine      = ""
            HeaderLine      = ""
            
            CSVFields = ["TimeStamp",TotalLines]
            
            # first need to find all the matched terms for the header
            for TimeStamp in LogDict:
                for SearchTerm in LogDict[TimeStamp][SearchTerms]:
                    if (SearchTerm not in CSVFields):
                        CSVFields.append(SearchTerm)
                    for Match in LogDict[TimeStamp][SearchTerms][SearchTerm][MatchedValues]:
                        if (Match not in CSVFields):
                            CSVFields.append(Match)
            
            # next make a list of dictionaries for csv module
            
            CSVList = []
            Totals = {}
            
            for TimeStamp in LogDict:
                CSVDict = {}
                CSVDict["TimeStamp"] = TimeStamp
                
                TotalLinesValue = LogDict[TimeStamp][TotalLines]
                CSVDict[TotalLines] = TotalLinesValue
                
                for SearchTerm in LogDict[TimeStamp][SearchTerms]:
                
                    TotalMatchedValue = LogDict[TimeStamp][SearchTerms][SearchTerm][TotalMatched]
                    CSVDict[SearchTerm] = TotalMatchedValue
              
                    for Match in LogDict[TimeStamp][SearchTerms][SearchTerm][MatchedValues]:
                        
                        Match.strip()
                        MatchValue = LogDict[TimeStamp][SearchTerms][SearchTerm][MatchedValues][Match]
                        CSVDict[Match] = MatchValue
                        
                        # print (Match, MatchValue)
                        if (str(Match) in Totals):
                            Totals[str(Match)] += int(MatchValue)
                        else:
                            Totals[str(Match)] = 0
                            Totals[str(Match)] += int(MatchValue)
                
                CSVList.append(CSVDict)
            
            print("-------------------------")
            for key, value in Totals.items():
                print(str(key) + "," + str(value));
                
            # print(json.dumps(CSVFields,indent=2))
            # print(json.dumps(CSVList,indent=2))
            
            # print(str(Totals))
            print("Writing CSV File")
            
            OutputFile = "output.csv"
            with open(OutputFile, 'w', newline='') as CSVFile:
                CSVWriter = csv.DictWriter(CSVFile, fieldnames=CSVFields)
                CSVWriter.writeheader()
                CSVWriter.writerows(CSVList)
                

            
    def PrintResults(self):
            TotalLines      = self.TotalLines
            TotalMatched    = self.TotalMatched
            SearchTerms     = self.SearchTerms
            MatchedValues   = self.MatchedValues
            LogDict         = self.LogDict
            OutputLine     = ""
            
            for TimeStamp in LogDict:
                
                TotalLinesValue = LogDict[TimeStamp][TotalLines]
                OutputLine = TimeStamp + "," + TotalLines + "=" + str(TotalLinesValue)
                
                for SearchTerm in LogDict[TimeStamp][SearchTerms]:
                
                    TotalMatchedValue = LogDict[TimeStamp][SearchTerms][SearchTerm][TotalMatched]
                    OutputLine = OutputLine + "," + "SearchTerm=" + SearchTerm
                    OutputLine = OutputLine + "," + TotalMatched + "=" + str(TotalMatchedValue)
            
                    for Match in LogDict[TimeStamp][SearchTerms][SearchTerm][MatchedValues]:
                        
                        for MatchValue in LogDict[TimeStamp][SearchTerms][SearchTerm][MatchedValues]:  # [Match]
                        
                            MatchValue = LogDict[TimeStamp][SearchTerms][SearchTerm][MatchedValues][Match]
                            OutputLine = OutputLine + "," + str(Match) + "=" + str(MatchValue)
                            # OutputLine = OutputLine + "," + "MatchValue=" + Match
                            # OutputLine = OutputLine + "," + "MatchedCount=" + str(MatchValue)
                        
                
                print(OutputLine)
            











InputFile = None
SearchTerm = None
Verbose = True

if (len(sys.argv) < 2):
  print("Please provide InputFile + SearchTerm + Verbose")
  exit()

InputFile= str(sys.argv[1])
SearchTerm = str(sys.argv[2])

if ((InputFile == None) or (SearchTerm == None)):
  print("Please provide InputFile + SearchTerm")
  exit()

MyLogCounter = LogCounter(InputFile, SearchTerm)
MyLogCounter.SearchLog()




