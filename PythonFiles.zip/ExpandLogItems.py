import sys, os, subprocess
from datetime import datetime
from datetime import timedelta

InputFile               = ""
OutputFile              = ""
PapertrailGroup         = ""

def QueryPapertrail(CurrentWindowMin, CurrentWindowMax):

    print("")
    Cmd = "pt "
    Args =  " --color off " +                   \
            " -g " + PapertrailGroup +          \
            " -q " +                            \
            " -b 100 " +                        \
            " -o " + '"' + OutputFile + '"' +   \
            " --min-time " + '"' +              \
            str(CurrentWindowMin) + '"' +       \
            " --max-time " + '"' +              \
            str(CurrentWindowMax) + '"'
            
    print(Cmd + Args)
    os.system(Cmd + Args)


def ExpandLog():

    global InputFile
    global OutputFile
    
    print("Loading: " + InputFile)
    
    PrevTimestamp = 0
    
    with open(InputFile, 'r', newline='', encoding='utf-8') as DataFile:
        
        CurrentWindowMin = 0
        CurrentWindowMax = 0
        Span = 5
        FutureSpan = timedelta(seconds=Span)
        PastSpan = timedelta(seconds=Span)
        MyDelta = timedelta(seconds=Span)
    
        
        for Line in DataFile:
        
            # print(Line)
            SplitLine = Line.split(' ');
            DateStr = ""
            TimeStr = ""
            
            if  ( (len(SplitLine)) > 2 ):
                DateStr = str(SplitLine[0]).strip()
                TimeStr = str(SplitLine[1]).strip()
            else:
                print("Line is missing timestamp")
                exit()
                continue
            
            Timestamp = datetime.fromisoformat(DateStr + " " + TimeStr)
            PastDelta = Timestamp - timedelta(seconds=Span)
            FutureDelta = Timestamp + timedelta(seconds=Span)
            
            if (PrevTimestamp == 0):
                PrevTimestamp = Timestamp
            
            print("----------")
            if (CurrentWindowMin == 0):
                CurrentWindowMin = Timestamp
            
            if (CurrentWindowMax == 0):
                CurrentWindowMax = Timestamp
 
            MaxDelta = (timedelta(seconds=(Span * 2)))
            
            print("CurrentTs        = " + str(Timestamp) + " " + str((Timestamp - PrevTimestamp)))
            print("PrevTimeStamp    = " + str(PrevTimestamp))
            print("WindowMin        = " + str(CurrentWindowMin))
            print("WindowMax        = " + str(CurrentWindowMax))
            print("max delta        = " + str(MaxDelta))
 
            if ((Timestamp - PrevTimestamp) > MaxDelta):
                #print("Reset!")
                #print("Block: " +   "min = " + str(CurrentWindowMin) + " " +
                #                    "max = " + str(CurrentWindowMax) )
                QueryPapertrail(CurrentWindowMin, CurrentWindowMax)
                CurrentWindowMin = Timestamp
                CurrentWindowMax = Timestamp
            
            if ((Timestamp + FutureSpan) > CurrentWindowMax):
                CurrentWindowMax = (Timestamp + FutureSpan)
        
            if ((Timestamp - PastSpan) < CurrentWindowMin):
                CurrentWindowMin = (Timestamp - PastSpan)

            if (not Timestamp):
                print("Failed to parse timetamp")
                exit()
                continue
           
            PrevTimestamp = Timestamp



def ParseArgs():

    global InputFile
    global OutputFile
    global PapertrailGroup

    if ((len(sys.argv) < 4)):
        print("")
        print("Insufficient parameters:")
        print("<Input File> <Output File> <PapertrailGroup (g3-prod-web/g3-prod-mobile)")
        print("")
        exit()

    InputFile = sys.argv[1]
    OutputFile = sys.argv[2]
    PapertrailGroup = sys.argv[3]    
    
    if (not os.path.exists(InputFile)):
        print("")
        print("Input file does not exist")
        print("")
        exit()
    
    #if (os.path.exists(OutputFile)):
    #    os.remove(OutputFile)





ParseArgs()
ExpandLog()

