import sys, io, json, time, re, random, base64
import selenium.webdriver
import appium.webdriver

from selenium.common.exceptions import *
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions import interaction
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.pointer_input import PointerInput
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.expected_conditions import *

#from apps import AndroidSettingsApp
#from app_pages import AppPage

import apps
import app_pages
import app_elements
from util import *

#from appium import webdriver
#from appium.webdriver.common.appiumby import AppiumBy
#from app_pages import *
#from app_elements import *
    
#from selenium import webdriver
    
# from lxml import html, etree

# options = Options()
# options.page_load_strategy = 'normal'



def AddPhotoToContactForm(WD, ScrollViewContainer):

    if (not WD):
        print("Invalid webdriver object")
        return False

    try:

        # Initialize a new WebDriverWait object
        WaitObject = None
        WaitObject = WebDriverWait( driver = WD,
                                    timeout = 0,
                                    poll_frequency = 0.25,
                                    ignored_exceptions = [
                                        NoSuchElementException,
                                        StaleElementReferenceException,
                                        NoAlertPresentException ])

        if not WaitObject:
            print('Failure creating WaitObject object')
            return False

        # Make selector for the Add Photo item
        PhotoFieldSelector = str( 'new UiSelector()' +
                                  '.className("android.widget.RelativeLayout")' +
                                  '.resourceId("com.google.android.contacts:id/photo_update_clickable")' +
                                  '.clickable(true)' )

        # Scroll back up to the Add Photo item
        ExecuteResult = WD.execute_script( 'mobile: scroll', {
                                           'elementId' : str(ScrollViewContainer.id),
                                           'strategy'  : str(By.ANDROID_UIAUTOMATOR),
                                           'selector'  : str(PhotoFieldSelector),
                                           'maxSwipes' : 10,
                                           'direction' : 'down',
                                           'speed' : 500000 } )

        # Locate the PhotoFieldButton
        PhotoFieldButton = None
        PhotoFieldButton = WaitObject.until(any_of(
                                              visibility_of_element_located(
                                                (By.ANDROID_UIAUTOMATOR,
                                                str(PhotoFieldSelector)))))

        if not PhotoFieldButton:
            print('Failed to locate PhotoFieldButton')
            return False

        # Click the PhotoFieldButton
        print('Clicking the PhotoFieldButton')
        PhotoFieldButton.click()

        # A pop-up dialog should be displayed
        # asking the user whether to take a picture or select from album
        # we will take a photo

        # Make the TakePhotoButtonSelector
        TakePhotoButtonSelector = str( 'new UiSelector()' +
                                       '.className("android.widget.TextView")' +
                                       '.resourceId("android:id/text1")' +
                                       '.text("Take photo")' +
                                       '.clickable(true)' )

        # Locate the TakePhotoButton
        TakePhotoButton = None
        TakePhotoButton = WaitObject.until(any_of(
                                            visibility_of_element_located(
                                                (By.ANDROID_UIAUTOMATOR,
                                                str(TakePhotoButtonSelector)))))

        if not TakePhotoButton:
            print('Failed to locate TakePhotoButton')
            return False

        # Click the TakePhotoButton
        print('Clicking the TakePhotoButton')
        TakePhotoButton.click()

        # Make selector for the CameraShutterButton
        CameraShutterButtonSelector = str( 'new UiSelector()' +
                                           '.className("android.widget.ImageView")' +
                                           '.resourceId("com.android.camera2:id/shutter_button")' +
                                           '.description("Shutter")' +
                                           '.clickable(true)' )

        # Locate the CameraShutterButton
        CameraShutterButton = None
        CameraShutterButton = WaitObject.until(any_of(
                                                visibility_of_element_located(
                                                    (By.ANDROID_UIAUTOMATOR,
                                                    str(CameraShutterButtonSelector)))))

        if not CameraShutterButton:
            print('Failed to locate CameraShutterButton')
            return False

        # Click the CameraShutterButton
        print('Clicking the CameraShutterButton')
        CameraShutterButton.click()

        # Make selector for the CameraCheckmarkDoneButton
        CameraCheckmarkDoneButtonSelector = str( 'new UiSelector()' +
                                                 '.className("android.widget.ImageButton")' +
                                                 '.resourceId("com.android.camera2:id/done_button")' +
                                                 '.description("Done")' +
                                                 '.clickable(true)' )

        # Locate the CameraCheckmarkDoneButton
        CameraCheckmarkDoneButton = None
        CameraCheckmarkDoneButton = WaitObject.until(any_of(
                                                        visibility_of_element_located(
                                                            (By.ANDROID_UIAUTOMATOR,
                                                            str(CameraCheckmarkDoneButtonSelector)))))

        if not CameraCheckmarkDoneButton:
            print('Failed to locate CameraCheckmarkDoneButton')
            return False

        # Click the CameraCheckmarkDoneButton
        print('Clicking the CameraCheckmarkDoneButton')
        CameraCheckmarkDoneButton.click()

        # The user will be shown a photo-edit feature
        # which has another Done button to click

        # Make selector for the PhotoEditDoneButton
        PhotoEditDoneButtonSelector = str( 'new UiSelector()' +
                                           '.className("android.widget.Button")' +
                                           '.resourceId("com.google.android.apps.photos:id/photos_photoeditor_fragments_editor3_save")' +
                                           '.text("Done")' +
                                           '.clickable(true)' )

        # Locate the PhotoEditDoneButton
        PhotoEditDoneButton = None
        PhotoEditDoneButton = WaitObject.until(any_of(
                                                visibility_of_element_located(
                                                    (By.ANDROID_UIAUTOMATOR,
                                                    str(PhotoEditDoneButtonSelector)))))

        if not PhotoEditDoneButton:
            print('Failed to locate PhotoEditDoneButton')
            return False

        # Click the PhotoEditDoneButton
        print('Clicking the PhotoEditDoneButton')
        PhotoEditDoneButton.click()

        # User is returned to the edit-contact form which
        # has the final Save button waiting to be clicked

        # Create selector for the ContactSaveButton
        ContactSaveButtonSelector = str( 'new UiSelector()' +
                                           '.className("android.widget.Button")' +
                                           '.resourceId("com.google.android.contacts:id/toolbar_button")' +
                                           '.clickable(true)' )

        # Locate the PhotoEditDoneButton
        ContactSaveButton = None
        ContactSaveButton = WaitObject.until(any_of(
                                                visibility_of_element_located(
                                                    (By.ANDROID_UIAUTOMATOR,
                                                    str(ContactSaveButtonSelector)))))

        if not ContactSaveButton:
            print('Failed to locate ContactSaveButton')
            return False

        # Click the ContactSaveButton
        print('Clicking the ContactSaveButton')
        ContactSaveButton.click()

        # Finally, we can click on the Navigate Up / Back
        # button to return to the main list of Contacts
        # and we can create another one

        # Make selector for the Navigate Up button

        NavigateUpButtonSelector = str( 'new UiSelector()' +
                                        '.className("android.widget.ImageButton")' +
                                        '.descriptionMatches("Navigate up|Back")' +
                                        '.clickable(true)' )

        NavigateUpButton = None
        NavigateUpButton = WaitObject.until(
                                        visibility_of_element_located(
                                            (By.ANDROID_UIAUTOMATOR,
                                            str(NavigateUpButtonSelector))))

        if not NavigateUpButton:
            print('Failed to locate NavigateUpButton')
            return(False)

        # sleep a few seconds to admire the work
        time.sleep(5)

        # Click the NavigateUpButton
        print('Clicking NavigateUpButton')
        NavigateUpButton.click()

        # Done adding photo

    except TimeoutException as Exc:
        # This exception block happens if we waited
        # longer than x seconds to locate an element.
        print('Waited too long for element to appear')
        return False

    # End of try-except

    return True

# End of function


    return True


def AddContactFormInfo(WD):

    if (not WD):
        print("Invalid webdriver object")
        return False

    try:

        # Initialize a new WebDriverWait object
        WaitObject = None
        WaitObject = WebDriverWait( driver = WD,
                                    timeout = 0,
                                    poll_frequency = 0.25,
                                    ignored_exceptions = [
                                        NoSuchElementException,
                                        StaleElementReferenceException,
                                        NoAlertPresentException ])

        if not WaitObject:
            print('Failure creating WaitObject object')
            return False

        # First, expand the list of fields by clicking the MoreFieldsButton
        MoreFieldsButtonSelector = str( 'new UiSelector()' +
                                        '.className("android.widget.TextView")' +
                                        '.resourceId("com.google.android.contacts:id/more_fields")' +
                                        '.text("More fields")' +
                                        '.clickable(true)' )

        MoreFieldsButton = None
        MoreFieldsButton = WaitObject.until( any_of(
                                                visibility_of_element_located(
                                                (By.ANDROID_UIAUTOMATOR,
                                                str(MoreFieldsButtonSelector)))))

        if not MoreFieldsButton:
            print('Failed to locate MoreFieldsButton')
            return False

        print()
        print('Clicking MoreFieldsButton')
        MoreFieldsButton.click()

        # Next, expand the list with more fields by clicking the Expand button
        ExpandedFieldsButtonSelector = str( 'new UiSelector()' +
                                            '.className("android.widget.FrameLayout")' +
                                            '.resourceId("com.google.android.contacts:id/expansion_view_container")' +
                                            '.clickable(true)' )

        ExpandedFieldsButton = None
        ExpandedFieldsButton = WaitObject.until( any_of(
                                                visibility_of_element_located(
                                                (By.ANDROID_UIAUTOMATOR,
                                                str(ExpandedFieldsButtonSelector)))))

        if not ExpandedFieldsButton:
            print('Failed to locate ExpandedFieldsButton')
            return False

        print()
        print('Clicking ExpandedFieldsButton')
        ExpandedFieldsButton.click()

        # List of all the fields to edit
        EditFieldNames = [  'Name prefix', 'First name', 'Middle name', 'Last name', 'Name suffix',
                            'Phonetic last name', 'Phonetic middle name', 'Phonetic first name',
                            'Nickname', 'Company', 'Department', 'Title', 'Phone', 'Email',
                            'Address', 'Website', 'Related person', 'SIP', 'Notes' ]


        # Add random data to fields
        for EditFieldName in EditFieldNames:

            # For each of the fields, scroll until it is found
            # First, find the ScrollView element
            ScrollViewSelector = str( 'new UiSelector()' +
                                      '.className("android.widget.ScrollView")' +
                                      '.resourceId("com.google.android.contacts:id/contact_editor_scroller")' +
                                      '.scrollable(true)' )

            ScrollViewContainer = None
            ScrollViewContainer = WaitObject.until( any_of(
                                                    visibility_of_element_located(
                                                    (By.ANDROID_UIAUTOMATOR,
                                                    str(ScrollViewSelector)))))

            if not ScrollViewContainer:
                print('Failed to locate ScrollViewContainer')
                return False

            print()
            print("Adding random data to field: " + EditFieldName)

            EditFieldSelector = None
            EditFieldSelector = str( 'new UiSelector()' +
                                    '.classNameMatches("android.widget.EditText|android.widget.AutoCompleteTextView")' +
                                    '.text("' + EditFieldName + '")' +
                                    '.clickable(true)' )

            # Scroll the field into view
            ExecuteResult = WD.execute_script( 'mobile: scroll', {
                                               'elementId' : str(ScrollViewContainer.id),
                                               'strategy'  : str(By.ANDROID_UIAUTOMATOR),
                                               'selector'  : str(EditFieldSelector),
                                               'maxSwipes' : 10,
                                               'direction' : 'up',
                                               'speed' : 500000 } )

            # The EditField should now be scrolled into view
            # We need to locate it first
            EditField = None
            EditField = WaitObject.until(any_of(
                                          visibility_of_element_located(
                                            (By.ANDROID_UIAUTOMATOR,
                                             str(EditFieldSelector)))))

            if not EditField:
                print('Failed to locate EditField')
                return False

            # Now use the Actions method to set focus
            EditFieldActions = None
            EditFieldActions = ActionChains(WD)
            EditFieldActions.move_to_element(EditField)
            EditFieldActions.click()
            EditFieldActions.perform()

            # Add data to fields, depending on type of field
            # because the app prevents incorrect data from
            # being typed in

            FieldData = ''

            if EditField.text == 'Phone':
                FieldData = '1-123-456-7890'
            else:
                FieldData = str(RandomString(20))

            ExecuteResult = WD.execute_script( 'mobile: type',
                                             { 'text' : FieldData })


            # Hide the keyboard if it is shown
            try:
                if (WD.is_keyboard_shown()):
                    print("Keyboard is currently shown")
                    WD.hide_keyboard()
                else:
                    print("Keyboard is not currently shown")
            except:
                pass


        # End of loop of Text Field Names

        # Call a separate function to add a photo
        AddPhotoToContactForm(WD, ScrollViewContainer)

    except TimeoutException as Exc:
        # This exception block happens if we waited
        # longer than x seconds to locate an element.
        print('Waited too long for element to appear')
        return False

    # End of try-except

    return True

# End of function


def AddContacts(WD):

    if (not WD):
        print("Invalid webdriver object")
        return False

    max_loops = 0
    current_loop = 0

    # This is from selenium, it is a wrapped retry-loop for
    # when it takes a little while for Android to populate a page with
    # elements.  So you can specify how long to wait.  We intentionally
    # ignore those 2 exceptions for this case. This just declares the
    # WaitObject to be used later.

    WaitObject = None
    WaitObject = WebDriverWait( driver = WD,
                                timeout = 0,
                                poll_frequency = 0.2,
                                ignored_exceptions = [
                                    NoSuchElementException,
                                    StaleElementReferenceException,
                                    NoAlertPresentException ])

    if not WaitObject:
        print('Failure creating WaitObject object')
        return False


    while True:

        # Exit after x iterations
        if current_loop > max_loops:
            break
        else:
            current_loop += 1

        # First wait for the AddContactButton to appear
        # Also click the google popups to go away

        print()
        print( 'Loop ' + str(current_loop) + '/' + str(max_loops) +
               ': Waiting for AddContactButton to appear')

        try:

            # This is an Android-specific selector syntax for the
            # UiAutomator framework that is part of Android OS and
            # requires writing the test clients in java.
            # Appium lets you circumvent most of it, by allowing a
            # user to write a tiny bit of java code to describe the
            # selector parameters, and inject it into the device.
            #  '.resourceIdMatches(AddContactButtonID + '|' + SkipButtonID + '|' + AllowButtonID)

            AddContactButtonID  =  'com.google.android.contacts:id/floating_action_button'
            SkipButtonID        = 'android:id/button2'
            AllowButtonID       = 'com.android.permissioncontroller:id/permission_allow_button'

            AddContactButtonSelector = str( 'new UiSelector()' +
                                            '.resourceId("' +
                                            AddContactButtonID + '")' +
                                            '.clickable(true)' )

            SkipAlertButtonSelector = str( 'new UiSelector()' +
                                            '.resourceId("' +
                                            SkipButtonID + '")' +
                                            '.clickable(true)' )

            AllowAlertButtonSelector = str( 'new UiSelector()' +
                                            '.resourceId("' +
                                            AllowButtonID + '")' +
                                            '.clickable(true)' )

            print(AddContactButtonSelector)
            print(SkipAlertButtonSelector)
            print(AllowAlertButtonSelector)

            # Now we use one of the pre-defined wait rules which says
            # "Wait until the element we are looking for exists in the DOM and
            # also is visible".  Otherwise, fail.  The return value is
            # a DOM element or it might be a boolean if an alert is present

            WaitResult = None
            WaitResult = WaitObject.until( any_of(
                                            visibility_of_element_located(
                                                (By.ANDROID_UIAUTOMATOR,
                                                str(AddContactButtonSelector))),
                                            visibility_of_element_located(
                                                (By.ANDROID_UIAUTOMATOR,
                                                str(SkipAlertButtonSelector))),
                                            visibility_of_element_located(
                                                (By.ANDROID_UIAUTOMATOR,
                                                str(AllowAlertButtonSelector))),
                                            alert_is_present() ))

            if WaitResult == None:
                print('Failed to get WaitResult')
                return False
            if WaitResult == True:     # alert is present
                print('Alert is present')
                return False
            elif WaitResult == False:
                print('Alert is not present')
                return False

            # PrintElementInfo(WaitResult)

            # Find out if we got a popup or the AddContactButton
            # Need to do this before clicking any popup buttons
            # or else they disappear from the DOM and so we can't
            # look them up anymore

            ResourceID = str(TryGetAttribute(WaitResult, 'resource-id'))

            if not ResourceID:
                print('Unable to get ResourceID from WaitResult')
                return False

            print('Clicking button for: ' + str(WaitResult) )
            WaitResult.click()

            if ResourceID not in AddContactButtonSelector:
                print("We got a popup/alert instead of AddContactButton")
                print("So let's try again")
                continue

            # Now we have an empty contact form to fill
            # with random data
            AddContactFormInfo(WD)
            continue

        except TimeoutException as Exc:
            # This exception block happens if we waited
            # longer than 5 seconds to locate an element.
            print()
            print('Waited too long for element to appear')


        # end of try-except
    # end of infinite while loop
# end of function


def ScrollAndOpenSettingsItems(WD):

    if not WD:
        print("Invalid webdriver object")
        return False

    # Entering into infinite loop until we finish
    # X number of iterations of randomly scrolling
    # and viewing Settings pages.

    max_loops = 1
    current_loop = 0

    # This is from selenium, it is a wrapped retry-loop for
    # when it takes a little while for Android to populate a page with
    # elements.  So you can specify how long to wait.  We intentionally
    # ignore those 2 exceptions for this case. This just declares the
    # WaitObject to be used later.

    WaitObject = None
    WaitObject = WebDriverWait( driver = WD,
                                timeout = 10,
                                poll_frequency = 0.50,
                                ignored_exceptions = [
                                    NoSuchElementException,
                                    StaleElementReferenceException,
                                    InvalidSelectorException ])

    if not WaitObject:
        print('Failure creating WaitObject object')
        return False

    while True:

        # Exit after x iterations
        if current_loop > max_loops:
            break
        else:
            current_loop += 1

        # First wait for the ScrollContainer element to appear
        # which has all the various Settings items in the list

        print('Loop ' + str(current_loop) + '/' + str(max_loops) )
        print(  ': Waiting for ScrollContainer to appear')

        try:

            # Print some information about it.
            print('ScrollContainer is ready')
            # PrintElementInfo(ScrollContainer)

            # List of substrings of the text labels for settings app
            SettingsItemSubstrs = [ 'Network', 'Connected', 'Apps', 'Notifications', 'Battery',
                                    'Storage', 'Sound', 'Display', 'Wallpaper', 'Accessibility',
                                    'Security', 'Privacy', 'Location', 'Safety', 'Passwords',
                                    'Wellbeing', 'Google', 'System', 'About' ]

            # Select a random settings item from the list above
            RandomSettingsItem = SettingsItemSubstrs[
                                    random.randint(0, len(SettingsItemSubstrs)-1)]

            # Make a selector for it
            SettingsItemSelector = str( 'new UiSelector()' +
                                        '.resourceId("android:id/title")' +
                                        '.className("android.widget.TextView")' +
                                        '.textContains("' + RandomSettingsItem + '")' )

            print(  'Scrolling to a randomly selected Settings item: \n'
                    + SettingsItemSelector )

            # This library function scrolls a ScrollView element, which we already
            # found.  It can scroll up/down/left/right to locate a target
            # element in the list that is being scrolled.
            # For some reason it always returns None even when successful


            #ExecuteResult = None
            #ExecuteResult = WD.execute_script( 'mobile: scroll',
            #                                 { 'direction' : 'down',
            #                                   'elementId' : str(ScrollContainer.id),
            #                                   'strategy'  : str(By.ANDROID_UIAUTOMATOR),
            #                                   'selector'  : str(SettingsItemSelector),
            #                                   'maxSwipes' : 10,
            #                                   'speed'      : 500000 } )

            # Even though the above function gets the target element scrolled
            # into view, we need to locate it separately.

            SettingsItem = None
            SettingsItem = WaitObject.until(
                                visibility_of_element_located(
                                    (By.ANDROID_UIAUTOMATOR,
                                    str(SettingsItemSelector))))

            if not SettingsItem:
                print('Failed to retrieve SettingsItem information')
                return(False)

            # Print info
            # PrintElementInfo(SettingsItem)

            # Unfortunately, the clickable element to launch
            # one of the settings items is not the same as the one
            # which has the text label, and that kind of sucks.
            # Fortunately, we don't have to do any fancy stuff to find
            # them so we can click.  ActionChains has a simpler way.
            # It positions the mouse/touch pointer for an item in a
            # location where we can just click without specifying an element
            # to click on, and Android OS finds the right settings item
            # because it is underneath the pointer.

            # .pause(java.time.Duration.ofSeconds(2))

            print('Moving to the Settings item and clicking')

            SettingsItemActions = None
            SettingsItemActions = ActionChains(WD)
            SettingsItemActions.move_to_element(SettingsItem)
            SettingsItemActions.pause(0.50)
            SettingsItemActions.click()
            SettingsItemActions.perform()
            SettingsItemActions.pause(0.50)

            print("Completed SettingsItemActions.click and perform")

            # Wait for the new settings page to load and
            # the back/up button to exist and become visible

            NavigateUpSelector = str( 'new UiSelector()' +
                                      '.className("android.widget.ImageButton")' +
                                      '.descriptionMatches("Navigate up|Back")' +
                                      '.clickable(true)' )

            NavigateUpButton = None
            NavigateUpButton = WaitObject.until(
                                    visibility_of_element_located(
                                        (By.ANDROID_UIAUTOMATOR,
                                        str(NavigateUpSelector))))

            if not NavigateUpButton:
                print('Failed to retrieve NavigateUpButton information')
                return(False)

            # Print info
            print(str(NavigateUpSelector))
            # PrintElementInfo(NavigateUpButton)

            # Click the button
            print('Clicking Navigate Up')
            NavigateUpButton.click()

            continue

        except:

            # This exception block happens if we waited
            # longer than 5 seconds to locate an element.

            print()
            print('Waited too long for element to appear')


# start of main
#gc.set_debug(gc.DEBUG_LEAK)
#Driver = selenium.webdriver.Chrome()
#Driver.get("http://www.google.com") 
#quit()

#if not Driver:
#    print("Failed to initialize Appium")
#    exit()


#print(Driver.contexts)

# Driver.context("NATIVE_APP");
#Driver.switch_to.context("CHROMIUM");

SettingsAppPackage  = 'com.android.settings'
SettingsAppActivity = 'com.android.settings.Settings'
TestAppURL          = 'https://www.linkedin.com'


#MyTestApp = WebApp( UseAppium = True )
#if MyTestApp.StartApp( TestAppURL ):
#    print('App started successfully')
#    print(str(MyTestApp.AppPages))
    #MyTestApp.EnumerateElementTree()
    #MyTestApp.PageSourceToFile()
    #MyTestApp.ElementTreeToFile()
#    MyTestApp.ExitApp()
#    quit()
#else:
#    print('Failed to start app')
#    quit()

print("Hello")
        
MyTestApp = apps.AndroidSettingsApp() 

#NewPageClass = type( 'app_pages.AndroidAppPage', ( app_pages.AppPage, ), {} )
#Info(NewPageClass)
#NewPage = NewPageClass( Driver = 'asdf', App = 'asdf', Name = "asdfasd" )

MyTestApp.Test()


'''
<android.widget.LinearLayout index="0" package="com.android.settings" class="android.widget.LinearLayout" text="" resource-id="com.android.settings:id/homepage_container" checkable="false" checked="false" clickable="false" enabled="true" focusable="true" focused="false" long-clickable="false" password="false" scrollable="false" selected="false" bounds="[0,737][1080,2088]" displayed="true">
              <android.widget.FrameLayout index="1" package="com.android.settings" class="android.widget.FrameLayout" text="" resource-id="com.android.settings:id/main_content" checkable="false" checked="false" clickable="false" enabled="true" focusable="false" focused="false" long-clickable="false" password="false" scrollable="false" selected="false" bounds="[0,737][1080,2088]" displayed="true">
                <android.widget.LinearLayout index="0" package="com.android.settings" class="android.widget.LinearLayout" text="" resource-id="com.android.settings:id/container_material" checkable="false" checked="false" clickable="false" enabled="true" focusable="false" focused="false" long-clickable="false" password="false" scrollable="false" selected="false" bounds="[0,737][1080,2088]" displayed="true">
                  <android.widget.FrameLayout index="0" package="com.android.settings" class="android.widget.FrameLayout" text="" resource-id="android:id/list_container" checkable="false" checked="false" clickable="false" enabled="true" focusable="false" focused="false" long-clickable="false" password="false" scrollable="false" selected="false" bounds="[0,737][1080,2088]" displayed="true">
                    <androidx.recyclerview.widget.RecyclerView index="0" package="com.android.settings" class="androidx.recyclerview.widget.RecyclerView" text="" resource-id="com.android.settings:id/recycler_view" checkable="false" checked="false" clickable="false" enabled="true" focusable="true" focused="false" long-clickable="false" password="false" scrollable="false" selected="false" bounds="[0,737][1080,2088]" displayed="true">
''' 
        

# MyTestApp.EnumerateElementTree()
# MyTestApp.PageSourceToFile()
# MyTestApp.ElementTreeToFile()

#PageSource = Driver.page_source

#HTMLDoc = lxml.html.fromstring(PageSource)
#HTMLString = lxml.etree.tostring(HTMLDoc)

#XMLTree = ET.canonicalize( xml_data = HTMLString, strip_text = True )

#XMLNode = ET.fromstring( XMLTree )

# TestApp = AndroidApp(Driver)


# Driver.start_recording_screen()

#
# ----- Settings App ---------
#

#Driver.start_activity(SettingsAppPackage, SettingsAppActivity)

# ScrollTest(Driver)


# ScrollAndOpenSettingsItems(Driver)

# Driver.terminate_app(SettingsAppPackage)

#
# ----- Contacts App ---------
#

# ContactsAppPackage  = 'com.google.android.contacts'
# ContactsAppActivity = 'com.android.contacts.activities.PeopleActivity'

#Driver.start_activity(ContactsAppPackage, ContactsAppActivity)
#AddContacts(Driver)
#Driver.terminate_app(ContactsAppPackage)

#Driver.quit()
#exit()



'''
Only shell,execEmuConsoleCommand,dragGesture,flingGesture,doubleClickGesture,clickGesture,longClickGesture,pinchCloseGesture,pinchOpenGesture,swipeGesture,scrollGesture,scrollBackTo,scroll,viewportScreenshot,viewportRect,deepLink,startLogsBroadcast,stopLogsBroadcast,acceptAlert,dismissAlert,batteryInfo,deviceInfo,getDeviceTime,changePermissions,getPermissions,performEditorAction,startScreenStreaming,stopScreenStreaming,getNotifications,listSms,type,sensorSet,pushFile,pullFile,pullFolder,deleteFile,isAppInstalled,queryAppState,activateApp,removeApp,terminateApp,installApp,clearApp,startActivity,startService,stopService,broadcast,getContexts,installMultipleApks,unlock,refreshGpsCache,startMediaProjectionRecording,isMediaProjectionRecordingRunning,stopMediaProjectionRecordin
'''