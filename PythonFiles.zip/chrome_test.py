import sys, os
from trio_cdp import open_cdp, page, dom





async def test():


    async with open_cdp(cdp_url) as conn:
        ...
        # Find the first available target (usually a browser tab).

    # Find the first available target (usually a browser tab).
        targets = await target.get_targets()
        target_id = targets[0].id


