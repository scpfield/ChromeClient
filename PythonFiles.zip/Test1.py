import sys, os



def SumsOf3And5( TestCase ):

    
    if ((TestCase >= 1) and
        (TestCase < pow(10, 9))):

        CountOf3    = (TestCase - 1) // 3
        CountOf5    = (TestCase - 1) // 5
        CountOf15   = (TestCase - 1) // 15
        
        SumOf3  = int(((CountOf3  *  3) * (CountOf3  + 1)) / 2)
        SumOf5  = int(((CountOf5  *  5) * (CountOf5  + 1)) / 2)
        SumOf15 = int(((CountOf15 * 15) * (CountOf15 + 1)) / 2)
        
        Total = (SumOf3 + SumOf5) - SumOf15
        
        print(Total)


def EvenFibonacci( TestCase ):

    if ((TestCase >= 10) and
        (TestCase <= (4 * pow(10, 16)))):

        PrevPrev    = 0
        Prev        = 1
        Current     = 1
        SumOfEven   = 0
        
        for x in range( TestCase ):
                        
            if ( Current % 2 == 0 ) and ( Current <= TestCase ):
                SumOfEven += Current
            
            PrevPrev = Prev
            Prev = Current
            Current = Prev + PrevPrev
        
        print(SumOfEven)
            
                
            
                       
            
            


if __name__ == '__main__':

    Input = [2, 10, 100]
    
    EvenFibonacci(100)
  

    