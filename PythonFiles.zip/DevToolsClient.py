import sys, os
import multiprocessing as mp
import multiprocessing.managers as mpm
import time, subprocess, websocket, requests, signal, cdp
from colorama import Fore, Back, Style, init as colorama_init
from util import *
from javascript_injection import *


GlobalChromeClient    = None
    
    
class ClientInitException(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

class StopThreadCommand(BaseException):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

            
class CDPReturnValue():

    def __init__(self, JSONMessage):
        self.JSONMessage    = JSONMessage
        self.ID             = JSONMessage.get( 'id' )
        self.Method         = JSONMessage.get( 'method' )
        self.Result         = JSONMessage.get( 'result' )
        self.Params         = JSONMessage.get( 'params' )
        self.Error          = JSONMessage.get( 'error' )

        if self.Result:
        
            self.ExceptionDetails = self.Result.get( 'exceptionDetails' )
            if self.ExceptionDetails:
                self.Error = self.ExceptionDetails
        
            if self.Result.get('result'):
                self.Result = self.Result.get('result')

        self.CDPObject      = None
        self.ResultColor    = Style.BRIGHT  + Fore.CYAN   + Back.BLACK
        self.ErrorColor     = Style.BRIGHT  + Fore.RED      + Back.BLACK
        self.LabelColor     = Style.BRIGHT  + Fore.WHITE    + Back.BLACK
        self.FailLabelColor = Style.BRIGHT  + Fore.WHITE    + Back.BLACK
        self.ResetColor     = Style.RESET_ALL        
    
    def IsError( self ):
        return True if self.Error != None else False
        
    def PrintObject( self ):
        print( '', Decorate = False )
        print(  self.LabelColor + "Result (CDP Object): " +
                self.ResetColor, Decorate=False)
        print(  self.ResultColor + str(self.CDPObject) + self.ResetColor, 
                Truncate=None, Decorate=False)
                
    def PrintMessage( self ):
        print( '', Decorate = False )
        print(  self.LabelColor + "Full Message (JSON): " +
                self.ResetColor, Decorate=False)
        print(  self.ResultColor + json.dumps(self.JSONMessage, indent=1) + self.ResetColor, 
                Truncate=None, Decorate=False)
    
    def Print( self ):
        print( '', Decorate = False )
        if self.Error == None:
            print(  self.LabelColor + "Result (JSON): " +
                    self.ResetColor, Decorate=False)
            print(  self.ResultColor + json.dumps(self.Result, indent=1) + self.ResetColor, 
                    Truncate=None, Decorate=False)
        else:
            print(  self.FailLabelColor + "Error Result (JSON): " +
                    self.ResetColor, Decorate=False)
            print(  self.ErrorColor + json.dumps(self.Error, indent=1) + self.ResetColor, 
                    Truncate=None, Decorate=False)
                    
    ...  # end of CDPResult class

class CDPEvent():

    def __init__(self, JSONMessage):
        self.JSONMessage    = JSONMessage
        self.Method         = JSONMessage.get( 'method' )
        self.Result         = JSONMessage.get( 'result' )
        self.Params         = JSONMessage.get( 'params' )
        self.Error          = JSONMessage.get( 'error' )
        self.CDPObject      = None
        self.ResultColor    = Style.BRIGHT  + Fore.CYAN   + Back.BLACK
        self.ErrorColor     = Style.BRIGHT  + Fore.RED      + Back.BLACK
        self.LabelColor     = Style.BRIGHT  + Fore.WHITE    + Back.BLACK
        self.FailLabelColor = Style.BRIGHT  + Fore.WHITE    + Back.BLACK
        self.ResetColor     = Style.RESET_ALL
        self.CDPObject      = cdp.util.parse_json_event( JSONMessage )


    def PrintObject( self ):
        print( '', Decorate = False )
        print(  self.LabelColor + "Event (CDP Object): " +
                self.ResetColor, Decorate=False)
        print(  self.ResultColor + str(self.CDPObject) + self.ResetColor, 
                Truncate=None, Decorate=False)
    
    def PrintMessage( self ):
        print( '', Decorate = False )
        print(  self.LabelColor + "Full Event Message (JSON): " +
                self.ResetColor, Decorate=False)
        print(  self.ResultColor + json.dumps(self.JSONMessage, indent=1) + self.ResetColor, 
                Truncate=None, Decorate=False)







class ChromeEventProcessor( mp.Process ):

    def __init__( self, ChromeClient, name = 'ChromeEventProcess', daemon = True ):
    
        super().__init__( name = name, daemon = daemon)
        self.name                   = name
        self.daemon                 = daemon
        self.ChromeClient           = ChromeClient
        self.EventDataLockAcquired  = False
        
        
    def run( self ):
    
        def Teardown():
            print(self.name + ': Clearing ProcessReadyEvent')
            self.ProcessReadyEvent.clear()
            if self.EventDataLockAcquired:
                print(self.name + ': Releasing EventDataLock')
                self.ChromeClient.EventDataLock.release()
                self.EventDataLockAcquired = False
        ...  # end of Teardown
        
        print(self.name + ': is alive!')
        print(self.name + ': Setting ProcessReadyEvent')
        self.ProcessReadyEvent.set()
        
        
        try:

            while True:
                JSONMessage = None
                print(self.name + ': Waiting for new Chrome Event')
                if self.ChromeClient.EventDataEvent.wait(30):
                    print(self.name + ": Finished waiting")
                    if self.ChromeClient.EventDataLock.acquire():
                        self.EventDataLockAcquired = True
                        if len(self.ChromeClient.EventData) == 0:
                            print(self.name + ': ERROR: EventData is empty!')
                        if len(self.ChromeClient.EventData) > 1:
                            print(self.name + ': ERROR: EventData has multiple msgs')
                        if len(self.ChromeClient.EventData) == 1:
                            JSONMessage = self.ChromeClient.EventData.pop(0)
                        self.ChromeClient.EventDataLock.release()
                        self.EventDataLockAcquired = False
                    else:
                        print(self.name + ': ERROR: Failed to acquire data lock')
                else:
                    print(self.name + ': ERROR: Failed waiting for EventDataEvent')
                    
                if JSONMessage != None:
                    print(self.name + ': Got Chrome Event message')
                    EV = CDPEvent( JSONMessage )
                    EV.PrintMessage()
                    EV.PrintObject()
                else:
                    print(self.name + ': ERROR: No event message available')
                    
            ...  # end of event processing loop        
                
            Teardown()
            print(self.name + ': Exiting')
            return True
        
        except SystemExit:
            print(self.name + ": Received SystemExit")
        except InterruptedError:
            print(self.name + ": Received InterruptedError")
        except KeyboardInterrupt:
            print(self.name + ": Received KeyboardInterrupt" )
        except BaseException as e:
            print(self.name + ": Received BaseException" )
            GetExceptionInfo(e)
        except:
            print(self.name + ": Received exception")
        finally:
            Teardown()
            print(self.name + ': Exiting')
            return True
        
        
class ChromeClient( mp.Process ):

    def __init__( self, name = 'ChromeClientProcess', daemon = True ):
        global GlobalChromeClient
        GlobalChromeClient = self
        super().__init__( name = name, daemon = daemon)
        
        self.name               = name
        self.daemon             = daemon
        self.CallData           = []
        self.EventData          = []
        self.CallDataLock       = None
        self.EventDataLock      = None
        self.CallDataEvent      = None
        self.EventDataEvent     = None
        self.ProcessReadyEvent  = None
        self.CallDataLockAcquired   = False
        self.EventDataLockAcquired  = False
        self.TargetWebSocket    = None
        self.Launcher           = None
        self.ChromeProcess      = None
        self.CallCounter        = 0
        self.CurrentTab         = 0

        print("Calling start()")
        self.start()
        time.sleep(10)
        
        if self.TargetWebSocket:
            print(self.TargetWebSocket)
        else:
            print("No TargetWebSocket")
        ...
   
    def __getstate__(self):
        print("__getstate__")
        State = self.__dict__.copy()
        return State

    def __setstate__(self, State):
        print("__setstate__")
        self.__dict__.update(State)
        self.InitializePostSpawn()
        
    def InitializePostSpawn(self):
        global GlobalChromeClient
        GlobalChromeClient      = self
        
        print("Initializing Post-Spawn")
        
        self.Launcher           = ChromeLauncher()
        self.ChromeProcess      = self.Launcher.Launch()
        self.CallDataLock       = mp.RLock()
        self.EventDataLock      = mp.RLock()        
        self.CallDataEvent      = mp.Event()
        self.EventDataEvent     = mp.Event()
        self.ProcessReadyEvent  = mp.Event()
        

        if (( not self.Launcher ) or
            ( not self.ChromeProcess )):
                raise ClientInitException
                    
        self.BrowserTargetInfo  = self.Launcher.GetBrowserTargetInfo()        
        self.PageTargetInfo     = self.Launcher.GetPageTargetInfo( 
                                       PageIdx = self.CurrentTab )
        
        self.CurrentTargetInfo = None
        self.CurrentTargetInfo = self.BrowserTargetInfo

        if (( not self.BrowserTargetInfo ) or
            ( not self.PageTargetInfo    )):
                raise ClientInitException
                
        
    def stop( self ):
        print("ChromeClient: Stop called")
        self.terminate()
        self.kill()
        self.close()

    #def start( self ):
    #    super().start()
        '''
        if self.is_alive():
            print(self.name + ": is already alive")
            return False
        
        print(self.name + ": Starting process")
        super().start()
        
        print(self.name + ": Waiting for process ready state (blocking)")
        if self.ProcessReadyEvent.wait():
            print(self.name + ': Process is ready')
            return True
        else:
            print(self.name + ': Failed waiting for ready state')
            return False
        '''
    ...   
    
        
    def run( self ):
        
        def OnOpen( WebSocketApp ):
            print(f'OnOpen called')
            self.ProcessReadyEvent.set()
            #self.EventDataThread.start()
            
        def OnClose( WebSocketApp, Status, Message ):
            print(f'OnClose called')
            print(f'OnClose: Status={Status} ' +
                  f'Message: {Message}')
            return True

        def OnError( WebSocketApp, Error ):
            print(f'OnError called')
            print(f'OnError Error: {Error}')
            return True

        def OnPing( WebSocketApp ):
            print(f'OnPing called')
            return True

        def OnPong( WebSocketApp, ByteData ):
            print(f'OnPong called')
            return True

        def OnContMessage( WebSocketApp, Message, Flag ):
            print(f'OnContMessage called')
            Pause()
            return True
            
        def OnMessage( WebSocketApp, Message ):
            print(f'OnMessage called')
            print(f'Message: {Message}')
            return True

        def OnData( WebSocketApp, Data, Format, Cont ):
                    
            if Data == None:
                print('OnData: Data is None')
                Pause()
                return False
                
            JSONMessage = None
                
            try:
                JSONMessage = json.loads( Data )
            except BaseException as e:
                print('Failed to convert to JSON')
                GetExceptionInfo(e)
                Pause()
                return False
                    
            ID = JSONMessage.get('id')
            
            if ID != None:
                if self.CallDataLock.acquire( blocking = True ):
                    self.CallDataLockAcquired = True
                    self.CallData.append( JSONMessage )
                    self.CallDataLock.release()
                    self.CallDataLockAcquired = False
                    self.CallDataEvent.set()
                    self.CallDataEvent.clear()
                    return True
                else:
                    print('Thread: Failed to acquire CallDataLock')
                    Pause()
                    return False
            else:                               
                if self.EventDataLock.acquire( blocking = True ):
                    self.EventDataLockAcquired = True
                    self.EventData.append( JSONMessage )
                    self.EventDataLock.release()
                    self.EventDataLockAcquired = False
                    self.EventDataEvent.set()
                    self.EventDataEvent.clear()
                    return True
                else:
                    print('Thread: Unable to acquire EventDataLock')
                    Pause()
                    return False
        
        def Teardown():
            print(self.name + ': Clearing ProcessReadyEvent')
            self.ProcessReadyEvent.clear()
            if self.CallDataLockAcquired:
                print(self.name + ': Releasing CallDataLock')
                self.CallDataLock.release()
                self.CallDataLockAcquired = False
            if self.EventDataLockAcquired:
                print(self.name + ': Releasing EventDataLock')
                self.EventDataLock.release()
                self.EventDataLockAcquired = False
            print(self.name + ': Clearing CallDataEvent')
            self.CallDataEvent.clear()
            print(self.name + ': Clearing EventDataEvent')
            self.EventDataEvent.clear()
            #print(self.name + ": Stopping EventDataThread" )
            #self.EventDataThread.stop()
            if self.TargetWebSocket:
                if self.TargetWebSocket.sock:
                    print(self.name + ': Closing TargetWebSocket')
                    self.TargetWebSocket.close()            
        
        # end of all the internal functions
        
        print(self.name +': Process is alive')
        
        try:
        
            URL = self.CurrentTargetInfo.get('webSocketDebuggerUrl')
          
            self.TargetWebSocket    = websocket.WebSocketApp(
                url                 = URL,
                on_open             = OnOpen,
                #on_message          = OnMessage,
                on_cont_message     = OnContMessage,
                on_data             = OnData,                
                on_error            = OnError,
                on_close            = OnClose )
            
            print(f'Opened WS-URL: {self.TargetWebSocket.url}')
            
            mp.parent_process().TargetWebSocket = self.TargetWebSocket
            
            print(mp.parent_process().pid)
            
            self.TargetWebSocket.run_forever()
            
            Teardown()
            print(self.name + ': Exiting thread')
            return True

        except SystemExit:
            print(self.name + ": Received SystemExit")
        except InterruptedError:
            print(self.name + ": Received InterruptedError")            
        except KeyboardInterrupt:
            print(self.name + ": Received KeyboardInterrupt" )
        except BaseException as e:
            print(self.name + ": Received BaseException" )
            GetExceptionInfo(e)        
        finally:
            Teardown()
            print(self.name + ': Exiting thread')
            return True
        
    def GetSessions( self ):

        print("Getting Sessions")
        
        time.sleep(5)
        
        Result = self.Execute( cdp.target.attach_to_browser_target )
        self.BrowserSessionID = Result.CDPObject

        self.stop()
        self.CurrentTargetInfo = self.PageTargetInfo
        self.start()            
        
        Result = self.Execute(  cdp.target.attach_to_target, 
                                target_id = cdp.target.TargetID(
                                            self.CurrentTargetInfo['id']),
                                flatten = True )
                                
        self.PageSessionID = Result.CDPObject
                                
        Result = self.Execute(  cdp.target.set_auto_attach, 
                                    auto_attach = True, 
                                    flatten = True,
                                    wait_for_debugger_on_start = True )
        
        ...     # end of GetSessions
        
    def Execute( self, CDPMethod, **kwargs ):
        
        # this returns a generator initialized with the args
        Generator           = CDPMethod( **kwargs )
        
        # this yelds a dictionary of the call + args
        # note:  send(None) == next(Generator)
        CDPMethodDict       = Generator.send( None )
        
        # add the CallCounter to it
        CDPMethodDict['id'] = self.CallCounter
        
        # add the ID to it
        if hasattr(self, 'PageSessionID'):
            CDPMethodDict['sessionId'] = self.PageSessionID
        
        # print request
        LabelColor  = Style.BRIGHT + Back.BLACK + Fore.WHITE
        CallColor   = Style.BRIGHT + Back.BLACK + Fore.YELLOW
        Reset       = Style.RESET_ALL

        print()
        print( f"{LabelColor}Execute: {Reset}", Decorate=False)
        print( f"{CallColor}{json.dumps(CDPMethodDict,indent=1)}{Reset}", Decorate=False )
        
        # send to WebSocket
        self.TargetWebSocket.send( json.dumps( CDPMethodDict ))
        
        # increment call counter
        self.CallCounter += 1
        
        # wait for reply
        JSONMessage = None
        RV          = None
        
        try:
            if self.CallDataEvent.wait():
                if self.CallDataLock.acquire():
                    self.CallDataLockAcquired = True
                    if len(self.CallData) == 0:
                        print(self.name + ": ERROR: CallData is empty")
                    if len(self.CallData) > 1:
                        print(self.name + ': ERROR: CallData has multiple msgs')
                    JSONMessage = self.CallData.pop(0)
                    self.CallDataLock.release()     
                    self.CallDataLockAcquired = False
                else:
                    print('Failed to acquire lock')
                    return None
            else:
                print(self.name + ": Failed waiting for CallDataEvent")
                return None
                
        except SystemExit:
            print(self.name + ": Received SystemExit")
            if self.CallDataLockAcquired:
                self.CallDataLock.release()     
                self.CallDataLockAcquired = False            
            RV = self.CloseChrome()
            if RV != None:
                RV.Print()
        except InterruptedError:
            print(self.name + ": Received InterruptedError")                
        except KeyboardInterrupt:
            print(self.name + ": Received KeyboardInterrupt" )
        except BaseException as e:
            print(self.name + ": Received BaseException" )
            GetExceptionInfo(e)        
        finally:
            if self.CallDataLockAcquired:
                self.CallDataLock.release()     
                self.CallDataLockAcquired = False
            self.stop()
                
            
        if JSONMessage == None:
            print( 'Execute: Received None for JSONMessage' )
            return None
        
        RV          = CDPReturnValue( JSONMessage )
        CDPObject   = None
            
        if RV.ID != ( self.CallCounter - 1):
            print(  f'Execute: ResponseID {RV.ID} != ' +
                    f'RequestID {self.CallCounter-1}' )
            Pause()
        
        if RV.Result != None and RV.Error == None:
            try:
                Generator.send( JSONMessage['result'] )
            except StopIteration as ActualResult:
                RV.CDPObject = ActualResult.value
            except BaseException as _BaseException:
                print("Got Exception")
                GetExceptionInfo(_BaseException)
                RV.Error = _BaseException
        
        RV.Print()
        
        return RV
        ...     # end of Execute
    
    
    def CloseChrome( self ):
        if  (( self.ChromeProcess        )  and
             ( self.is_alive()           )  and
             ( self.TargetWebSocket      )  and 
             ( self.TargetWebSocket.sock )):
                return self.Execute( cdp.browser.close )
            
    
    def Evaluate(   self, Script, 
                    ReturnByValue = False, 
                    GenerateWebDriverValue = False ):
    
        print( f'Script: {Script}')
        
        RV = self.Execute( 
            cdp.runtime.evaluate,
            expression = Script,
            object_group = RandomString(10),
            include_command_line_api = True,
            silent = False,
            # contextID = None
            return_by_value = ReturnByValue,
            generate_preview = False,
            user_gesture = True,
            await_promise = True,
            throw_on_side_effect = False,
            timeout = cdp.runtime.TimeDelta(60000),
            disable_breaks = True,
            generate_web_driver_value = GenerateWebDriverValue,
            repl_mode = True,
            allow_unsafe_eval_blocked_by_csp = True)

        return RV

        
        

    
    def DumpProperties( self, ObjectID, OwnProps = False, Level = None, MaxLevel = 1 ):
    
        if not ObjectID:
            Pause("Error, DumpProperties called without ObjectID")
            return None
    
        if Level == None:
            Level = 0
            
        #print("Level = " + str(Level))
    
        print("Dumping Object_ID: ", ObjectID)
        RV = self.Execute(  cdp.runtime.get_properties, 
                                    object_id = ObjectID,
                                    own_properties = OwnProps,
                                    accessor_properties_only = False,
                                    generate_preview = False,
                                    non_indexed_properties_only = False )
                                    
        if not RV.CDPObject: return None, None, None, None
        Properties = RV.CDPObject
        Regular = Internal = Private = Error = None
        
        if len(Properties) == 4:
            (Regular, Internal, Private, Error) = Properties
        
        if len(Properties) == 3:
            (Regular, Internal, Private) = Properties
        
        # Pause("Counts of Properties:")
        if Regular:  print(f"Regular   : {len(Regular)}")
        if Internal: print(f"Internal  : {len(Internal)}")
        if Private:  print(f"Private   : {len(Private)}")
        if Error:    print(f"Error     : {len(Error)}")
        
        # Pause("Contents of Properties:")
        if Regular:
            for Item in Regular:
                #print(Item)
                if (( hasattr(Item, 'value')) and 
                    ( hasattr(Item.value, 'object_id') )): 
                        PropertyObjectID = Item.value.object_id
                        if not PropertyObjectID:
                            continue
                        if Level < MaxLevel:
                            #print("About to recurse dump for: " + PropertyObjectID)
                            ValueProperties = self.DumpProperties(PropertyObjectID, 
                                                                    OwnProps = True, 
                                                                    MaxLevel = MaxLevel, 
                                                                    Level = (Level + 1))
                            #print("Popped back out of recursion, level = " + str(Level))
                            if ValueProperties and len(ValueProperties) > 0:
                                #print("len subobject: ", len(ValueProperties))
                                #print("Added subobject to item.value: ", Item.value)
                                try:
                                    value = Item.value.__dict__.get('value')
                                    if value == None:
                                        Item.value.__dict__['value'] = ValueProperties[0]
                                    else:
                                        Item.value.__dict__['objects'] = ValueProperties[0]
                                    #del Item.value.__dict__['object_id']
                                except BaseException as e:
                                    print("Got some exception")
                                    GetExceptionInfo(e)
                                    ...
                        else:
                            ...
                            #print("Level is maxed, not recursing: " + str(Level))
                
                #PrintJSON(Item, Truncate = 1024)
          #      Pause()
        
        if Internal:  
            print("INTERNAL")
            PrintJSON(Internal)
            for Item in Internal:
                #print(Item)
                if Item.name == '[[Prototype]]':
                    if (( Item.value.class_name == 'MouseEvent') or 
                        ( 'MouseEvent' in Item.value.description)):
                            print("Found MouseEvent prototype item")
                            PrototypeID = Item.value.object_id
                            print(PrototypeID)
                            ValueProperties = self.DumpProperties(PrototypeID, 
                                                                    OwnProps = True, 
                                                                    MaxLevel = MaxLevel, 
                                                                    Level = (Level + 1))
                            
                            if ValueProperties and len(ValueProperties) > 0:
                                #print("len subobject: ", len(ValueProperties))
                                #print("Added subobject to item.value: ", Item.value)
                                try:
                                    value = Item.value.__dict__.get('value')
                                    if value == None:
                                        Item.value.__dict__['value'] = ValueProperties[0]
                                    else:
                                        Item.value.__dict__['objects'] = ValueProperties[0]
                                    #del Item.value.__dict__['object_id']
                                except BaseException as e:
                                    print("Got some exception")
                                    GetExceptionInfo(e)
                                    ...                                                                    
                
                if Item.name == '[[FunctionLocation]]':
                    LocationObjectID = Item.value.object_id
                    print(LocationObjectID)
                    RV = self.Execute( cdp.debugger.get_script_source, script_id = cdp.runtime.ScriptId('45') )
                    RV.Print()
                    Pause()
                    
        if Private:  
            print("PRIVATE")
            PrintJSON(Private)
            Pause()
        if Error:  
            print("ERROR")
            PrintJSON(Error)
            Pause()
        
        return Properties
    
    def Test( self ):
    
        print()
        print("BrowserSessionID : " + self.BrowserSessionID)
        print("PageSessionID    : " + self.PageSessionID)
        print()
        
        
        self.Execute( cdp.log.enable )
        self.Execute( cdp.page.enable ) 
        
        self.Execute(  cdp.page.add_script_to_evaluate_on_new_document,
                        source = AddPageLoadListeners, 
                        world_name = None, 
                        include_command_line_api = True)

        self.Execute( cdp.dom.enable )
        self.Execute( cdp.dom_snapshot.enable )
        self.Execute( cdp.dom_storage.enable )
        self.Execute( cdp.debugger.enable )
        self.Execute( cdp.runtime.enable )
        self.Execute( cdp.css.enable )
        self.Execute( cdp.network.enable )
        # self.Execute( cdp.fetch.enable )
        self.Execute( cdp.accessibility.enable )
        self.Execute( cdp.audits.enable )
        self.Execute( cdp.inspector.enable )
        self.Execute( cdp.overlay.enable )
        self.Execute( cdp.profiler.enable )
        self.Execute( cdp.performance.enable )
        self.Execute( cdp.service_worker.enable )
        self.Execute( cdp.layer_tree.enable )
        self.Execute( cdp.media.enable )
        self.Execute( cdp.console.enable )
        self.Execute( cdp.cast.enable )
        self.Execute( cdp.database.enable )
        self.Execute( cdp.animation.enable )
        self.Execute( cdp.indexed_db.enable )
        self.Execute( cdp.heap_profiler.enable )
        self.Execute( cdp.heap_profiler.enable )
        self.Execute( cdp.security.enable )
        self.Execute( cdp.web_authn.enable )
        
        TimelineEvents = [ 'mark', 'measure', 'navigation', 'resource',
                           'longtask', 'paint', 'element', 'first-input',
                           'layout-shift', 'largest-contentful-paint' ]
                           
        self.Execute(   cdp.performance_timeline.enable,
                        event_types = TimelineEvents)
        
        #self.Execute( cdp.background_service.start_observing )
        self.Execute( cdp.storage.get_trust_tokens )
        self.Execute( cdp.schema.get_domains )
        
        Result = self.Execute( cdp.system_info.get_feature_state,
                                feature_state='*')
    
        self.Execute( cdp.tracing.get_categories )
        Result = self.Execute( cdp.runtime.get_isolate_id ) 
        
        Result = self.Execute( cdp.dom.get_document,
                               depth = -1, pierce = True)
                            
        URL = 'https://localhost:8834/#/'
        #self.Execute(   cdp.page.navigate, 
        #                url = URL )
                        #transition_type = cdp.page.TransitionType.TYPED,
                        #referrer_policy = cdp.page.ReferrerPolicy.NO_REFERRER )
        
        # Script = "return new XMLSerializer().serializeToString(document);"
        # Script = 'this.location'
        # Script = 'document'  # this gives all the event listener
        
        #Result = self.Execute( cdp.runtime.global_lexical_scope_names,
        #                        execution_context_id = cdp.runtime.ExecutionContextId(1) )
        
        #Result = self.Execute(  cdp.dom.set_node_stack_traces_enabled,
        #                        enable = True )
                            
        Result = self.Execute( cdp.dom.get_document,
                               depth = -1, pierce = True)
                              
        Result = self.Execute( cdp.dom.request_child_nodes,
                               node_id = cdp.dom.NodeId(0), depth = -1, pierce = True)

        
        Selector =  'button[data-domselect="sign-in"]'
        #Script =  f"testClick( '{Selector}' )"
        Script =  "getEventObject()"
        Script = "Object"
        Script = "launchDownloadsPage()"
        Script = "permissions()"
        Script = "attachInternals()"
        Script = "focus() / blur() / click()"
        Script = "getTypeMapping()"
        Script = "getPropertyType()"
        Script = "TrustedTypePolicyFactory"
        Script = "TrustedTypePolicy()"
        Script = "TrustedScript()"
        Script = "isTrusted() "
        Script = "startGame()"
        Script = "Object.startGame"
        Script = "isTrusted()"

        #Script = (  "function TestFunction() { " +
        #            " ABC = new MouseEvent('click'); " +
        #            " Reflect.set(ABC, 'isTrusted', true); " +
        #            " return ABC }; " +
        #            " TestFunction(); ")
                    
        #Script = ( "Reflect.deleteProperty(new MouseEvent('click'), 'isTrusted')")
        #Script = "window.trustedTypes.getPropertyType()"
        # window.trustedTypes.getTypeMapping()
        #Script = "Reflect"
        
        time.sleep(2)
        
        
        #RV = self.Execute( cdp.debugger.get_script_source, script_id = cdp.runtime.ScriptId('7') )

        # globalThis.etc
        # External, EventTarget, EventSource, MouseEvent, ElementInternals, NavigatorManagedData, Permissions,PermissionStatus, ConvolverNode, InputEvent
        # _Utils _Log _Messages _Properties _Session
        
        #Script = "const x = globalThis"
        #Script = "const X = new MouseEvent('click'); X;"
        
        print("*********************************************************")
        print("About to run script: " + Script)
        print("*********************************************************")
        
        
        #'{ "type": "MouseEvent", "value": { "a": 1, "b": 2 } }'
        #'{ "type": "MyClass", "value": { "a": 1, "b": 2 } }'
        
        print("Test returning")
        return
        
        Pause()
        
        RV = self.Evaluate( Script, ReturnByValue = False)

        
        RV.Print()
        RV.PrintObject()
        Pause("About to dump properties")

        Properties = self.DumpProperties( RV.CDPObject[0].object_id, MaxLevel = 2 )
        
        #InternalProperties = self.DumpProperties( RV.CDPObject[1].object_id, MaxLevel = 2 )
        
        if not Properties:
            return False
        
        Pause("About to write to disk")
        PrintJSON(Properties[0], FileName = "result-objects.json", Truncate = 1024)
        PrintJSON(Properties[1], FileName = "result-objects-internal.json", Truncate = 1024)
         
        ProtoTypeObjectID   = None
        ScopeObjectID       = None
        ProxyTargetID       = None
        HandlerObjectID     = None
        
        #IsTrustedProp = Properties[0][0]
        
        #print(IsTrustedProp)
        #PrintJSON(IsTrustedProp)
        
        #Pause()
        
        if Properties:
            if len(Properties[1]) > 0:
                # print(Properties[1], Truncate=1024)
                for Item in Properties[1]:
                    if Item.name == '[[Prototype]]':
                        ProtoTypeObjectID = Item.value.object_id
                    if Item.name == '[[Scopes]]':
                        ScopeObjectID = Item.value.object_id
                    if Item.name == '[[Target]]':
                        ProxyTargetID = Item.value.object_id
                    if Item.name == '[[Handler]]':
                        HandlerObjectID = Item.value.object_id                        

        print("ProtoTypeObjectID = " + str(ProtoTypeObjectID))
        print("ScopeObjectID = " + str(ScopeObjectID))
        print("ProxyTargetID = " + str(ProxyTargetID))
        print("HandlerObjectID = " + str(HandlerObjectID))        
        
        Pause()
        
        if ProtoTypeObjectID:
            
            # Properties = self.DumpProperties( ProtoTypeObjectID)
            
            RV = self.Execute(  cdp.runtime.query_objects,
                                prototype_object_id = ProtoTypeObjectID)
            
            if RV.IsError():
                return False
                
            RV.Print()
            Pause()
            
            InstanceProps = self.DumpProperties( RV.CDPObject.object_id, MaxLevel = 1 )
            InstanceList = InstanceProps[0]
            
            print("InstanceList length = " + str(len(InstanceList)))
            
            Pause()
            PrintJSON(InstanceList, FileName = "prototype-instances.json", Truncate = 1024)

            IsTrustedObjectID = None
            FoundInstance = None
            
            '''
            for Instance in InstanceList:
                if (( hasattr(Instance, 'value'))              and 
                    ( hasattr(Instance.value, 'description'))  and
                    ( 'isTrusted' in Instance.value.description )):
                        IsTrustedObjectID = Instance.value.object_id
                        FoundInstance = Instance
                        print("Found IsTrusted:")
                        PrintJSON(Instance)
                        Pause()
                        break
            '''
            
            '''
            #if IsTrustedObjectID:
            #    print("IsTrusted ObjectID = " + str(IsTrustedObjectID))
            #    IsTrustedProps = self.DumpProperties( IsTrustedObjectID, ToFile = True )
                
            ReleaseResult = self.Execute( cdp.runtime.release_object,
                                          object_id = IsTrustedObjectID )
            
            print(ReleaseResult)
            PrintJSON(ReleaseResult)
            
            #Script = f"delete {Instance.value};"
            #DeleteResult = self.Evaluate( Script, ReturnByValue = False, Traverse = False)
            
            Pause()
            
            ProtoTypeInstances = self.Execute(   cdp.runtime.query_objects,
                                                prototype_object_id = ProtoTypeObjectID )
                                                #object_group = RandomString(10) )  
                                        
            print(ProtoTypeInstances)
            PrintJSON(ProtoTypeInstances)
            
            Pause()
            
            InstanceProps = self.DumpProperties( ProtoTypeInstances.object_id, ToFile = True )
            InstanceList = InstanceProps[0]
            
            print("InstanceList length = " + str(len(InstanceList)))            
            
            IsTrustedObjectID = None
            
            for Instance in InstanceList:
            
                if (( hasattr(Instance, 'value'))              and 
                    ( hasattr(Instance.value, 'description'))  and
                    ( 'isTrusted' in Instance.value.description )):
                        IsTrustedObjectID = Instance.value.object_id
                        print("Found IsTrusted:")
                        PrintJSON(Instance.value)
                        break            
            Pause()
            '''
            #self.DumpProperties( IsTrustedObjectID, ToFile = True )
           
           
        '''
        if ScopeObjectID:
        
            Properties = self.DumpProperties( ScopeObjectID )

        Pause()
        
        if ProxyTargetID:
        
            Properties = self.DumpProperties( ProxyTargetID )

        Pause()
        
        if HandlerObjectID:
        
            Properties = self.DumpProperties( HandlerObjectID )

        Pause()
        '''

            
        '''
        if ProtoTypeObjectID:
            print(" PROTOTYPE OBJECT ")
            ProtoTypeObjects = self.Execute( cdp.runtime.query_objects,
                                            prototype_object_id = ProtoTypeObjectID,
                                            object_group = RandomString(10) )    
        
            print(type(ProtoTypeObjects))
            PrintJSON(ProtoTypeObjects, Truncate=1024)
            
            Properties = self.DumpProperties( ProtoTypeObjects.object_id, ToFile = True )

        
        if ScopeObjectID:
            print(" SCOPE OBJECT ")
            ScopeObjects = self.Execute( cdp.runtime.query_objects,
                                            prototype_object_id = ScopeObjectID,
                                            object_group = RandomString(10) )    
        
            print(type(ScopeObjects))
            PrintJSON(ScopeObjects, Truncate=1024)
            
            Properties = self.DumpProperties( ScopeObjects.object_id, ToFile = True )
        
        Pause()        

        ProtoTypeObjectID   = None
        ScopeObjectID       = None
        
        if Properties:
            if len(Properties[1]) > 0:
                print(Properties[1], Truncate=1024)
                for Item in Properties[1]:
                    if Item.name == '[[Prototype]]':
                        ProtoTypeObjectID = Item.value.object_id
                    if Item.name == '[[Scopes]]':
                        ScopeObjectID = Item.value.object_id

        print("ProtoTypeObjectID = " + str(ProtoTypeObjectID))
        print("ScopeObjectID = " + str(ScopeObjectID))
        Pause()
        
        if ProtoTypeObjectID:
            print(" PROTOTYPE OBJECT ")
            ProtoTypeObjects = self.Execute( cdp.runtime.query_objects,
                                            prototype_object_id = ProtoTypeObjectID,
                                            object_group = RandomString(10) )    
        
            print(type(ProtoTypeObjects))
            PrintJSON(ProtoTypeObjects, Truncate=1024)
            
            Properties = self.DumpProperties( ProtoTypeObjects.object_id, ToFile = True )

        
        if ScopeObjectID:
            print(" SCOPE OBJECT ")
            ScopeObjects = self.Execute( cdp.runtime.query_objects,
                                            prototype_object_id = ScopeObjectID,
                                            object_group = RandomString(10) )    
        
            print(type(ScopeObjects))
            PrintJSON(ScopeObjects, Truncate=1024)
            
            Properties = self.DumpProperties( ScopeObjects.object_id, ToFile = True )
        
        Pause()
    
            #RemoteNode = self.Execute( cdp.dom.describe_node,
            #                            object_id = Result.object_id )        
        
        '''
        
        #for Item in Regular:
        #    Info(Item)
        #    Pause()
        #    if Item.name == 'isTrusted':
        #        Item.__dict__['value'].__dict__['value'] = True
        #        break;
#            JSONString = Item.to_json()
#            if JSONString['name'] == 'isTrusted':
#                if JSONString['value']['value'] == False:
#                    Pause("About to set property")
#                    JSONString['value']['value'] = True
#                    Pause("Set property")
#                    print( JSONString['value']['value'] )
            
#            Item = Item.from_json(JSONString)

        
        
        #Script =  f"testClick('{Selector}, {Result}')"
        #print(Script)

        #print(Result)            
                    
        #Selector =  "button[data-domselect=\"sign-in\"]"
        #Button =  f"document.querySelector('{Selector}')"
        #Script = f"console.log(JSON.parse(JSON.stringify(this)));"
        #Script = "navigator.properties"
        #Script = f"console.log({Button})"
        # Script = "function foo() { function bar() { console.trace(); } bar();} foo();"
        
            #Script = "clear"
            #Clear = self.Evaluate( Script, Traverse=False, ReturnByValue = True )

            #Script = "$('div')"
            #RemoteArray = self.Evaluate( Script, Traverse=False, ReturnByValue = False )

            #print(RemoteArray)
            
        
        Pause("Exit Test normally")
    ...  # End of ChromeClient
    


def Teardown():
    print("Global Teardown called")
    if GlobalChromeClient:
        
        print('Closing Chrome gracefully')
        RV = GlobalChromeClient.CloseChrome()
        if RV != None:
            RV.Print()
        print('Stopping thread')
        GlobalChromeClient.stop()
    else:
        print("Global Teardown: No global chrome client")


def OSSignalHandler( Signal, Frame ):
    try:
        print( f'Caught Signal: {signal.strsignal(Signal)}' )
        
    except BaseException as e:
        GetExceptionInfo(e)
        print("OSSignalHandler exception " + str(e))
        
    finally:
        Teardown()
        
    ...


def main():

    try:
    
        signal.signal( signal.SIGINT,   OSSignalHandler )
        signal.signal( signal.SIGBREAK, OSSignalHandler )
        signal.signal( signal.SIGABRT,  OSSignalHandler )   
        colorama_init(autoreset=False)
        
        Pause("Test Pause")
        
        MyChromeClient = ChromeClient()

        
        while MyChromeClient.is_alive():  
            print("main: looping")
            for Item in mp.active_children():
                Info(Item._popen, Static=True)
            time.sleep(1)
        
        # ChromeClient.Test()
        #print("Test has returned")
        
        
    except SystemExit as se:
        # GetExceptionInfo(se)
        print('Main Exception: SystemExit')
    except InterruptedError as se:
        # GetExceptionInfo(se)
        print('Main Exception: InterruptedError')        
    except BaseException as be:
        print('Main Exception')
        GetExceptionInfo(be)
        #signal.raise_signal(signal.SIGINT)

    print('All Done. Exiting')



if __name__ == '__main__':
    main()
    







    
    