import sys, io, json, time, appium, selenium

    # C:\Users\Administrator\AppData\Roaming\Python\Python311\site-packages\selenium\webdriver\remote
    
from appium import *
from selenium import *
from selenium.webdriver import *
from selenium.webdriver.remote import *
from selenium.webdriver.remote.switch_to import SwitchTo
from selenium.webdriver.support.expected_conditions import staleness_of
from selenium.webdriver.support import *
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support.relative_locator import *

# WebDriverWait(driver, delay, ignored_exceptions=(NoSuchElementException,StaleElementReferenceException)).until(expected_conditions.presence_of_element_located((By.ID, "my_id"))).click()


from appium import webdriver
from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.common.touch_action import TouchAction
from selenium.common.exceptions import *
from appium.webdriver.switch_to import MobileSwitchTo

# For W3C actions
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions import interaction
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.pointer_input import PointerInput
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoSuchFrameException
from selenium.common.exceptions import NoSuchWindowException
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement


global PackageName
global Capabilities 
global CSS_SELECTOR
global AppiumServer
global WD           

PackageName     = "com.sitecapture.app.sitecapture.dev"
Capabilities    = {}
CSS_SELECTOR    = "css selector"
AppiumServer    = "http://127.0.0.1:4723"
WD              = None


def Initialize():

    global Capabilities
    global WD
        
    Capabilities = {}
    Capabilities["platformName"] = "Android"
    Capabilities["appium:platformVersion"] = "13"
    Capabilities["appium:deviceName"] = "emulator-5554"
    Capabilities["appium:app"] = "c:\\users\\administrator\\downloads\\sitecapture-dev-347.apk"
    Capabilities["appium:appPackage"] = PackageName
    Capabilities["appium:appActivity"] = "com.fotonotes.android.activity.LoginActivity"
    Capabilities["appium:automationName"] = "UiAutomator2"
    # Capabilities["appium:ensureWebviewsHavePages"] = True
    Capabilities["appium:nativeWebScreenshot"] = True
    # Capabilities["appium:newCommandTimeout"] = 30000
    Capabilities["appium:connectHardwareKeyboard"] = True
    Capabilities["appium:locationContextEnabled"] = True
    Capabilities["appium:noReset"] = False
    Capabilities["appium:autoGrantPermissions"] = True
    Capabilities["appium:showGradleLog"] = True
    Capabilities["appium:noSign"] = False
    # Capabilities["appium:eventTimings"] = True
    # Capabilities["appium:automationName"] = "Espresso"
    
    WD = webdriver.Remote(AppiumServer, Capabilities)
    WD.implicitly_wait(10)

    TouchActions = TouchAction(WD)
    ChainActions = ActionChains(WD)
    
    return(WD)


def TryGetAttribute(Element, Attribute):

    AttributeValue = ""    

    try:
        AttributeValue = Element.get_attribute(Attribute)
    except:
        print("Failed to get attribute: " + Attribute)

    return(AttributeValue)

 
def PrintElementInfo(Element):    

    if (not Element):
        print("Invalid element")
        return
            
    try:
        print("id           : " + str(Element.id))
    except:
        print("id:          : None")

    try:        
        print("accessible_name : " + str(Element.accessible_name))
    except:
        print("accessible_name : None")
    
    try:
        print("aria_role : " + str(Element.aria_role))
    except:
        print("aria_role : None")
    
    try:
        print("location : " + str(Element.location))
    except:
        print("location : None")
    
    try:
        print("location_once_scrolled_into_view : " + str(Element.location_once_scrolled_into_view))
    except:
        print("location_once_scrolled_into_view : None")
    
    try:
        print("size : " + str(Element.size))
    except:
        print("size : None")
    
    try:
        print("tag_name : " + str(Element.tag_name))
    except:
        print("tag_name : None")
    
    try:
        print("shadow_root : " + str(Element.shadow_root))
    except:
        print("shadow_root : None")
    
    
    AttributeList = [ "resource-id", "name", "text", "class", "package", "displayed", "checkable", "checked",  "clickable", "content-desc", "enabled", "focusable",
    "focused", "longClickable", "password", "scrollable", "selection-start", "selection-end", 
    "selected", "hint", "extras", "bounds", "contentSize" ]
    
    for Attribute in AttributeList:

        AttributeValue = TryGetAttribute(Element, Attribute)

        if (AttributeValue):
            print(Attribute + ": " + AttributeValue)
        else:
            print(Attribute + ": None")

    print("")
    


def Logon():
    global WD
    UserName       = "sam_stage_company1_field1"
    Password       = "test"
    UserNameID     = PackageName + ":id/editTextUsername"
    PasswordID     = PackageName + ":id/editTextPassword"
    LogonButtonID  = PackageName + ":id/buttonSignin"

    UserNameField  = WD.find_element(  by    = AppiumBy.ID, 
                                       value = UserNameID )

    PasswordField  = WD.find_element(  by    = AppiumBy.ID, 
                                       value = PasswordID )
                                            
    LogonButton    = WD.find_element(  by    = AppiumBy.ID, 
                                       value = LogonButtonID )

    print("Logon: Sending logon info")
    UserNameField.send_keys( UserName )
    PasswordField.send_keys( Password )                                 
    LogonButton.click()



def WaitForProjectListPage():
    global WD
    ProjectListID = "android:id/list"
    count = 0
    
    while True:
        count += 1
        print("Checking if project page is ready yet")
        try:
            ProjectList =   WD.find_element( 
                            by    = AppiumBy.ID, 
                            value = ProjectListID )
                            
            if not ProjectList:
                continue

            if TryGetAttribute( ProjectList, "displayed" ):
                print("Project page has displayed")
                return ProjectList

        except:
            pass
           
        if (count > 10):
            print("Exceeded max loops")
            WD.quit()
            exit()

        # time.sleep(1)


def EnumerateProjectList(ProjectList):
    global WD

    ProjectListItemsID  =  "[clickable=true][class-name=android.widget.RelativeLayout]"
    ProjectItemID       =  PackageName + ":id/displayLine1"

    print("")
    print(  "EnumerateProjectList: Looking for: " + 
            ProjectListItemsID)

    ProjectListItems =  ProjectList.find_elements(
                        by    = CSS_SELECTOR, 
                        value = ProjectListItemsID)

    if not ProjectListItems:
        print("EnumerateProjectList: No projects found") 
        exit()   
        
    print(  "EnumerateProjectList: Found projects: " + 
            str(len(ProjectListItems)))
                        
    if ProjectListItems:    
        for ProjectListItem in ProjectListItems:
    
            print("------------------------")
            print("Looking for     : " + ProjectItemID )
            print("ProjectListItem : " + ProjectListItem.id)
            
            ProjectInfo =   ProjectListItem.find_element(
                            by    = AppiumBy.ID, 
                            value = ProjectItemID )
            
            if not ProjectInfo:
                print("EnumerateProjectList: Failed to locate project")
                exit()

            print(  "ProjectInfo.id   : " + ProjectInfo.id)
            print(  "ProjectInfo.text : " + 
                    TryGetAttribute(ProjectInfo, "text"))
    
    return ProjectList


def AddProject(ProjectList):
    global WD

    AddProjectButtonID  =   "[id=" +        \
                            PackageName +   \
                            ":id/floating_add_button]"

    print("")
    print("AddProject: Looking for: " + AddProjectButtonID)

    AddProjectButton =  WD.find_element(
                        by    = AppiumBy.CSS_SELECTOR, 
                        value = AddProjectButtonID )
                                    
    if AddProjectButton:
        print("Found Add Project button")
        AddProjectButton.click()
    


WD = Initialize()
Logon()
ProjectList = WaitForProjectListPage()
ProjectList = EnumerateProjectList(ProjectList)
AddProject(ProjectList)
WD.quit()
exit()

'''
# 
# Add a project
#
AddProjectButtonID  = PackageName + ":id/floating_add_button"
TemplateListID      = "android:id/list"

AddProjectButton = driver.find_element(  by    = AppiumBy.ID, 
                                         value = AddProjectButtonID )
                                         
AddProjectButton.click()

#ANDROID_VIEW_MATCHER
#ANDROID_DATA_MATCHER

TemplateList = driver.find_element(  by    = AppiumBy.ID, 
                                     value = TemplateListID )
                                     
if (TemplateList):

    print("TemplateList is something")
    print(str(TemplateList))

    TemplateListItem = TemplateList.find_element(  by = AppiumBy.ANDROID_DATA_MATCHER,
                                                   value = { "name" : "hasEntry", 
                                                             "args" : ["index", "0"] } )

    if (TemplateListItem):
        print("Got a TemplateListItem")
        print(str(TemplateListItem))



# TemplateListItem = driver.find_element(by=AppiumBy.XPATH, value="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[10]")
# TemplateListItem.click()

CreateProjectButton = driver.find_element(by=AppiumBy.ID, value="com.sitecapture.app.sitecapture.dev:id/done_button")
CreateProjectButton.click()

SectionLabelButton = driver.find_element(by=AppiumBy.ID, value="com.sitecapture.app.sitecapture.dev:id/section_label")
SectionLabelButton.click()

NavigateUpButton = driver.find_element(by=AppiumBy.ACCESSIBILITY_ID, value="Navigate up")
NavigateUpButton.click()

NavigateUpButton = driver.find_element(by=AppiumBy.ACCESSIBILITY_ID, value="Navigate up")
NavigateUpButton.click()

OpenMenuButton = driver.find_element(by=AppiumBy.ACCESSIBILITY_ID, value="\"Open\"")
OpenMenuButton.click()

MenuLogoffButton = driver.find_element(by=AppiumBy.ID, value="com.sitecapture.app.sitecapture.dev:id/menu_sign_out")
MenuLogoffButton.click()

WarningPromptLogoffButton = driver.find_element(by=AppiumBy.ID, value="android:id/button1")
WarningPromptLogoffButton.click()
'''





    