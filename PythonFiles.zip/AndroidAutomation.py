import sys, io, json
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

# For W3C actions
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions import interaction
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.pointer_input import PointerInput


caps = {}
caps["platformName"] = "Android"
caps["appium:platformVersion"] = "13"
caps["appium:deviceName"] = "emulator-5554"
caps["appium:app"] = "c:\\users\\administrator\\downloads\\sitecapture-dev-344.apk"
caps["appium:appPackage"] = "com.sitecapture.app.sitecapture.dev"
caps["appium:appActivity"] = "com.fotonotes.android.activity.LoginActivity"
caps["appium:automationName"] = "UiAutomator2"
caps["appium:ensureWebviewsHavePages"] = True
caps["appium:nativeWebScreenshot"] = True
caps["appium:newCommandTimeout"] = 3600
caps["appium:connectHardwareKeyboard"] = True

driver = webdriver.Remote("http://127.0.0.1:4723", caps)

if (driver.is_app_installed("com.sitecapture.app.sitecapture.dev")):
    print("App is installed")
else:
    print("App is not installed")
    

self.driver.launch_app()




el1 = driver.find_element(by=AppiumBy.ID, value="com.sitecapture.app.sitecapture.dev:id/editTextUsername")
el1.send_keys("sam_stage_admin_1")

el2 = driver.find_element(by=AppiumBy.ID, value="com.sitecapture.app.sitecapture.dev:id/editTextPassword")
el2.send_keys("test")

el3 = driver.find_element(by=AppiumBy.ID, value="com.sitecapture.app.sitecapture.dev:id/buttonSignin")
el3.click()

<body>
	
    <div id="fn_wrap" ng-app="fn" class="ng-scope">
			
			<!-- Our FN nav -->  
			<div id="fn_sb">
				<div class="fn_brand">
					
   			 		 	
   			 			 	
						
    					
				</div>
			</div><!-- /fnReserved -->  
   
   
   		<!-- below is the logo, utility nav and the types nav --> 









            <!-- NEW NAV WRAPPER -->
            <!-- ng-class="{'siteCapture' : fn.currentMicrosite.appName == 'SiteCapture'}" -->

            <div class="navWrapper newUI">

                <!-- the messages -->
                <div ng-show="fn.jsonSaving" class="saveNotification alert alert-success span2 ng-hide">Saving...</div>
                <div ng-show="fn.jsonSaved &amp;&amp; !fn.jsonSaving" class="saveNotification alert alert-success span2 animate-fadeOut-025 ng-hide">Changes saved.</div>
                <div ng-show="fn.alertMessage" class="saveNotification alert alert-success span2 animate-fadeOut-025 ng-binding ng-hide"></div><div ng-show="fn.errorMessage" class="saveNotification alert alert-error span6 ng-binding ng-hide"></div>


                <!-- Type Nav -->
                <div id="typeNav" class="tabbable">
                    <ul class="nav nav-tabs">
                        <li id="portal_id" ng-class="{'active':(fn.activeTab =='t')}">
                            <a href="/app/#/dashboard" title="Dashboard">
                                
                                    <!-- hardcoded for now -->
                                    <!-- GRAILS3_REFACTOR trying to make it dynamic-->
                                    <img src="/images/sitecapture-favicon.svg">
                                
                            </a>
                        </li>
                        
                            
                                <li ng-show="fn.hasContainers" ng-class="{'menuProperties':true, 'active':(fn.activeTab =='c')}" class="menuProperties" style="">
                                    <a href="/app/#/project/search/c" class="ng-binding">Properties</a>
                                </li>
                                <li ng-class="{'menuWorkorders':true, 'active':(fn.activeTab == 'nc')}" class="menuWorkorders active">
                                    <a href="/app/#/project/search/nc" class="ng-binding">Work</a>
                                </li>

                            
                        
                    </ul>
                </div>
                


               <!-- utility Nav -->
               <div id="n_un">
                  
                      <ul ng-show="fn.initDataLoaded" class="" style="">
                         <li class="dropdown">
                             <a class="dropdown-toggle adminMenu userMenu" data-toggle="dropdown">
                                 <i class="ikon ikon-admin-menu-user report" ng-hide="fn.currentUser.profileImageId"></i>
                                <img ng-show="fn.currentUser.profileImageId" class="profilePic ng-hide" alt="">
                             </a>
                             <ul class="dropdown-menu  pull-right userMenu menu-dark">
                                 <li class="loggedInAs"><h4 class="ng-binding">sam_stage_vendor_company2</h4></li>
                                 <li><a href="/app/#/account">My Account</a></li>
                                 <li><a href="/logout/index">Sign Out</a></li>
                             </ul>
                         </li>
                         <li class="dropdown zendeskLink">
                            
                                <a class="adminMenu" data-toggle="dropdown"><i class="ikon ikon-admin-menu-help report"></i></a>
                                <ul class="dropdown-menu pull-right menu-dark">
                                    <li><a href="https://sitecapture.zendesk.com/" target="_blank">Help Center</a></li>
                                </ul>
                            
                        </li>



                      <li ng-show="fn.hasPermission('ADMIN_PROJECTS')" class="dropdown" style=""><a class="dropdown-toggle adminMenu ng-scope" data-toggle="dropdown" bs-tooltip="'Admin'" data-delay="1000" data-placement="bottom" data-original-title="" title="">
                                <i class="ikon ikon-admin-menu-pages report"></i>
                            </a>
                            <div class="dropdown-menu  pull-right admin-menu menu-dark">
                                <div class="inner">

                                    <div>
                                        <h4 ng-show="fn.currentCompany &amp;&amp; fn.hasPermission('ADMIN_COMPANY') ||fn.hasPermission('ADMIN_TEMPLATES')" class="" style="">Account</h4>
                                        <ul ng-show="fn.currentCompany &amp;&amp; fn.hasPermission('ADMIN_COMPANY') ||fn.hasPermission('ADMIN_TEMPLATES')" class="" style="">
                                            <li ng-show="fn.currentCompany &amp;&amp; fn.hasPermission('ADMIN_COMPANY')" class="" style="">
                                                <a href="/app/#/portal/company">Company Info</a></li>
                                            <li ng-show="fn.hasPermission('ADMIN_TEMPLATES')" class="" style=""><a href="/app/#/portal">Settings</a></li>
                                            <li ng-show="isPortalAdmin() &amp;&amp; fn.currentMicrosite.isCustomer &amp;&amp; fn.currentMicrosite.isEnabled" class="ng-hide"><a href="javascript:void(0)" data-cb-type="portal"> Billing </a></li>
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 ng-show="fn.hasPermission('ADMIN_USERS')" class="" style="">Team</h4>
                                        <ul ng-show="fn.hasPermission('ADMIN_USERS')" class="" style="">
                                            <li ng-show="fn.hasPermission('ADMIN_USERS')" class="" style=""><a href="/app/#/user">Users</a></li>
                                            <li ng-show="fn.feature.VENDOR_ASSIGNMENT &amp;&amp; fn.hasPermission('ADMIN_USERS')" class="" style=""><a href="/app/#/vendor/list">Vendors</a></li>
                                            <li ng-show="fn.feature.CUSTOMER_MANAGEMENT &amp;&amp; fn.hasPermission('ADMIN_USERS')" class="" style=""><a href="/app/#/customer/list">Customers</a></li>
                                        </ul>
                                        <h4 ng-show="fn.hasPermission('ADMIN_TEMPLATES') || fn.feature.SERVICE_MANAGEMENT" class="" style="">Configuration</h4>
                                        <ul>
                                            <li ng-show="fn.hasPermission('ADMIN_TEMPLATES')" class="" style=""><a href="/app/#/template/list">Templates</a></li>
                                            <li ng-show="fn.feature.TYPE_MANAGEMENT &amp;&amp; fn.hasPermission('ADMIN_TEMPLATES')" class="" style=""><a href="/app/#/type/list">Types</a></li>
                                            <li ng-show="fn.feature.SERVICE_MANAGEMENT" class="" style=""><a href="/app/#/service">Services</a></li>
                                            <li ng-show="fn.feature.DATA_VIEWS" class="" style=""><a href="/app/#/dataview/list">Data Views</a></li>
                                            <li ng-show="fn.feature.REPORT_CONFIG_UI" class="" style=""><a href="/app/#/report/list">Reports</a></li>
                                            <li ng-show="fn.feature.MARKETS_REGIONS &amp;&amp; fn.hasPermission('ADMIN_USERS')" class="" style=""><a href="/app/#/marketregion/list">Markets and Regions</a></li>
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 ng-show="fn.feature.ACTIVITY_LOG &amp;&amp; fn.hasPermission('ADMIN_ACTIVITY_LOG') || fn.hasPermission('VIEW_ARCHIVES')" class="" style="">Data &amp; Integration</h4>
                                        <ul ng-show="fn.feature.ACTIVITY_LOG &amp;&amp; fn.hasPermission('ADMIN_ACTIVITY_LOG') || fn.hasPermission('VIEW_ARCHIVES')" class="" style="">
                                            <li ng-show="fn.hasPermission('ADMIN_IMPORT_EXPORT')" class="" style=""><a href="/app/#/import">Import</a></li>
                                            <li ng-show="(fn.feature.INTEGRATION || fn.feature.SALESFORCE_INTEGRATION) &amp;&amp; fn.hasPermission('ADMIN_INTEGRATION')" class="" style=""><a href="/app/#/integration/list"> Integration Status</a></li>
                                            
                                                <li ng-show="fn.hasPermission('ADMIN_IMPORT_EXPORT')" class="" style=""><a href="/app/#/export/list">Batch Reports</a></li>
                                            
                                            <li ng-show="fn.feature.ACTIVITY_LOG &amp;&amp; fn.hasPermission('ADMIN_ACTIVITY_LOG')" class="" style=""><a href="/app/#/export/activity"> Activity Log</a></li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                      <li class="dropdown global-search">
                          <a class="adminMenu" data-toggle="dropdown" title="New Search..."><i class="ikon ikon-admin-menu-search report"></i></a>
                          <ul class="dropdown-menu admin-search menu-dark">
                              <li>
                                  <div>
                                      <form ng-submit="fn.newSearch()" class="ng-pristine ng-valid">
                                         <!--  <h4 ng-show="fn.hasContainers">Search</h4> -->
                                          <div ng-show="fn.hasContainers" class="" style="">
                                            <div class="styled-select">
                                              <select ng-model="fn.globalSearchCategory" name="" id="" class="ng-pristine ng-untouched ng-valid">
                                                  <option class="test ng-binding" value="c">Properties</option>
                                                  <option class="test ng-binding" value="nc">Work</option>
                                              </select>
                                            </div>  
                                          </div>
                                          <!-- <h4 ng-show="!fn.hasContainers">Search {{fn.nonContainerConfiguration.pluralName}}</h4> -->

                                          <input type="text" ng-model="fn.globalSearchText" class="input-medium search-query deletable ng-pristine ng-untouched ng-valid" placeholder="Type some text...">
                                          <input class="save btn btn-primary" type="submit" value="Search">
                                      </form>
                                  </div>
                              </li>
                          </ul>
                      </li>
                      <li ng-show="fn.chatSupported" class="dropdown newChatNotice" style="">
                          <a class="ikon dropdown-toggle " data-toggle="dropdown" ng-click="fn.showNewChatMessages()" title="you have 0 new messages"><i class="ikon "></i><span ng-show="fn.chat.unreadMessageCount > 0" class="unreadMessageCount ng-binding ng-hide" title="you have 0 new messages">0</span></a>
                          <ul class="dropdown-menu">
                              <li>
                                    <!-- ngInclude:  --><div ng-include="" src="'/angular-app/chat/chat-messages-modal.html'" class="ng-scope"><div id="chat-messages-modal" class="fn_modal ng-scope" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<!-- hide fade modal -->
    <div class="modal-header">
        <h3>New Messages</h3>
    </div>
    <div class="modal-body">
            <ul class="serviceSelectListx newChatMessageList">
                <!-- the timestamp is to make the URL new to force reload-->
                <!-- ngRepeat: project in fn.chatProjectList -->
            </ul>


            <p ng-hide="fn.chat.unreadMessageCount > 0">No projects with unread messages.</p>
      
    </div>

    <div class="modal-footer">
        <div class="form-actions-proto">
            <a class="btn btn-cancel" style="display: inline-block;margin: 10px -10px 0 0;" ng-click="fn.closeChatModal()" aria-hidden="true">Close</a>
        </div>
    </div>
</div></div>
                                 
                              </li>
                          </ul>
                      </li>
               
                  
                        
                </ul></div><!-- /utility Nav --> 
             </div><!-- /navWrapper -->


            <div id="overlayBackground" style="display:none;"></div>
            <!-- ngView:  --><div ng-app="fn" ng-view="" class="page_content ng-scope"><div id="fn_type_list" class="pl2 ng-scope" ng-class="{'viewsSidebarCollapsed':viewsSidebarCollapsed}" ng-show="initializePage()">
    <div class="search_title">

        <h1 ng-hide="fn.currentSearchConfiguration.savedSearch.id" class="ng-binding ng-hide">Work</h1>
        <h1 ng-show="fn.currentSearchConfiguration.savedSearch.id" class="ng-binding">All Inspections <span ng-show="!loadingList &amp;&amp; (fn.currentSearchConfiguration.modified)" class="ng-hide">*</span>
            <span ng-show="fn.currentSearchConfiguration.savedSearch.favorite &amp;&amp; fn.currentUser.hasAccessToAllSavedSearches" ng-click="unfavoriteSearch(fn.currentSearchConfiguration.savedSearch)" class="isFaved ng-hide" title="Click to remove from favorites">&nbsp;</span>
            <span ng-hide="fn.currentSearchConfiguration.savedSearch.favorite" ng-click="favoriteSearch(fn.currentSearchConfiguration.savedSearch)" class="notFaved" title="Click to add to favorites">&nbsp;</span>
        </h1>


        <ul class="saveSearchControls">
            <li class="dropdown more">
                <a class="dropdown-toggle" data-toggle="dropdown"><i class=" ikon ikon-show-controls-more share" title="View data, Edit, Save and Export this view..."></i></a>
                <ul class="dropdown-menu">
                    <li ng-show="fn.feature.DATA_VIEWS  &amp;&amp; fn.hasPermission('ADMIN_PROJECTS')" class="dropdown-submenu">
                        <a class="dropdown-toggle" data-toggle="dropdown">Data View...</a>
                        <ul class="dropdown-menu dataview-menu">
                            <!-- ngRepeat: dataView in dataViews track by dataView.id -->
                        </ul>
                    </li>
                    <li class="divider"></li>
                    <li ng-show="((fn.hasPermission('CREATE_SEARCH') &amp;&amp; (fn.currentSearchConfiguration.savedSearch.type.name=='PRIVATE')) || fn.hasPermission('ADMIN_ADVANCED_SEARCH')) &amp;&amp; fn.currentSearchConfiguration.savedSearch.name  &amp;&amp; (fn.currentSearchConfiguration.savedSearch.creator.micrositeId == fn.currentMicrosite.id)">
                        <a ng-click="showSaveNewSearch(false, false)">Save changes to this view...</a>
                    </li>
                    <li ng-show="fn.hasPermission('CREATE_SEARCH')">
                        <a ng-click="showSaveNewSearch(true, false)">Save as new view...</a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a ng-click="showExportsSearchModal()">Export results...</a>
                    </li>
                </ul>
            </li>
        </ul>

        <div class="spanner">&nbsp;</div>

        <div class="create_new_view">
                <a ng-click="startNewSearch()" title="New Search of Work">New Search...</a>
            </div>

            <input ng-show="fn.userCanCreateProjects" ng-disabled="selectedCount" class="createNewProject" type="button" ng-click="showNewProjectModal()" value="Work" title="Create a new Work">

    </div>

    <div class="leftSideBar">
        <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/list-advanced-search-partial.html'" class="ng-scope"><div id="searchPanel" class="advancedSearch ng-scope" xmlns="http://www.w3.org/1999/html">
    <div class="advancedSearch_i" ng-show="fn.currentUser.hasAccessToAllSavedSearches" style="height: 905px;">

        <div class="viewsSidebarHeader">
            <a class="maxSidebar ng-hide" ng-show="viewsSidebarCollapsed" ng-click="toggleViewSidebar()" title="Expand sidebar">&nbsp;</a>
            <a class="minSidebar" ng-show="!viewsSidebarCollapsed" ng-click="toggleViewSidebar()" title="Collapse sidebar">&nbsp;</a>
            <div class="inner" ng-show="!viewsSidebarCollapsed">
                <h3>Views</h3>
                    <ul class="saveSearchControls" style="position:absolute;right:50px;top:0px;">
                        <li class="dropdown more">
                            <a class="dropdown-toggle" data-toggle="dropdown"><i class=" ikon ikon-show-controls-more-vertical share" title="Manage views..."></i></a>
                            <ul class="dropdown-menu pull-right">
                                <li><a ng-click="showManageFavorites()">Manage favorites views...</a></li>
                                <li ng-show="fn.hasPermission('ADMIN_ADVANCED_SEARCH')"><a ng-click="showManageViews()">Manage all views...</a></li>
                                <li ng-show="!fn.hasPermission('ADMIN_ADVANCED_SEARCH')" class="ng-hide"><a ng-click="showManageViews()">Manage my views...</a></li>
                            </ul>
                        </li>
                    </ul>
            </div>
        </div>

        <div class="viewsSidebarBody">
            <div ng-show="!viewsSidebarCollapsed">

                <h4 ng-class="{'sidebarListToggle':true, 'collapsed':favoriteListCollapsed }" ng-click="toggleFavoriteList()" class="sidebarListToggle">Favorites</h4>
                
                <span class="noFavesYet" ng-show="fn.currentSearchConfiguration.favoriteSearches.length == 0">Click the star to add to Favorites.</span>
                <ul class="favoriteViews views-list" ng-show="!favoriteListCollapsed">
                    <!-- ngRepeat: search in fn.currentSearchConfiguration.favoriteSearches | orderBy:'favoriteOrder' track by search.id -->
                </ul>

                <br>

                <h4 ng-class="{'sidebarListToggle':true, 'collapsed':otherListCollapsed }" ng-click="toggleOtherList()" class="sidebarListToggle">Views</h4>

                <ul class="otherViews views-list" ng-show="!otherListCollapsed">

                    <!-- ngRepeat: search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id --><li ng-repeat="search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id" ng-class="{search_name:true, 'active':(fn.currentSearchConfiguration.savedSearch.id == search.id)}" class="ng-scope search_name">

                        <div class="list-item-inner">

                            <a class="scrollTo" id="searchID2724"></a>
 
                            <div class="nameAndCount" ng-click="openSavedView(search.id)">
                                <span class="searchName ng-binding" title="This view can be seen by everyone">All Properties</span>
                                <div class="currentCount" title="Click button to refresh count">
                                    <span ng-show="search.currentCount >= 0" class="ng-binding">0</span>
                                    <span ng-show="search.currentCount === null" class="ng-hide">--</span>
                                </div>

                            </div>

                            <div class="currentCountWrap">
                                <div class="refreshCount">
                                    <div class="refreshCountButton" ng-click="fetchSearchCount(search)" title="Click to refresh count">&nbsp;</div>
                                    <div ng-show="search.currentCount === -1" id="spinner" class="spinner ng-hide">
                                        <img src="/images/spinner.gif" alt="Spinner">
                                    </div>
                                </div>
                            </div>
                        
                        </div>

                    </li><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id --><li ng-repeat="search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id" ng-class="{search_name:true, 'active':(fn.currentSearchConfiguration.savedSearch.id == search.id)}" class="ng-scope search_name active">

                        <div class="list-item-inner">

                            <a class="scrollTo" id="searchID2725"></a>
 
                            <div class="nameAndCount" ng-click="openSavedView(search.id)">
                                <span class="searchName ng-binding" title="This view can be seen by everyone">All Inspections</span>
                                <div class="currentCount" title="Click button to refresh count">
                                    <span ng-show="search.currentCount >= 0" class="ng-binding">4</span>
                                    <span ng-show="search.currentCount === null" class="ng-hide">--</span>
                                </div>

                            </div>

                            <div class="currentCountWrap">
                                <div class="refreshCount">
                                    <div class="refreshCountButton" ng-click="fetchSearchCount(search)" title="Click to refresh count">&nbsp;</div>
                                    <div ng-show="search.currentCount === -1" id="spinner" class="spinner ng-hide">
                                        <img src="/images/spinner.gif" alt="Spinner">
                                    </div>
                                </div>
                            </div>
                        
                        </div>

                    </li><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id --><li ng-repeat="search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id" ng-class="{search_name:true, 'active':(fn.currentSearchConfiguration.savedSearch.id == search.id)}" class="ng-scope search_name">

                        <div class="list-item-inner">

                            <a class="scrollTo" id="searchID2726"></a>
 
                            <div class="nameAndCount" ng-click="openSavedView(search.id)">
                                <span class="searchName ng-binding" title="This view can be seen by everyone">All Punchlists</span>
                                <div class="currentCount" title="Click button to refresh count">
                                    <span ng-show="search.currentCount >= 0" class="ng-binding">0</span>
                                    <span ng-show="search.currentCount === null" class="ng-hide">--</span>
                                </div>

                            </div>

                            <div class="currentCountWrap">
                                <div class="refreshCount">
                                    <div class="refreshCountButton" ng-click="fetchSearchCount(search)" title="Click to refresh count">&nbsp;</div>
                                    <div ng-show="search.currentCount === -1" id="spinner" class="spinner ng-hide">
                                        <img src="/images/spinner.gif" alt="Spinner">
                                    </div>
                                </div>
                            </div>
                        
                        </div>

                    </li><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id --><li ng-repeat="search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id" ng-class="{search_name:true, 'active':(fn.currentSearchConfiguration.savedSearch.id == search.id)}" class="ng-scope search_name">

                        <div class="list-item-inner">

                            <a class="scrollTo" id="searchID2727"></a>
 
                            <div class="nameAndCount" ng-click="openSavedView(search.id)">
                                <span class="searchName ng-binding" title="This view can be seen by everyone">All</span>
                                <div class="currentCount" title="Click button to refresh count">
                                    <span ng-show="search.currentCount >= 0" class="ng-binding"></span>
                                    <span ng-show="search.currentCount === null" class="">--</span>
                                </div>

                            </div>

                            <div class="currentCountWrap">
                                <div class="refreshCount">
                                    <div class="refreshCountButton" ng-click="fetchSearchCount(search)" title="Click to refresh count">&nbsp;</div>
                                    <div ng-show="search.currentCount === -1" id="spinner" class="spinner ng-hide">
                                        <img src="/images/spinner.gif" alt="Spinner">
                                    </div>
                                </div>
                            </div>
                        
                        </div>

                    </li><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches  | orderBy:'sortOrder' | filter:{favorite:false} track by search.id -->
                </ul>
            </div>
        </div><!--/advanced search-->
    </div>









    <div class="advancedSearch_i ng-hide" ng-hide="fn.currentUser.hasAccessToAllSavedSearches" style="height: 905px;">

        <div class="viewsSidebarHeader">

            <a class="maxSidebar ng-hide" ng-show="viewsSidebarCollapsed" ng-click="toggleViewSidebar()" title="Expand sidebar">&nbsp;</a>
            <a class="minSidebar" ng-show="!viewsSidebarCollapsed" ng-click="toggleViewSidebar()" title="Collapse sidebar">&nbsp;</a>
        
            <div class="inner" ng-show="!viewsSidebarCollapsed">
                <h3>Views</h3>
            </div>

        </div>
        <div class="viewsSidebarBody">
            <div ng-show="!viewsSidebarCollapsed">

                <h4 ng-class="{'sidebarListToggle':true, 'collapsed':favoriteListCollapsed }" ng-click="toggleFavoriteList()" class="sidebarListToggle">Views</h4>
                <!-- <h4 ng-class="{'sidebarListToggle':true, 'collapsed':otherListCollapsed }" ng-click="toggleOtherList()">Views</h4> -->
                <span class="noFavesYet" ng-show="fn.currentSearchConfiguration.favoriteSearches.length == 0">No views!  Contact your Admin to give you access to views </span>

                <ul class="favoriteViews views-list" ng-show="!favoriteListCollapsed">
                    <!-- ngRepeat: search in fn.currentSearchConfiguration.favoriteSearches | orderBy:'sortOrder' track by search.id -->
                </ul>
            </div>
        </div>
    </div><!--/advanced search-->




</div>

</div>
    </div>
    <div class="mainContent">
        <div id="fn_type_list_inner" class="s">

            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/list-advanced-search-modal.html'" class="ng-scope"><div id="editSearchModal" class="fn_modal modal hide fade ng-scope" xmlns="http://www.w3.org/1999/html">
   <div class="modal-header">
        <h3 ng-show="!fn.currentSearchConfiguration.savedSearch.id" class="ng-hide">Search Filters for <strong class="ng-binding">Work</strong></h3>
        <h3 ng-show="fn.currentSearchConfiguration.savedSearch.id">Search Filters for <strong class="ng-binding">All Inspections</strong></h3>
   </div>
    <form class="form-inline ng-pristine ng-valid">
   <div class="modal-body">
        <div class="searchControls">

                <div class="advancedFilters">

                    <div class="formControls" ng-show="!searchOptions.containerSearch &amp;&amp; ((fn.companies.length>1)||(fn.currentSearchConfiguration.showMyCompanySelect &amp;&amp; (fn.companies.length == 1)))">
                        <div>
                            <label>Company</label>
                            <div class="styled-select">
                                <select ng-model="searchOptions.companyMicrositeId" ng-options="company.micrositeId as company.name for company in fn.companies" ng-change="onMicrositeSelected()" class="ng-pristine ng-untouched ng-valid"><!-- ngIf: fn.currentSearchConfiguration.showMyCompanySelect --><option value="" ng-if="fn.currentSearchConfiguration.showMyCompanySelect" class="ng-scope">My Company</option><!-- end ngIf: fn.currentSearchConfiguration.showMyCompanySelect --><option value="0" label="Sam Stage 1">Sam Stage 1</option></select>
                            </div>
                        </div>
                    </div>
                    <div class="subgroup">


                        <div class="formControls">
                            <label ng-hide="types.length == 0">Types</label>
                            <div class="multiSelectWrap" ng-hide="types.length == 0 || searchOptions.containerSearch">
                                <div ng-show="types.length > 0" ng-dropdown-multiselect="" options="types" selected-model="searchOptions.typeList" events="typeListEvents" extra-settings="typeListSettings" checkboxes="true" translation-texts="typeListTexts" group-by="disabled" class="ng-isolate-scope" style=""><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">Inspection</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Uncheck All</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in orderedItems | filter: searchFilter --><li ng-repeat-start="option in orderedItems | filter: searchFilter" ng-show="getPropertyForObject(option, settings.groupBy) !== getPropertyForObject(orderedItems[$index - 1], settings.groupBy)" role="presentation" class="dropdown-header sub-header ng-binding ng-scope ng-hide"></li><li ng-repeat-end="" role="presentation" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))" checked="checked"> Inspection</label></div></a></li><!-- end ngRepeat: option in orderedItems | filter: searchFilter --><li ng-repeat-start="option in orderedItems | filter: searchFilter" ng-show="getPropertyForObject(option, settings.groupBy) !== getPropertyForObject(orderedItems[$index - 1], settings.groupBy)" role="presentation" class="dropdown-header sub-header ng-binding ng-scope ng-hide"></li><li ng-repeat-end="" role="presentation" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> Punchlist</label></div></a></li><!-- end ngRepeat: option in orderedItems | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding">1 / 0 checked</a></li></ul></div></div>
                            </div>
                            <div ng-show="searchOptions.containerSearch" class="ng-hide">
                                <h4 class="ng-binding">Work</h4>
                            </div>

                        </div>


                        <div class="formControls">
                            <label>Status<i class="icon-refresh glyphicon glyphicon-refresh spinning ng-hide" ng-show="templatesLoading"></i></label>
                            <div class="multiSelectWrap">
                                <div ng-dropdown-multiselect="" options="filteredStatusList" selected-model="searchOptions.statusList" extra-settings="statusListSettings" checkboxes="true" translation-texts="statusListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Uncheck All</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> Complete</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> In Progress</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> New</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding">0 / 0 checked</a></li></ul></div></div>
                            </div>
                        </div>
                    </div><!-- /subgroup -->


                    <div class="subgroup">
                        <div class="formControls">
                            <label>Template</label>
                            <div class="multiSelectWrap">
                                <div ng-dropdown-multiselect="" options="filteredTemplates" selected-model="searchOptions.templateList" events="templateListEvents" extra-settings="templateListSettings" checkboxes="true" translation-texts="templateListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Uncheck All</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> InspectionTemplate2</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding">0 / 0 checked</a></li></ul></div></div>
                            </div>
                        </div>

                        <div class="formControls">
                            <label>Assigned</label>
                            <div class="multiSelectWrap">
                                <div ng-dropdown-multiselect="" options="searchUsers" selected-model="searchOptions.assigned" extra-settings="userListSettings" translation-texts="userListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0" class="ng-hide"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Clear</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> Unassigned</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> sam_stage_vendor2_fielduser</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> sam_stage_vendor_company2</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> Sam Stage 1</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> sam_stage_vendor_company</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding"> / 1 checked</a></li></ul></div></div>
                            </div>
                        </div>

                    </div><!-- /subgroup -->


                    <div class="subgroup">
                        <div class="formControls" style="height:auto;"><!-- overide the height for the date ranges -->
                            <div class="dateRange">
                                <label>Due Date</label>
                                <div class="styled-select">
                                    <select ng-model="searchOptions.dueDateRange" class="ng-pristine ng-untouched ng-valid"><option value="? undefined:undefined ?"></option>
                                        <option value="none" selected="selected">None</option>
                                        <option value="today">Today</option>
                                        <option value="before_today">Before today</option>
                                        <option value="up_to_3_days_from_now">Before 3 days from now</option>
                                        <option value="this_week">This week</option>
                                        <option value="last_week">Last week</option>
                                        <option value="next_week">Next week</option>
                                        <option value="this_month">This month</option>
                                        <option value="last_month">Last month</option>
                                        <option value="this_year">This year</option>
                                        <option value="relative_range">Range in days from today...</option>
                                        <option value="specific_range">Specific range...</option>
                                    </select>
                                </div>
                                <div class="dateRangeFrom ng-hide" ng-show="searchOptions.dueDateRange == 'relative_range'">
                                    <div class="startDate">
                                        <label>From</label>
                                        <div class="input-append date">
                                            <input type="text" ng-model="searchOptions.dueDateDaysBeforeToday" name="dueDateAfter" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                    <div class="endDate">
                                        <label>To</label>
                                        <div class="input-append date">
                                            <input type="text" ng-model="searchOptions.dueDateDaysAfterToday" name="dueDateBefore" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                </div>
                                <div class="dateRangeFrom ng-hide" ng-show="searchOptions.dueDateRange == 'specific_range'">
                                    <div class="startDate">
                                            <label>From</label>
                                            <div class="input-append date">
                                                <input bs-datepicker="" type="text" ng-model="searchOptions.dueDateAfterDisplay" id="dueDateAfterPicker" name="dueDateAfter" class="ng-pristine ng-untouched ng-valid">
                                            </div>
                                    </div>    
                                    <div class="endDate">
                                        <label>To</label>
                                        <div class="input-append date">
                                                <input bs-datepicker="" type="text" ng-model="searchOptions.dueDateBeforeDisplay" id="dueDateBeforePicker" name="dueDateBefore" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                            <div class="formControls" ng-show="fn.feature.TENANT_INSPECTIONS">
                                <div>
                                    <label>Sent to recipients</label>
                                    <div class="styled-select">
                                        <select name="sentToConsumer" ng-model="searchOptions.sentToConsumer" class="ng-pristine ng-untouched ng-valid">
                                            <option value="true">Sent</option>
                                            <option value="false">Not sent</option>
                                            <option value="">All</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                    </div>


                    <div class="subgroup">
                        <div class="formControls">
                            <div class="textSearch">
                                <label>Contains text</label>
                                <input type="text" ng-model="searchOptions.search" class="ng-pristine ng-untouched ng-valid">
                                <label class="matchText"><input type="checkbox" ng-model="searchOptions.exactText" class="ng-pristine ng-untouched ng-valid">Match text exactly</label>
                            </div>
                        </div>
                        <div class="formControls">
                            <div class="includeArchive">
                                <label>Archives</label>
                                <div class="styled-select">
                                    <select name="archived" ng-model="searchOptions.isArchived" class="ng-pristine ng-untouched ng-valid">
                                        <option value="false">No archives</option>
                                        <option value="">Include archives</option>
                                        <option value="true">Only archives</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                    </div>




                    <div class="showMoreToggle">
                        <h4>Advanced search options</h4>
                    </div>





                    <div class="showMoreSearchOptions">
    
                        <div class="subgroup">
                            <div class="formControls prioritySearch">
                                    <label>Priority</label>
                                    <div class="multiSelectWrap">
                                        <div ng-dropdown-multiselect="" options="fn.priorityOptions" selected-model="searchOptions.priorityList" extra-settings="priorityListSettings" checkboxes="true" translation-texts="priorityListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Uncheck All</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> Emergency</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> Critical</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> High</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> Medium</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> Low</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> None</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding">0 / 0 checked</a></li></ul></div></div>
                                    </div>
                            </div>
                            <div class="formControls manager">
                                <label>Manager</label>
                                <div class="multiSelectWrap">
                                    <div ng-dropdown-multiselect="" options="searchManagers" selected-model="searchOptions.assignedManager" extra-settings="managerListSettings" translation-texts="managerListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0" class="ng-hide"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Clear</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> Unassigned</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> sam_stage_vendor_company2</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding"> / 1 checked</a></li></ul></div></div>
                                </div>
                            </div>
                        </div><!-- /subgroup -->



                        <div class="subgroup">
                            <div class="formControls">
                                <div ng-show="isPortalAdmin()">
                                    <label>Tag</label>
                                    <div class="styled-select">
                                        <select ng-model="searchOptions.tag" ng-options="t.value for t in tagList" class="ng-pristine ng-untouched ng-valid"><option value="" class="">All</option></select>
                                    </div>
                                </div>
                            </div>
                            <div class="formControls customer">
                                <label>Customer</label>
                                <div class="multiSelectWrap">
                                    <div ng-dropdown-multiselect="" options="searchCustomers" selected-model="searchOptions.assignedCustomer" extra-settings="customerListSettings" translation-texts="customerListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0" class="ng-hide"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Clear</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> Unassigned</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding"> / 1 checked</a></li></ul></div></div>
                                </div>
                            </div>
                        </div>



                        <div class="subgroup">
                            <div class="formControls" style="height:auto;">
                            <div class="dateRange">
                                <label>Created</label>
                                <div class="styled-select">
                                    <select ng-model="searchOptions.createdDateRange" class="ng-pristine ng-untouched ng-valid"><option value="? undefined:undefined ?"></option>
                                        <option value="none" selected="selected">None</option>
                                        <option value="today">Today</option>
                                        <option value="before_today">Before today</option>
                                        <option value="this_week">This week</option>
                                        <option value="last_week">Last week</option>
                                        <option value="next_week">Next week</option>
                                        <option value="this_month">This month</option>
                                        <option value="last_month">Last month</option>
                                        <option value="this_year">This year</option>
                                        <option value="relative_range">Range in days from today...</option>
                                        <option value="specific_range">Specific range...</option>
                                    </select>
                                </div>
                                <div class="dateRangeFrom ng-hide" ng-show="searchOptions.createdDateRange == 'relative_range'">
                                    <div class="startDate">
                                        <label>From</label>
                                        <div class="input-append date">
                                            <input type="text" ng-model="searchOptions.createdDateDaysBeforeToday" name="createdDateDaysBeforeToday" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                    <div class="endDate">
                                        <label>To</label>
                                        <div class="input-append date">
                                            <input type="text" ng-model="searchOptions.createdDateDaysAfterToday" name="createdDateDaysAfterToday" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                </div>

                                <div class="dateRangeFrom ng-hide" ng-show="searchOptions.createdDateRange == 'specific_range'">
                                    <div class="startDate">
                                        <label>From</label>
                                        <div class="input-append date">
                                            <input bs-datepicker="" type="text" ng-model="searchOptions.createdDateAfterDisplay" id="createdDateAfterPicker" name="createdDateAfter" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                    <div class="endDate">
                                        <label>To</label>
                                        <div class="input-append date">
                                            <input bs-datepicker="" type="text" ng-model="searchOptions.createdDateBeforeDisplay" id="createdDateBeforePicker" name="createdDateBefore" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                            <!-- ngIf: (fn.markets.length > 0)  && (fn.feature.MARKETS_REGIONS && fn.hasPermission('ADMIN_USERS')) -->


                        </div>

                    <div class="subgroup">



                        <div class="formControls">
                            <div class="dateRange">
                                <label>Current Status Date</label>
                                <div class="styled-select">
                                    <select ng-model="searchOptions.statusLastUpdatedRange" class="ng-pristine ng-untouched ng-valid"><option value="? undefined:undefined ?"></option>
                                        <option value="none" selected="selected">None</option>
                                        <option value="today">Today</option>
                                        <option value="before_today">Before today</option>
                                        <option value="this_week">This week</option>
                                        <option value="last_week">Last week</option>
                                        <option value="next_week">Next week</option>
                                        <option value="this_month">This month</option>
                                        <option value="last_month">Last month</option>
                                        <option value="this_year">This year</option>
                                        <option value="relative_range">Range in days from today...</option>
                                        <option value="specific_range">Specific range...</option>
                                    </select>
                                </div>
                                <div class="dateRangeFrom ng-hide" ng-show="searchOptions.statusLastUpdatedRange == 'relative_range'">
                                    <div class="startDate">
                                        <label>From</label>
                                        <div class="input-append date">
                                            <input type="text" ng-model="searchOptions.statusLastUpdatedDaysBeforeToday" name="statusLastUpdatedDaysBeforeToday" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                    <div class="endDate">
                                        <label>To</label>
                                        <div class="input-append date">
                                            <input type="text" ng-model="searchOptions.statusLastUpdatedDaysAfterToday" name="statusLastUpdatedDaysAfterToday" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                </div>

                                <div class="dateRangeFrom ng-hide" ng-show="searchOptions.statusLastUpdatedRange == 'specific_range'">
                                    <div class="startDate">
                                        <label>From</label>
                                        <div class="input-append date">
                                            <input bs-datepicker="" type="text" ng-model="searchOptions.statusLastUpdatedAfterDisplay" id="statusLastUpdatedAfterPicker" name="statusLastUpdatedAfter" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                    <div class="endDate">
                                        <label>To</label>
                                        <div class="input-append date">
                                            <input bs-datepicker="" type="text" ng-model="searchOptions.statusLastUpdatedBeforeDisplay" id="statusLastUpdatedBeforePicker" name="statusLastUpdatedBefore" class="ng-pristine ng-untouched ng-valid">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div><!-- /subgroup -->


</div><!-- /showMoreSearchOptions -->
                
               

        </div><!-- /search controls -->
</div>
    </div><!-- /modal body -->
    <div class="modal-footer form-actions-proto">
        
        <a class="btn btn-link deleteThisUser" ng-click="clearSearchOptions()">Clear all filters</a>
        <a class="btn btn-cancel" ng-click="cancelEditSearchModal()">Cancel</a>
        <a class="btn btn-primary" ng-click="newSearch()">Search</a>
    </div>
      </form>
</div><!--/advanced search-->


</div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/list-new-project-modal.html'" class="ng-scope"><div id="newProjectModal" class="fn_modal modal hide fade ng-scope" xmlns="http://www.w3.org/1999/html">
   <div class="modal-header">
        <h3 class="ng-binding">Create New Work</h3>
   </div>
<form name="popoverForm" class="ng-pristine ng-valid">
    <div ng-show="fn.templatesLoading" class="ng-hide">Loading...</div>
   <div class="modal-body" ng-show="!fn.templatesLoading">


       <div class="control-group ng-hide" ng-hide="fn.currentSearchConfiguration.containerSearch || !hasCompanyChoiceForCreate">
           <label>Choose a Company:</label>
           <div class="controls">
               <div class="styled-select">
                   <select ng-model="newProject.micrositeId" ng-options="company.micrositeId as company.name for company in fn.projectCreationCompanies" class="ng-pristine ng-untouched ng-valid"><option value="?" selected="selected" label=""></option><option value="0" label="My Company">My Company</option><option value="1" label="Sam Stage 1">Sam Stage 1</option></select>
               </div>
           </div>
       </div>



       <div class="control-group" ng-hide="fn.currentSearchConfiguration.containerSearch || (getCurrentTypes(newProject.micrositeId).length == 1)">
           <label>Choose a Type:</label>
           <div class="controls">
               <div class="styled-select">
                   <select ng-model="newProject.type" ng-options="type.displayName for type in getCurrentTypes(newProject.micrositeId)" class="ng-pristine ng-untouched ng-valid"><option value="" class="">Any</option><option value="0" label="Inspection">Inspection</option><option value="1" label="Punchlist">Punchlist</option></select>
               </div>
           </div>
       </div>

       <div class="control-group">
            <label>Choose a Template:</label>
            <div class="controls">
              <div class="styled-select">
                <select ng-model="newProject.template" ng-options="t.title for t in getCurrentTemplates(newProject.micrositeId) | filter:{typeId:newProject.type.id,disabled:false}" class="ng-pristine ng-untouched ng-valid"><option value="" disabled="" selected="" class="">Select...</option><option value="0" label="InspectionTemplate2">InspectionTemplate2</option><option value="1" label="PunchlistTemplate1">PunchlistTemplate1</option></select>
              </div>
            </div>
        </div>

        <div class="control-group" ng-show="fn.feature.MARKETS_REGIONS">
            <label>Choose a Market (Optional):</label>
            <div class="controls">
              <div class="styled-select">
                <select ng-model="newProject.market" ng-options="m as m.name for m in fn.enabledMarkets track by m.id" class="ng-pristine ng-untouched ng-valid"><option value="" class="">None</option></select>
              </div>
            </div>
        </div>


       <div class="control-group ng-hide" ng-show="fn.hasContainers &amp;&amp; !fn.currentSearchConfiguration.containerSearch &amp;&amp; newProject.template">
           <label class="ng-binding">Choose a Property (optional): <a style="float: right;font-size: 11px;letter-spacing: 1px; " ng-click="changeContainer()" ng-show="newProject.container.title" class="ng-hide">Change</a></label>

           <div class="control-group">
            <!-- <label>Search for {{fn.containerConfiguration.displayName}}:</label> -->
            <input type="text" id="containerSearchTextBox" ng-model="newProject.containerSearchText" ng-change="searchContainers(newProject.containerSearchText)" style="width:370px;padding: 5px 10px;" placeholder="Enter 4 or more characters to search..." ng-show="!newProject.container.title" class="ng-pristine ng-untouched ng-valid">

                   <div class="selectedContainer group ng-hide" ng-show="newProject.container.title">
                    <img class="img">
                    <h5 class="ng-binding"></h5>
                    <p ng-show="newProject.container.displayLine2" class="ng-binding ng-hide"></p>
                    <p ng-show="newProject.container.displayLine3" class="ng-binding ng-hide"></p>
                    <p ng-show="newProject.container.displayLine4" class="ng-binding ng-hide"></p>
                   </div>
            <div>
                <ul class="containerSearchResults" ng-show="!newProject.container.title">
                    <li class="noResults ng-hide" ng-show="newProject.containerSearchResults.length == 0 &amp;&amp; newProject.containerSearchText.length > 3">No results</li>
                    <!-- ngRepeat: container in newProject.containerSearchResults track by container.id --><a ng-click="selectContainer(container)">
                </a></ul><a ng-click="selectContainer(container)">
            </a></div><a ng-click="selectContainer(container)">
        </a></div><a ng-click="selectContainer(container)">           
       </a></div><a ng-click="selectContainer(container)">

   </a></div><!-- /modal body --><a ng-click="selectContainer(container)">
    </a><div class="modal-footer form-actions-proto"><a ng-click="selectContainer(container)">
        </a><a class="btn btn-cancel" ng-click="hideNewProjectModal()">Cancel</a>
        <a class="btn btn-primary" ng-click="hideNewProjectModal();createProject();" ng-disabled="newProject.template.id == null" disabled="disabled">Create</a>
    </div>
      </form>

 </div><!--/advanced search-->


</div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/list-comments.html'" class="ng-scope"><div id="projectCommentsReadOnly" class="projectComments-list ng-scope ng-hide" ng-show="showComments">

    <div id="projectComments-header">
        <a id="hideComments" ng-click="$parent.showComments=false">×</a>
        
        <div class="displayFields">
            <img ng-show="project.projectMedia.fullSquareThumbnailUrl" class="ng-hide">
            <h3 class="ng-binding"></h3>
            <p class="ng-binding"></p>
            <p class="ng-binding"></p>
            <p class="ng-binding"></p>
        </div>
    </div>

    <div id="projectComments-inner">
        <div class="ps_comment_module">
            <div class="ps_comment_module_i">
                <p class="noDocsYet" ng-hide="project.comments.length > 0" style="margin-top: 20px;text-align: center;color: #999;">
                    Be the first to add a comment.</p>
                <div class="commentThread">

                

                    <!-- ngRepeat: comment in project.comments -->

                 </div>
            </div>
        </div>
        <div class="commentNodeAdd">
            <div class="control-group addCommentUI " ng-class="getCommentClass()">
                <!-- <h4>{{fn.currentUser.userRealName}}</h4> -->
                <textarea ng-model="project.newComment.text" class="ng-pristine ng-untouched ng-valid"></textarea> <span ng-show="project.newComment.text.length > (commentLength - 50) &amp;&amp; project.newComment.text.length <= commentLength" class="help-inline ng-binding ng-hide">0 characters left</span>
                    <span ng-show="project.newComment.text.length > commentLength" class="help-inline ng-binding ng-hide">0 max character limit exceeded!</span>
                    <button type="button" ng-disabled="project.newComment.text == null || project.newComment.text.length > commentLength" class="btn btn-primary btn-small" ng-click="addComment()" disabled="disabled">Send
                </button>
            </div>
        </div>
    </div>

    <div class="activityLogPanel ng-hide" ng-show="auditEntries">

        <h4>Activity</h4>

        <div class="activityLogPanel-i">
            <!-- ngRepeat: entry in auditEntries -->
        </div>


    </div>

</div>

<div id="projectComment" ng-show="showLastComment" class="ng-scope ng-hide">

    <div id="projectComment-inner" class="" ng-style="resizeWithOffset(280)">

        <div class="ps_comment_module">
            <div class="ps_comment_module_i">
                <div class="commentThread">

                    <div class="commentNode">
                        <div class="taskNotes">
                            <h4 class="ng-binding"></h4>
                            <pre class="commentText ng-binding"></pre>
                            <p><span class="timeStamp ng-binding"></span></p>

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
    <h4 id="showLastLogLink" ng-show="fn.feature.ACTIVITY_LOG &amp;&amp; fn.isPortalAdminForProject(project)" class="ng-hide">Activity</h4>


    <div class="activityLogPanel ng-hide" ng-show="project.lastAuditEntry">

        <h4>Activity</h4>

        <div class="activityLogPanel-i">
            <div class="auditEntry">
                <p>
                    <span class="userName ng-binding"></span>
                    <!-- <span class="category">{{entry.username}}</span> -->
                    <span class="activityType ng-binding"></span>
                    <span class="activityMsg ng-binding"></span>
                    <span class="activityDate ng-binding"></span>
                </p>
            </div>
        </div>


    </div>

</div></div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/export-search.html'" class="ng-scope">

<div id="export-search-modal" class="fn_modal modal hide fade ng-scope" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">CLOSE</button> -->
    <!-- <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> -->
    <h3>Export Search Results</h3>
  </div>
  <form id="exportSearchResultsForm" ng-submit="prepareSearchOptions()" action="/projectJSON/exportSearch" method="post" class="ng-pristine ng-valid">
  <div class="modal-body">

      <input id="searchOptions" name="searchOptions" type="hidden" value="{&quot;offset&quot;:0,&quot;max&quot;:20,&quot;regionList&quot;:[],&quot;isArchived&quot;:false,&quot;exportDefault&quot;:true,&quot;templateList&quot;:[],&quot;savedSearchType&quot;:&quot;EVERYONE&quot;,&quot;priorityList&quot;:[],&quot;exportVendorData&quot;:false,&quot;marketList&quot;:[],&quot;summaryOnly&quot;:true,&quot;containerSearch&quot;:false,&quot;typeList&quot;:[{&quot;displayed&quot;:true,&quot;pluralName&quot;:&quot;Inspections&quot;,&quot;isDefault&quot;:false,&quot;listPageOnlyUncontainedProjects&quot;:false,&quot;displayName&quot;:&quot;Inspection&quot;,&quot;sortOrder&quot;:1,&quot;id&quot;:3788,&quot;iconUrl&quot;:&quot;http://fotobabble.net/fotonotes/fn_type_icons/default.png&quot;,&quot;version&quot;:0}],&quot;statusList&quot;:[],&quot;assigned&quot;:{},&quot;assignedManager&quot;:{},&quot;assignedCustomer&quot;:{},&quot;sort&quot;:{&quot;value&quot;:null,&quot;order&quot;:null},&quot;createdDateAfterDisplay&quot;:null,&quot;createdDateBeforeDisplay&quot;:null,&quot;statusLastUpdatedAfterDisplay&quot;:null,&quot;statusLastUpdatedBeforeDisplay&quot;:null,&quot;dueDateAfterDisplay&quot;:null,&quot;dueDateBeforeDisplay&quot;:null}">

<h4>Include:</h4>
                        <label>
                          <input ng-model="searchOptions.summaryOnly" id="summaryOnly" name="summaryOnly" type="checkbox" class="ng-pristine ng-untouched ng-valid">
                          All standard fields (Display lines, Status, Due Date, etc)
                        </label>

                        <label>
                          <input ng-model="searchOptions.exportDefault" id="exportDefault" name="exportDefault" type="checkbox" class="ng-pristine ng-untouched ng-valid">
                          All template fields (All the fields in the templates)
                        </label>


                        <label ng-show="!searchOptions.exportDefault" class="ng-hide">Specific fields (comma separated field keys) </label>
                        <input ng-show="!searchOptions.exportDefault &amp;&amp; fn.hasPermission('ADMIN_IMPORT_EXPORT')" type="text" ng-model="searchOptions.fieldKeys" class="ng-pristine ng-untouched ng-valid ng-hide">
                        <input ng-show="!searchOptions.exportDefault &amp;&amp; !fn.hasPermission('ADMIN_IMPORT_EXPORT')" type="text" ng-model="searchOptions.fieldKeys" readonly="true" class="ng-pristine ng-untouched ng-valid ng-hide">

      <label>
          <input ng-model="searchOptions.exportVendorData" id="exportVendorData" name="exportVendorData" type="checkbox" class="ng-pristine ng-untouched ng-valid">
          Vendor data
      </label>


      <label>
          <input ng-model="searchOptions.exportStatusTimeline" id="exportStatusTimeline" name="exportStatusTimeline" type="checkbox" class="ng-pristine ng-untouched ng-valid">
           Status timeline
      </label>

	</div><!-- /modal-body -->
   <div class="modal-footer">
      <div class="form-actions-proto">
      <a class="btn btn-cancel" data-dismiss="modal">Cancel</a>
      <a class="btn btn-primary btn-small" ng-href="" target="_blank" ng-click="exportSearchResults()">Export</a>
    </div>
  </div>
  </form>
</div>


</div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/list-batch-create-modal.html'" class="ng-scope"><div id="batchCreateModal" class="fn_modal modal hide fade ng-scope" xmlns="http://www.w3.org/1999/html">
   <div class="modal-header">
        <h3 class="ng-binding">Create New Work</h3>
       <p class="ng-binding">Create a Work of the selected Type and Template for each of the selected Properties</p>
   </div>
<form name="popoverForm" class="ng-pristine ng-valid">
    <div ng-show="fn.templatesLoading" class="ng-hide">Loading...</div>
   <div class="modal-body" ng-show="!fn.templatesLoading">


       <div class="control-group">
           <label>Choose a Type:</label>
           <div class="controls">
               <div class="styled-select">
                   <select ng-model="createContained.type" ng-options="type.displayName for type in getCurrentMicrositeTypes() | filter: {isContainable: true}" class="ng-pristine ng-untouched ng-valid"><option value="" disabled="" selected="" class="">Select...</option><option value="0" label="Inspection">Inspection</option><option value="1" label="Punchlist">Punchlist</option></select>
               </div>
           </div>
       </div>

       <div class="control-group">
            <label>Choose a Template:</label>
            <div class="controls">
              <div class="styled-select">
                <select ng-model="createContained.template" ng-options="t.title for t in getCurrentMicrositeTemplates() | filter:{typeId:createContained.type.id,disabled:false}" class="ng-pristine ng-untouched ng-valid"><option value="" disabled="" selected="" class="">Select...</option><option value="0" label="InspectionTemplate2">InspectionTemplate2</option><option value="1" label="PunchlistTemplate1">PunchlistTemplate1</option></select>
              </div>
            </div>
        </div>

   </div><!-- /modal body -->
    <div class="modal-footer form-actions-proto">
        <a class="btn btn-cancel" ng-click="hideBatchCreateModal()" ng-hide="createContained.processing">Cancel</a>
        <a class="btn btn-primary" ng-click="doBatchCreate();" ng-hide="createContained.processing">Create</a>
        <span class="pleaseWait ng-hide" ng-show="createContained.processing"><img src="../images/portal/spinner-material.gif" alt="Spinner">Create in progress. Please wait... </span>
    </div>
      </form>



</div><!--/advanced search-->


</div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/copy-project-modal.html'" class="ng-scope"><div id="copyProjectModal" class="fn_modal hide fade modal ng-scope" data-backdrop="static" data-keyboard="false" xmlns="http://www.w3.org/1999/html">
    <div class="modal-header">
        <h3>Copy</h3>
    </div>
    <div class="modal-body">

        <div ng-show="copyProject.copyErrorMessage" class="alert alert-error ng-binding ng-hide">
            
        </div>

        <h3>Choose a Template</h3>
        <div class="controls">
            <div class="control-group">
                <label><input type="radio" ng-model="copyProject.copyWithDifferentTemplate" ng-value="false" class="ng-pristine ng-untouched ng-valid" name="9226" value="false">Use the same template</label>
            </div>
            <div class="control-group">
                <label><input type="radio" ng-model="copyProject.copyWithDifferentTemplate" ng-value="true" class="ng-pristine ng-untouched ng-valid" name="9227" value="true">Select a different template (Only fields with matching field keys will be copied)</label>
            </div>
            <div ng-show="copyProject.copyWithDifferentTemplate" class="ng-hide">
                <div class="control-group" style="margin-top:20px; margin-left: 40px;">
                    <label>Filter templates by type</label>
                    <div class="styled-select">
                        <select ng-model="copyProject.typeToFilterTemplates" ng-options="t.displayName for t in fn.types" ng-change="copyProject.copyTemplate = null" class="ng-pristine ng-untouched ng-valid"><option value="" selected="selected" label=""></option><option value="0" label="Property">Property</option><option value="1" label="Inspection">Inspection</option><option value="2" label="Punchlist">Punchlist</option></select>
                    </div>
                </div>
                <div class="control-group" style="margin-top:20px;margin-left: 40px;">
                    <label>Choose template</label>
                    <div class="styled-select">
                        <select ng-model="copyProject.copyTemplate" ng-options="t.title for t in fn.templates | filter:{typeId:copyProject.typeToFilterTemplates.id}:true" class="ng-pristine ng-untouched ng-valid"><option value="" selected="selected" label=""></option><option value="0" label="asdfasdf">asdfasdf</option><option value="1" label="foo1">foo1</option><option value="2" label="foo3">foo3</option><option value="3" label="InspectionTemplate2">InspectionTemplate2</option><option value="4" label="PunchlistTemplate1">PunchlistTemplate1</option><option value="5" label="Vendor2PropertyTemplate1">Vendor2PropertyTemplate1</option></select>
                    </div>
                </div>
                <div class="control-group" style="margin-left: 40px;">
                    <label>
                        <input ng-model="copyProject.checkCopyFlag" id="checkCopyFlag" name="checkCopyFlag" type="checkbox" class="ng-pristine ng-untouched ng-valid">Only copy fields that have copy flag checked
                    </label>
                </div>
            </div>



            <h3>Choose What To Copy </h3>
            <label>
                <input ng-model="copyProject.copyAssignedUser" id="copyAssignedUser" name="copyTags" type="checkbox" class="ng-pristine ng-untouched ng-valid">Copy assigned user
            </label>

            <label>
                <input ng-model="copyProject.copyDueDate" id="copyDueDate" name="copyTags" type="checkbox" class="ng-pristine ng-untouched ng-valid">Copy due date
            </label>
            <p>
                <label>
                    <input ng-model="copyProject.copyTags" id="copyTags" name="copyTags" type="checkbox" class="ng-pristine ng-untouched ng-valid">Copy tags
                </label>
            </p>
            <div>
                <p class="control-group">
                    <label>
                        <input ng-model="copyProject.copyMedia" id="copyMedia" name="copyMedia" type="checkbox" class="ng-pristine ng-untouched ng-valid">Copy photos to the new project
                    </label>
                </p>
                <p class="control-group" style="margin-left:30px;">
                    <label ng-show="copyProject.copyMedia" class="ng-hide">
                        <input ng-model="copyProject.copyFlaggedMedia" id="copyFlaggedMedia" name="copyFlaggedMedia" type="checkbox" class="ng-pristine ng-untouched ng-valid">Copy only flagged photos
                    </label>
                </p>
            </div>
            <label>
                <input ng-model="copyProject.copyDocuments" id="copyDocuments" name="copyTags" type="checkbox" class="ng-pristine ng-untouched ng-valid">Copy documents
            </label>





            <h3 ng-show="fn.feature.DYNAMIC_ITEMS &amp;&amp; (copyProject.sections.length > 0)" class="ng-hide">Choose Field Group Items</h3>
            <div ng-show="(fn.feature.DYNAMIC_ITEMS) &amp;&amp; (copyProject.sections.length > 0)" class="ng-hide">
                <p class="control-group" style="margin-left:30px;">
                    </p><div class="styled-select">
                    <select ng-model="copyProject.itemCopyType" ng-options="type.value as type.label for type in itemCopyTypes" class="ng-pristine ng-untouched ng-valid"><option value="?" selected="selected" label=""></option></select>
                    </div>
                <p></p>
            </div>


            <!-- ngIf: (copyProject.itemCopyType == 'SUBSET') --><!-- subset of items -->
        </div>

    </div><!-- modal-body-->
    <div class="modal-footer" style="padding-top: 1.5em;">
        <div style="text-align:left;position:absolute;">
            <p ng-show="copyProject.numberOfCopiesMade > 0" style="margin:0;" class="ng-binding ng-hide">Number of copies made: </p>
            <!--  -->
            <p ng-show="copyProjectInProgress" class="ng-hide"><img style="width: 1.2em" src="../images/portal/spinner-material.gif" alt="Spinner"> Copying in progress... </p><p>
        </p></div>
        

        


        <div class="form-actions-proto">
                <button ng-disabled="copyProjectInProgress" ng-click="cancelCopyProjectModal()" class="btn btn-cancel" type="button">Close</button>
                <button ng-disabled="copyProjectInProgress" ng-click="createCopyOfProject(true)" type="button" class="btn btn-primary">Copy</button>
                <button ng-disabled="copyProjectInProgress" ng-click="createCopyOfProject(false)" type="button" class="btn btn-primary">Copy and go to the copy</button>
                
            </div>
        

    </div>
</div>

</div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/display-data-view.html'" class="ng-scope"><div id="show-data-viewer" class="fn_modal modal hide fade ng-scope" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

    <div class="modal-header">
        <div class="viewInfo">
            <h3 class="ng-binding"><span class="ng-binding">Work / All Inspections</span></h3>
            <a href="" ng-click="doExport()">Export</a>
        </div>
        <div class="pageControls">
            <button type="button" class="close" ng-click="hideDataViewer()" aria-hidden="true">×</button>

        </div>

        
    </div><!-- close modal-header -->


    <div ng-hide="dataDisplay.loaded" class="upload-spinner">
            <img src="/images/spinner.gif" alt="Spinner"> Loading Data
    </div>


    <div class="modal-body dataViewsDisplay">

        <div ng-show="dataDisplay.loaded" class="ng-hide">
            <div class="totalsAverages">

                <div class="totalsWrap ng-hide" ng-show="dataDisplay.summary.averageColumns.length + dataDisplay.summary.totalColumns.length > 0">
    
                    <h3>Summary</h3>

                    <table class="dataTotals">
                    <tbody><tr class="averagesTotalsRow">
                        <th>&nbsp;</th>
                        <th class="averagesSpan ng-hide" colspan="" ng-show="dataDisplay.summary.averageColumns.length"><div class="ng-binding">  / Averages</div></th>
                        <th class="totalsSpan ng-hide" colspan="" ng-show="dataDisplay.summary.totalColumns.length"><div class="ng-binding"> / Totals</div></th>
                    </tr>
                    <tr>
                        <th class=""></th>
                        <!-- ngRepeat: column in dataDisplay.summary.averageColumns -->
                        <!-- ngRepeat: column in dataDisplay.summary.totalColumns -->
                    </tr>

                        <!-- ngRepeat: row in dataDisplay.summary.rows -->
                    </tbody></table>

                </div><!-- end totals section-->


            </div><!-- end totalsAverages -->



            <div class="dataWrap ng-hide" ng-show="dataDisplay.columns.length > 0">

                <div class="dataHeader">
                <h3>Data</h3>

                <div class="top-pager ng-hide" ng-show="dataDisplay.paging.total > 100">
                <div class="projectCount">
                    <strong class="ng-binding"> - </strong> of <strong class="ng-binding"></strong>
                </div>
                <div class="pagination">
                <ul class="">
                    <li><a ng-click="pageDataDisplay(dataDisplay.paging.previousPage.offset)"><span>«</span></a></li>
                    <li><a ng-click="pageDataDisplay(dataDisplay.paging.nextPage.offset)"><span>»</span></a></li>
                </ul>
                </div>
            </div>
            </div>

        <div style="overflow:scroll">
                <table class="dataAll">
                    <tbody><tr>
                    <!-- ngRepeat: column in dataDisplay.columns -->
                    </tr>

                    <!-- Peter:  you can get the data type with this expression: {{dataDisplay.columns[$index].type}} -->
                    <!-- ngRepeat: row in dataDisplay.rows track by $index -->
                </tbody></table>
</div>
            </div><!-- loaded-->
        </div>
</div><!-- show-data-viewer--></div></div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/batch-send-consumers-modal.html'" class="ng-scope"><div id="batchSendConsumersModal" class="fn_modal modal hide fade ng-scope">
    <div class="modal-header">
        <h3>Batch Send to Recipients</h3>
    </div>
    <div class="modal-body">

        <form class="ng-pristine ng-valid">

            <div class="setReminderEmails" ng-show="!batchSend.sending &amp;&amp; !batchSend.sent">
                <label>
                    <input type="checkbox" ng-model="batchSend.sendReminders" class="ng-pristine ng-untouched ng-valid">Send Reminder Emails
                </label>

                <p>
                    If checked, reminder emails will be sent according to your configured schedule.
                </p>
            </div>


            <div ng-show="batchSend.sending" class="upload-spinner ng-hide">
                <img src="/images/spinner.gif" alt="Spinner"> Sending. . .
            </div>


            <div ng-show="batchSend.sent" class="upload-spinner ng-hide">
                <p><strong class="ng-binding">
                    0 items sent successfully.
                </strong></p>
                <p><br></p>
                <!-- ngIf: batchSend.errorList.length > 0 -->

            </div>


        </form>
    </div>

    <div class="modal-footer">
        <div class="form-actions-proto">
            <a class="btn btn-cancel" ng-click="hideBatchSendModal()" ng-show="!batchSend.sending &amp;&amp; !batchSend.sent">Cancel</a>
            <a class="btn btn-cancel ng-hide" ng-click="hideBatchSendModal()" ng-show="batchSend.sent">Close</a>
            <a class="btn btn-primary" ng-click="doBatchSendConsumers()" ng-show="!batchSend.sending &amp;&amp; !batchSend.sent">Send Emails</a>
        </div>
    </div>

</div>
</div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/market-modal.html'" class="ng-scope"><div id="setMarketModal" class="fn_modal modal hide fade ng-scope" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <h3>Set Market</h3>
  </div>
  <div class="modal-body">
    <!-- <label>Select Market</label>  this feels redundant and confusing on such a simple modal so I'm hiding it -->
    <div class="styled-select select-role">
      <select ng-model="project.newMarket" ng-options="m as m.name for m in fn.enabledMarkets" class="ng-pristine ng-untouched ng-valid"><option value="" class="">None</option></select>
    </div>
  </div>
  <div class="modal-footer">
    <div class="form-actions-proto">
      <a class="btn btn-cancel" ng-click="closeMarketModal()" aria-hidden="true">Cancel</a>
      <a class="btn btn-primary" ng-click="saveAndCloseMarketModal()" aria-hidden="true">Save</a>
    </div>
  </div>
</div></div>
            <!-- ngInclude:  --><div ng-include="" src="'/angular-app/project/batch-report-modal.html'" class="ng-scope"><div id="batchReportModal" class="fn_modal modal hide fade ng-scope">
    <div class="modal-header">
        <h3>Batch Export PDFs</h3>
    </div>
    <div class="modal-body">
        <!-- class="saveSearch deleteSearch" -->
        <!--   <p>Select options and click Start Export.  </p> -->

        <form class="ng-pristine ng-invalid ng-invalid-required">
            <table style="width:100%">
                <tbody><tr>
                    <td class="">
                        <label>Select report</label>
                        <div class="styled-select select-report">
                            <select ng-model="newExport.reportKey" ng-options="r.reportKey as r.name for r in fn.reports" required="" class="ng-pristine ng-untouched ng-invalid ng-invalid-required"><option value="" class="">Default</option><option value="0" label="Report1">Report1</option></select>
                        </div>
                        <div ng-show="fn.currentUser.portalAdmin">
                            <br>
                            <label>User role</label>
                            <div class="styled-select select-role">
                                <select ng-model="newExport.role" ng-init="newExport.role=ADMIN" required="" class="ng-pristine ng-untouched ng-valid ng-valid-required">
                                    <option value="ADMIN" selected="selected">Admin</option>
                                    <option value="WORKER">Field User</option>
                                    <option value="CUSTOMER">Customer</option>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="reportOptions includeOnlyFlaggedPhotos">
                            <label>Include these photos:</label>
                            <div class="styled-select select-report">
                                <select ng-model="newExport.flaggedPhotos" ng-init="newExport.flaggedPhotos=NONE" required="" class="ng-pristine ng-untouched ng-invalid ng-invalid-required"><option value="? undefined:undefined ?"></option>
                                    <option value="NONE" selected="selected">All</option>
                                    <option value="INCLUDE_FLAGGED">Flagged photos only</option>
                                    <option value="EXCLUDE_FLAGGED">Unflagged photos only</option>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="newExport.timestampedPhotos" ng-show="fn.currentUser.portalAdmin">
                            <label>
                                <input type="checkbox" ng-model="newExport.timestampedPhotos" class="ng-pristine ng-untouched ng-valid">Timestamp photos
                            </label>
                        </div>
                    </td>
                </tr>
            </tbody></table>
            <br>

            <div class="control-group">
                <div class="controls">

                    <label>Field key to use in report filename (optional):</label>
                    <input type="text" ng-model="newExport.displayFieldForFileName" id="displayFieldForFileName" name="displayFieldForFileName" class="ng-pristine ng-untouched ng-valid">
                </div>
            </div>
        </form>
    </div>

    <div class="modal-footer">
        <div class="form-actions-proto">
            <a class="btn btn-cancel" ng-click="hideBatchReportModal()">Cancel</a>
            <a class="btn btn-primary" ng-click="doBatchReports()">Start Export</a>
            <p>After starting your export, <b>go to Admin/Batch Exports</b> to see the status of your export and download the results when complete. </p>
        </div>
    </div>

</div>
</div>

            <div class="list-wrapper">


                <h3 class="results-header ng-binding">4 Results </h3>
         

                <div id="fn_type_list-controls">
    
                    <div class="bulk-assign ng-hide" ng-hide="!selectedCount">
                    
                        <div class="bulk-assign-inner" ng-show="isPortalAdmin()">

                            <span class="dropdown ng-hide" ng-show="selectedCount &amp;&amp; userCanDo(BULK_ASSIGN)">
                            <a class="btn dropdown-toggle btn-flat menuAssign bulk-btn " data-toggle="dropdown" ng-click="showAssignmentMenu()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                <span class="infoValue">Assign</span>
                                <span class="caret"></span>
                            </a>

                       
                            
                            <ul class="dropdown-menu  menu assigneeMenu ng-hide" style="display:block;" ng-show="assigning">
                                <li class="assignFeedback ng-binding">Assign 0 items to: </li>
                                <li class="searchPopUp">
                                    <form class="ng-pristine ng-valid">
                                        <input type="text" ng-model="searchFilter" class="input-medium search-query deletable ng-pristine ng-untouched ng-valid" placeholder="Enter characters to search">
                                    </form>
                                </li>
                                    <div class="scroll_container1 ng-hide" ng-show="(bulkUserList.length > 0)">
                                        <ul class="scroll_container2">
                                            <li>
                                                <a ng-class="{selected: pendingUserAssignment == 'Unassigned'}" ng-click="setAssignedUser(null)">Unassigned</a>
                                            </li>

                                            <!-- ngRepeat: user in bulkUserList | filter: {displayName: searchFilter} track by $index -->
                                        </ul>
                                    </div>

                                    <div ng-show="loadingUserList" style="margin-left: 16px" class="ng-hide"><img src="../images/portal/spinner-material.gif" alt="Spinner"></div>

                                <li class="assignFormControl">
                                    <a ng-click="cancelAssignment()" class="cancel">Cancel</a>

                                    <span class="dis" ng-hide="pendingUserAssignment">Apply</span>

                                    <a ng-click="verifyAssignment()" ng-show="pendingUserAssignment" ng-class="{'disabled': disableAssign}" class="confirm ng-hide">Apply</a>

                                </li>
                            </ul>

                            <ul class="dropdown-menu  menu assigneeMenu removeVenderAssignment ng-hide" style="display:block;margin-top: 246px;" ng-show="assigning &amp;&amp; showAssignConfirm">
                                <p>One or more items are currently assigned.  This assignment will delete that assignment and all sub-assignments.</p>
                                <li class="assignFormControl">
                                    <a ng-click="cancelAssignment()" class="cancel">Cancel</a>
                                    <a ng-click="doAssignment()" ng-class="{'disabled': disableAssign}" class="confirm">Continue</a>
                                </li>
                            </ul>
                         </span>
 


                        <span class="dropdown ng-hide" ng-show="selectedCount &amp;&amp; userCanDo(BULK_DUE_DATE)">
                                <a class="btn dropdown-toggle btn-flat menuAssign bulk-btn " data-toggle="dropdown" ng-click="showDateDue()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                    <span class="infoValue">Due</span>
                                    <span class="caret"></span>
                                </a>

                        
                            <ul class="dropdown-menu  menu setDueDateMenu ng-hide" style="display:block;" ng-show="showDateDuePicker">
                                <li class="assignFeedback ng-binding">Set due date on 0 items to:</li>
                                <li class="datePickerWrapper">
                                    <input ng-model="dateDuePicker" bs-datepicker="" data-placement="bottom-right" type="input" ng-change="changeDateDue()" class="ng-pristine ng-untouched ng-valid">
                                    <button type="button" data-toggle="datepicker"><i class="icon-calendar"></i></button>
                                </li>
                                <li class="assignFormControl">
                                    <a ng-click="cancelDateDue()" class="cancel">Cancel</a>
                                    <a ng-click="applyDateDue()" ng-show="dateDuePicker" class="confirm ng-hide">Apply</a>
                                </li>
                            </ul>
                        </span>

                        <span class="dropdown ng-hide" ng-show="selectedCount &amp;&amp; userCanDo(BULK_STATUS_CHANGE)">
                            <a class="btn dropdown-toggle btn-flat  bulk-btn " data-toggle="dropdown" ng-click="showStatus()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                <span class="infoValue">Status</span>
                                <span class="caret"></span>
                            </a>


                            <ul class="dropdown-menu  menu statusMenu ng-hide" style="display:block;" ng-show="settingStatus">

                                    <li class="assignFeedback">Select a status</li>
                                    <div class="scroll_container1 ng-hide" ng-show="(bulkStatusList.length > 0)">
                                        <ul class="scroll_container2">
                                            <!-- ngRepeat: status in bulkStatusList track by status.id -->
                                        </ul>
                                    </div>
                                    <div ng-show="loadingStatusList" style="margin-left: 16px" class="ng-hide"><img src="../images/portal/spinner-material.gif" alt="Spinner"></div>
                                    <div ng-show="selectedStatus.workflowStateName==='DECLINED'" style="margin-left: 16px" class="ng-hide">
                                        <p>Reason for declining (10 chars minimum):</p>
                                        <input ng-model="declined_comment" data-placement="bottom-right" type="input" class="ng-pristine ng-untouched ng-valid">
                                    </div>

                                    <div ng-show="!loadingStatusList &amp;&amp; (!bulkStatusList || (bulkStatusList.length == 0))" style="margin-left: 16px">
                                        <p>No matching status options</p>
                                    </div>

                                    <li class="assignFormControl">
                                        <a ng-click="cancelStatus()" class="cancel">Cancel</a>
                                        <span ng-show="selectedStatus.id &amp;&amp; (selectedStatus.workflowStateName !=='DECLINED' || declined_comment.length > 10)" class="ng-hide">
                                        <a ng-click="verifyStatus()" class="confirm">Apply</a>
                                        </span>
                                    </li>
                            </ul>
                        </span>


                        <span class="moreMenuWrap ng-hide" ng-show="selectedCount &amp;&amp; (userCanDo(BULK_ARCHIVE) || userCanDo(ASSIGN_CUSTOMER_MANAGER) || userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS))">
                            <a class="btn dropdown-toggle btn-flat menuAssign bulk-btn " data-toggle="dropdown" ng-click="showMoreMenu()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                <span class="infoValue">More...</span>
                            </a>

                            <ul class="moreMenu dropdown-menu">
                                <li ng-show="selectedCount &amp;&amp; userCanDo(ASSIGN_CUSTOMER_MANAGER)" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showCustomerAssignmentMenu()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                                Set Customer
                                        </a>                            
                                </li>
                                <li ng-show="selectedCount &amp;&amp; userCanDo(ASSIGN_CUSTOMER_MANAGER)" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showManagerAssignmentMenu()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                               Set Manager
                                        </a>
                                </li>
                                <li ng-show="selectedCount &amp;&amp; userCanDo(ASSIGN_MARKET)  &amp;&amp; fn.feature.MARKETS_REGIONS &amp;&amp; fn.hasPermission('ADMIN_USERS')" class="ng-hide">
                                    <a class="" data-toggle="dropdown" ng-click="showMarketAssignmentMenu()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                           Set Market...
                                    </a>
                                </li>
                                 <li class="divider small ng-hide" ng-show="selectedCount &amp;&amp; fn.feature.USER_TAGGING"></li>
                              <li ng-show="selectedCount &amp;&amp; fn.feature.USER_TAGGING" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showBatchTagModal()" ng-class="project.changeStatusClass">
                                                Add Tags...
                                        </a>
                                </li>
                                 <li ng-show="selectedCount &amp;&amp; fn.feature.USER_TAGGING" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showBatchRemoveTagModal()" ng-class="project.changeStatusClass">
                                                Remove Tags...
                                        </a>
                                </li>

                               <li class="divider small"></li>
                              <li ng-show="selectedCount &amp;&amp; fn.feature.BATCH_REPORT_EXPORT" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showBatchReportModal()" ng-class="project.changeStatusClass">
                                                Batch Export PDFs...
                                        </a>
                                </li>
                                <li ng-show="selectedCount &amp;&amp; fn.feature.TENANT_INSPECTIONS &amp;&amp; userCanDo(BATCH_CONSUMER_SEND)" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showBatchSendModal()" ng-class="project.changeStatusClass">
                                                Batch Send to Recipients...
                                        </a>
                                </li>


                                <li class="divider small"></li>
                                <li ng-show="selectedCount &amp;&amp; fn.currentSearchConfiguration.containerSearch &amp;&amp; fn.userCanCreateProjects" class="ng-hide">
                                        <a class="ng-binding" data-toggle="dropdown" ng-click="showBatchCreateModal()" ng-class="project.changeStatusClass">
                                                Batch Create Work...
                                        </a>
                                </li>

                                <li ng-show="selectedCount &amp;&amp; userCanDo(BULK_ARCHIVE)" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showArchiveMenu()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                                Archive      
                                        </a>
                                </li>

                                <li ng-show="selectedCount &amp;&amp; userCanDo(BULK_ARCHIVE) &amp;&amp; ((searchOptions.isArchived=='true') || (searchOptions.isArchived==''))" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showUnarchiveMenu()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                                Unarchive
                                        </a>
                                </li>


                                <li class="divider small ng-hide" ng-show="selectedCount &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)"></li>
                                <li ng-show="selectedCount &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                        <a class="" data-toggle="dropdown" ng-click="showPermDelProjectModal()" ng-disabled="project.changeStatus" ng-class="project.changeStatusClass" style="position:relative;">
                                                Permanently Delete...      
                                        </a>
                                </li>
                            </ul>
                       






                            <ul class="dropdown-menu  menu setCustomerMenu ng-hide" style="display:block;" ng-show="customerAssigning">
                                <li class="assignFeedback ng-binding">Set customer on 0 items to: </li>
                                <li class="searchPopUp">
                                <form class="ng-pristine ng-valid">
                                    <input type="text" ng-model="customerSearch.$" class="input-medium search-query deletable ng-pristine ng-untouched ng-valid" placeholder="Enter characters to search">
                                </form>
                                </li>
                                <div class="scroll_container1 ng-hide" ng-show="(bulkCustomerList.length > 0)">
                                    <ul class="scroll_container2">

                                        <li>
                                            <a ng-class="{selected: pendingCustomerAssignment == 'Unassigned'}" ng-click="setAssignedCustomer(null)">Unassigned</a>
                                        </li>


                                        <!-- ngRepeat: user in bulkCustomerList | filter: customerSearch : strict track by $index -->
                                    </ul>
                                </div>
                                <li class="assignFormControl">
                                    <a ng-click="cancelCustomerAssignment()" class="cancel">Cancel</a>
                                    <span class="dis" ng-hide="pendingCustomerAssignment">Apply</span>
                                    <a ng-click="doCustomerAssignment()" ng-show="pendingCustomerAssignment" class="confirm ng-hide">Apply</a>
                                </li>
                                </ul>
                                <!-- set Manager pop up... -->
                                <ul class="dropdown-menu  menu setManagerMenu ng-hide" style="display:block;" ng-show="managerAssigning">

                                <li class="assignFeedback ng-binding">Set manager on 0 items to: </li>

                                <li class="searchPopUp">
                                    <form class="ng-pristine ng-valid">
                                        <input type="text" ng-model="managerSearch.$" class="input-medium search-query deletable ng-pristine ng-untouched ng-valid" placeholder="Enter characters to search">
                                    </form>
                                </li>
                                <div class="scroll_container1 ng-hide" ng-show="(bulkManagerList.length > 0)">
                                    <ul class="scroll_container2">

                                        <li class="searchPopUp">
                                            <a ng-class="{selected: pendingManagerAssignment == 'Unassigned'}" ng-click="setAssignedManager(null)">Unassigned</a>
                                        </li>


                                        <!-- ngRepeat: user in bulkManagerList | filter: managerSearch : strict track by $index -->
                                    </ul>
                                </div>
                                <li class="assignFormControl">
                                    <a ng-click="cancelManagerAssignment()" class="cancel">Cancel</a>
                                    <span class="dis" ng-hide="pendingManagerAssignment">Apply</span>
                                    <a ng-click="doManagerAssignment()" ng-show="pendingManagerAssignment" class="confirm ng-hide">Apply</a>
                                </li>
                            </ul>

                                <!-- archive pop up... -->
                            <ul class="dropdown-menu  menu archiveMenu ng-hide" style="display:block;top: 220px;" ng-show="archiving">
                                <li class="assignFeedback ng-binding">Archive 0 items?</li>
                                <li class="assignFormControl">
                                    <a ng-click="cancelArchive()" class="cancel">Cancel</a>
                                    <a ng-click="doArchive()" class="confirm">Archive</a>
                                </li>
                            </ul>


                            <ul class="dropdown-menu  menu unarchiveMenu ng-hide" style="display:block;top: 250px;" ng-show="unarchiving">
                                <li class="assignFeedback ng-binding">Unarchive 0 items?</li>
                                <li class="assignFormControl">
                                    <a ng-click="cancelUnarchive()" class="cancel">Cancel</a>
                                    <a ng-click="doUnarchive()" class="confirm">Unarchive</a>
                                </li>
                            </ul>

                        </span><!-- close moremenu wrap -->
                        

                         <!-- </span>close more menu wrap -->

                        <span ng-show="selectedCount" class="selectCount ng-binding ng-hide">0 Selected</span>

                    </div><!-- /bulk-assign inner -->
                </div><!-- /bulk-assign -->





               
    

                <!-- <div class="spanner">&nbsp;</div> -->


                <div class="search_filters" ng-hide="selectedCount">
                    <div class="formControls filter_status">
                        <label style="padding-left:1em;">Status <i class="icon-refresh glyphicon glyphicon-refresh spinning ng-hide" ng-show="templatesLoading"></i></label>
                        <div class="multiSelectWrap textEllipsisWrap" ng-class="{'disabled':templatesLoading}">
                            <div ng-hide="statusesLoading" ng-dropdown-multiselect="" options="filteredStatusList" selected-model="searchOptions.statusList" extra-settings="statusListSettings" checkboxes="true" translation-texts="statusListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Uncheck All</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> Complete</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> In Progress</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))"><div class="checkbox"><label class="ng-binding"><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))"> New</label></div></a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding">0 / 0 checked</a></li></ul></div></div>
                        </div>
                    </div>
                    <div class="formControls">
                        <label>Assigned</label>
                        <div class="multiSelectWrap textEllipsisWrap">
                            <div ng-dropdown-multiselect="" options="searchUsers" selected-model="searchOptions.assigned" extra-settings="userListSettings" translation-texts="userListTexts" class="ng-isolate-scope"><div class="multiselect-parent btn-group dropdown-multiselect"><button type="button" class="dropdown-toggle btn btn-default" ng-class="settings.buttonClasses" ng-click="toggleDropdown()"><span class="btnTxt ng-binding">All</span>&nbsp;<span class="caret"></span></button><ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? 'block' : 'none', height : settings.scrollable ? settings.scrollableHeight : 'auto' }" style="display: none; height: 275px;"><li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0" class="ng-hide"><a data-ng-click="selectAll()" class="ng-binding"><span class="glyphicon glyphicon-ok"></span>  Check All</a></li><li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();" class="ng-binding"><span class="glyphicon glyphicon-remove"></span>   Clear</a></li><li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) &amp;&amp; !settings.showUncheckAll" class="divider"></li><li ng-show="settings.enableSearch"><div class="dropdown-header search-menu searchPopUp"><input type="text" class="form-control ng-pristine ng-untouched ng-valid" style="" ng-model="searchFilter" placeholder="Search..."></div></li><li ng-show="settings.enableSearch" class="divider"></li><!-- ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> Unassigned</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> sam_stage_vendor2_fielduser</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> sam_stage_vendor_company2</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> Sam Stage 1</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li role="presentation" ng-repeat="option in options | filter: searchFilter" class="ng-scope"><a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))" class="ng-binding"><span data-ng-class="{'glyphicon glyphicon-ok': isChecked(getPropertyForObject(option,settings.idProp))}"></span> sam_stage_vendor_company</a></li><!-- end ngRepeat: option in options | filter: searchFilter --><li class="divider ng-hide" ng-show="settings.selectionLimit > 1"></li><li role="presentation" ng-show="settings.selectionLimit > 1" class="ng-hide"><a role="menuitem" class="ng-binding"> / 1 checked</a></li></ul></div></div>
                        </div>
                    </div>

                    <div class="formControls filter_text">
                        <div class="textSearch">
                            <form class="form-search ng-pristine ng-valid" ng-submit="newSearch()">
                                <input type="text" ng-model="searchOptions.search" class="input-medium search-query deletable ng-pristine ng-untouched ng-valid" placeholder="Display field text...">

                                

                                <span class="button"><input class="save btn" type="submit" value=""></span>

                                <a class="moreSearchOptions" ng-click="showEditSearchModal()" title="Click to see and select additional search filters...">&nbsp;

                            </a>

                                
                            </form>
                        </div>
                    </div>

                </div>





                
                    <div class="top-pager">
                        <div class="projectCount">
                            <strong class="ng-binding">1 - 4</strong> of <strong class="ng-binding">4</strong>
                        </div>
                        <div class="pagination">
                            <ul class="">
                                <li><a ng-click="pageProjects(previousPage.offset)"><span>«</span></a></li>
                                <li><a ng-click="pageProjects(nextPage.offset)"><span>»</span></a></li>
                            </ul>
                        </div>
                    </div>
                



            </div><!-- /fn_type_list-controls -->










            <div ng-hide="!loadingList" style="position: absolute; top: 48%; left: calc(50% + 80px);" class="ng-hide">
                <i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>
            </div>














            <table class="table fixed_header reportList" ng-hide="searchOptions.containerSearch">
                <thead>
                    <tr>
                    <th class="multiSelect checkbox">
                        <span ng-show="!selectedCount &amp;&amp; isPortalAdmin()" class="selectAllControl selectNone ng-scope" ng-click="selectAllProjects()" bs-tooltip="'select all'" data-delay="500" data-original-title="" title=""></span>
                        <span ng-show="selectedCount==projects.length &amp;&amp; (projects.length)" class="selectAllControl selectAll ng-scope ng-hide" ng-click="unselectAllProjects()" bs-tooltip="'deselect all'" data-delay="500" data-original-title="" title=""></span>
                        <span ng-show="selectedCount &amp;&amp; (selectedCount < projects.length)" class="selectAllControl selectSome ng-scope ng-hide" ng-click="unselectAllProjects()" bs-tooltip="'deselect all'" data-delay="500" data-original-title="" title=""></span>
                    </th>
                    <th class="displayImg">&nbsp;</th>
                    <th class="titleDesc" ng-class="sortingClass('title')" ng-click="sortBy('title', 'asc')">
                        <span>Title &amp; Description</span>
                    </th>
                    <th class="status" ng-class="sortingClass('_currentStatus.sortOrder')" ng-click="sortBy('_currentStatus.sortOrder', 'asc')">
                        <span>Status</span>
                    </th>
                    <th class="statusLastUpdated sortable" ng-class="sortingClass('statusLastUpdated')" ng-click="sortBy('statusLastUpdated', 'asc')" title="Status last updated">
                        <span>Updated</span>
                    </th>
                    <th c="" class="priority sortable" ng-class="sortingClass('priority')" ng-click="sortBy('priority', 'asc')">
                        <span>Priority</span>
                    </th>
                    <th class="dateDue sortable" ng-class="sortingClass('dateDue')" ng-click="sortBy('dateDue', 'asc')">
                        <span>Due</span>
                    </th>
                    <th class="assigned sortable" ng-class="sortingClass('_assignedUser.userRealName')" ng-click="sortBy('_assignedUser.userRealName', 'asc')">
                        <span>Assigned</span>
                    </th>
                    <th class="tags sortable" ng-show="isPortalAdmin()">
                        <span>Tags</span>
                    </th>
                   <th class="templateSource sortable" ng-class="sortingClass('_template.title')" ng-click="sortBy('_template.title', 'asc')">
                        <span>Template</span>
                    </th>
                    <!-- <th class="sortable" ng-class="sortingClass('_template.title')"
                        ng-click="sortBy('_template.type', 'asc')">Type
                    </th> -->
                    <th class="dateCreated sortable" ng-class="sortingClass('dateCreated')" ng-click="sortBy('dateCreated', 'asc')">
                        <span>Created</span>
                    </th>
                    <th class="utility">
                        <div class="setResultsPerPage" title="Results per page">
                            <div class="styled-select">
                                <select ng-model="searchOptions.max" ng-change="changeMax()" class="ng-pristine ng-untouched ng-valid">
                                    <option value="20">20</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                        </div>
                    </th>
                    </tr>
                </thead>

                <tbody>
                    <!-- -->
                    <!-- ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">

                        <td class="checkbox">

                            <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508723">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc desc">        
                        <!-- 2. PROJECT Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508723" class="ng-binding">Inspection1</a>
                                <span class="containerIcon" ng-show="project.container" title="Property: ContainerProperty1">&nbsp;</span></h4>
                            <p class="ng-binding">23434</p>
                            <p class="ng-binding">Mr. Inspector</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>

                            <p class="projectTooltip truncate_140px ng-hide" ng-show="project.marketDisplay &amp;&amp; fn.feature.MARKETS_REGIONS &amp;&amp; fn.hasPermission('ADMIN_USERS')" title=": ">
                               <span class="ng-binding"></span> 
                                <!-- <br> -->
                            </p>
           
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding ng-hide"></span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                    <td class=" status">
                        <!-- 3. Status...  -->
                        <p style="margin-bottom: 2px" class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>

                         <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508723" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508723" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    <td class="priority" ng-style="project.priorityStyle">
                        <p class="ng-binding">None</p>
                    </td>
                    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle" class="ng-binding"></span>
                    </td>
                    <td class="assigned">
                        <span class="assignedUser ng-hide" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; project.assignedUser.isCompany &amp;&amp; fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/" class="ng-binding">
                            </a></span>
                        <span class="assignedUser ng-binding" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            </span>
                    </td>
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <!-- <td class="templateSource">
                       <span title="{{project.template.title}}">{{project.template.type.displayName}}</span> 
                    </td> -->
                    <td class="dateCreated">
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 3:22 AM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, COMMENT)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes  hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment line-clamp ng-binding"></p>
                                        </div>
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" ng-click="showAllComments(project)" title="Add a comment">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown" title="Copy, Archive... "><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">
                                            Archive…
                                            
                                        </a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">
                                            Copy…
                                            
                                        </a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                        <a class="edit" ng-click="unarchiveProject(project)">
                                            Unarchive…
                                        </a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">
                                            <!-- delete the contained item -->
                                          Permanently Delete…
                                        </a>
                                    </li>
                  
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">

                        <td class="checkbox">

                            <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508724">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc desc">        
                        <!-- 2. PROJECT Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508724" class="ng-binding">ContainedInspection1</a>
                                <span class="containerIcon" ng-show="project.container" title="Property: ContainerProperty1">&nbsp;</span></h4>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding">asdfasdfasdf</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>

                            <p class="projectTooltip truncate_140px ng-hide" ng-show="project.marketDisplay &amp;&amp; fn.feature.MARKETS_REGIONS &amp;&amp; fn.hasPermission('ADMIN_USERS')" title=": ">
                               <span class="ng-binding"></span> 
                                <!-- <br> -->
                            </p>
           
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding ng-hide"></span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                    <td class=" status">
                        <!-- 3. Status...  -->
                        <p style="margin-bottom: 2px" class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>

                         <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508724" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508724" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    <td class="priority" ng-style="project.priorityStyle">
                        <p class="ng-binding">None</p>
                    </td>
                    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle" class="ng-binding"></span>
                    </td>
                    <td class="assigned">
                        <span class="assignedUser ng-hide" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; project.assignedUser.isCompany &amp;&amp; fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/" class="ng-binding">
                            </a></span>
                        <span class="assignedUser ng-binding" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            </span>
                    </td>
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <!-- <td class="templateSource">
                       <span title="{{project.template.title}}">{{project.template.type.displayName}}</span> 
                    </td> -->
                    <td class="dateCreated">
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 3:24 AM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, COMMENT)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes  hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment line-clamp ng-binding"></p>
                                        </div>
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" ng-click="showAllComments(project)" title="Add a comment">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown" title="Copy, Archive... "><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">
                                            Archive…
                                            
                                        </a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">
                                            Copy…
                                            
                                        </a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                        <a class="edit" ng-click="unarchiveProject(project)">
                                            Unarchive…
                                        </a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">
                                            <!-- delete the contained item -->
                                          Permanently Delete…
                                        </a>
                                    </li>
                  
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">

                        <td class="checkbox">

                            <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508726">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc desc">        
                        <!-- 2. PROJECT Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508726" class="ng-binding">ContainedInspection3OfInspection2</a>
                                <span class="containerIcon" ng-show="project.container" title="Property: ContainedPropertyOfInspection1">&nbsp;</span></h4>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>

                            <p class="projectTooltip truncate_140px ng-hide" ng-show="project.marketDisplay &amp;&amp; fn.feature.MARKETS_REGIONS &amp;&amp; fn.hasPermission('ADMIN_USERS')" title=": ">
                               <span class="ng-binding"></span> 
                                <!-- <br> -->
                            </p>
           
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding">sam_stage_vendor_company2</span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                    <td class=" status">
                        <!-- 3. Status...  -->
                        <p style="margin-bottom: 2px" class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>

                         <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508726" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508726" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    <td class="priority" ng-style="project.priorityStyle">
                        <p class="ng-binding">None</p>
                    </td>
                    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle" class="ng-binding"></span>
                    </td>
                    <td class="assigned">
                        <span class="assignedUser ng-hide" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; project.assignedUser.isCompany &amp;&amp; fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/" class="ng-binding">
                            </a></span>
                        <span class="assignedUser ng-binding" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            </span>
                    </td>
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <!-- <td class="templateSource">
                       <span title="{{project.template.title}}">{{project.template.type.displayName}}</span> 
                    </td> -->
                    <td class="dateCreated">
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 3:27 AM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, COMMENT)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes  hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment line-clamp ng-binding"></p>
                                        </div>
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" ng-click="showAllComments(project)" title="Add a comment">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown" title="Copy, Archive... "><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">
                                            Archive…
                                            
                                        </a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">
                                            Copy…
                                            
                                        </a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                        <a class="edit" ng-click="unarchiveProject(project)">
                                            Unarchive…
                                        </a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">
                                            <!-- delete the contained item -->
                                          Permanently Delete…
                                        </a>
                                    </li>
                  
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">

                        <td class="checkbox">

                            <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508736">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc desc">        
                        <!-- 2. PROJECT Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508736" class="ng-binding">InspectionContainer1</a>
                                <span class="containerIcon ng-hide" ng-show="project.container" title="Property: ">&nbsp;</span></h4>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding">asdfasdfa</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>

                            <p class="projectTooltip truncate_140px ng-hide" ng-show="project.marketDisplay &amp;&amp; fn.feature.MARKETS_REGIONS &amp;&amp; fn.hasPermission('ADMIN_USERS')" title=": ">
                               <span class="ng-binding"></span> 
                                <!-- <br> -->
                            </p>
           
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding ng-hide"></span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                    <td class=" status">
                        <!-- 3. Status...  -->
                        <p style="margin-bottom: 2px" class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>

                         <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508736" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508736" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    <td class="priority" ng-style="project.priorityStyle">
                        <p class="ng-binding">None</p>
                    </td>
                    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle" class="ng-binding"></span>
                    </td>
                    <td class="assigned">
                        <span class="assignedUser ng-hide" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; project.assignedUser.isCompany &amp;&amp; fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/" class="ng-binding">
                            </a></span>
                        <span class="assignedUser ng-binding" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() &amp;&amp; (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            </span>
                    </td>
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <!-- <td class="templateSource">
                       <span title="{{project.template.title}}">{{project.template.type.displayName}}</span> 
                    </td> -->
                    <td class="dateCreated">
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 6:49 PM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, COMMENT)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes  hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment line-clamp ng-binding"></p>
                                        </div>
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" ng-click="showAllComments(project)" title="Add a comment">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown" title="Copy, Archive... "><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">
                                            Archive…
                                            
                                        </a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">
                                            Copy…
                                            
                                        </a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                        <a class="edit" ng-click="unarchiveProject(project)">
                                            Unarchive…
                                        </a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">
                                            <!-- delete the contained item -->
                                          Permanently Delete…
                                        </a>
                                    </li>
                  
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id -->
                </tbody>
            </table>



















            <table class="table fixed_header propertyList ng-hide" ng-hide="!searchOptions.containerSearch">
                <thead>
                    <tr>
                    <th class="multiSelect checkbox">
                        <span ng-show="!selectedCount &amp;&amp; isPortalAdmin()" class="selectAllControl selectNone ng-scope" ng-click="selectAllProjects()" bs-tooltip="'select all'" data-delay="500" data-original-title="" title=""></span>
                        <span ng-show="selectedCount==projects.length &amp;&amp; (projects.length)" class="selectAllControl selectAll ng-scope ng-hide" ng-click="unselectAllProjects()" bs-tooltip="'deselect all'" data-delay="500" data-original-title="" title=""></span>
                        <span ng-show="selectedCount &amp;&amp; (selectedCount < projects.length)" class="selectAllControl selectSome ng-scope ng-hide" ng-click="unselectAllProjects()" bs-tooltip="'deselect all'" data-delay="500" data-original-title="" title=""></span></th>
                    <th class="displayImg">&nbsp;</th>
                    <th class="titleDesc sortable" ng-class="sortingClass('title')" ng-click="sortBy('title', 'asc')">
                        <span>Title &amp; Description</span>
                    </th>
                    <th class="status sortable" ng-class="sortingClass('_currentStatus.sortOrder')" ng-click="sortBy('_currentStatus.sortOrder', 'asc')">
                        <span>Status</span>
                    </th>
                    <th class="statusLastUpdated sortable" ng-class="sortingClass('statusLastUpdated')" ng-click="sortBy('statusLastUpdated', 'asc')" title-"status="" last="" updated"=""><span>Updated</span>
                    </th>
                   <!--  <th class="priority sortable" ng-class="sortingClass('priority')" ng-click="sortBy('priority', 'asc')">
                        Priority
                    </th> -->
                 <!--    <th class="dateDue sortable" ng-class="sortingClass('dateDue')" ng-click="sortBy('dateDue', 'asc')">Due
                    </th> -->
                   <!--  <th class="assigned sortable" ng-class="sortingClass('_assignedUser.userRealName')"
                        ng-click="sortBy('_assignedUser.userRealName', 'asc')">Assigned
                    </th> -->
                     <th class="tags sortable" ng-show="isPortalAdmin()"><span>Tags</span>
                    </th>
                    <th class="templateSource sortable" ng-class="sortingClass('_template.title')" ng-click="sortBy('_template.type', 'asc')"><span>Template/Type</span>
                    </th>
                    <th class="dateCreated sortable" ng-class="sortingClass('dateCreated')" ng-click="sortBy('dateCreated', 'asc')"><span>Created</span>
                    </th>
                    <th class="utility">
                        <div class="setResultsPerPage" title="Results per page">
                            <div class="styled-select">
                                <select ng-model="searchOptions.max" ng-change="changeMax()" class="ng-pristine ng-untouched ng-valid">
                                    <option value="20">20</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                        </div>
                    </th>
                    </tr>
                </thead>
                <tbody>
                    <!-- ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">
                        <td class="checkbox">
                             <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508723">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc">
                        <!-- 2. PROPERTY Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508723" class="ng-binding">Inspection1</a></h4>
                            <p class="ng-binding">23434</p>
                            <p class="ng-binding">Mr. Inspector</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>
                       
                            <p class="projectTooltip truncate_140px ng-binding ng-hide" ng-show="project.marketDisplay" title=": ">
                                
                            </p>
                            <br>
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding ng-hide"></span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                   
                    <td class="status">
                        <!-- 3. Status...  -->
                        <p class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>
                        <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508723" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508723" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    

                   <!--  <td class="priority" ng-style="project.priorityStyle">
                        <p>{{project.priority}}</p>
                    </td> -->
                 <!--    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle">{{project.dateDueDisplay}}</span>
                    </td> -->
               <!--      <td class="assigned">
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && project.assignedUser.isCompany && fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/{{project.assignedUser.relationId}}">
                            {{project.assignedUser.userRealName}}</a></span>
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            {{project.assignedUser.userRealName}}</span>
                   </td> -->
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <td class="dateCreated">
        
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 3:22 AM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, ADMIN)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment ng-binding"></p>
                                        </div>
                                       <!--  <div ng-hide="project.lastComment">
                                            <p class="author">No comments yet...</p>
                                        </div> -->
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" style="opacity: .3;" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown"><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">Archive</a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp; !project.isArchived" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">Copy...</a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                       
                                        <a class="edit" ng-click="unarchiveProject(project)"> Unarchive</a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                     <!--    <a class="edit"  ng-click="deleteProject(project)" style="color:red;">Permanently Delete</a>
                                      
                                        <!-- container delete -->
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">Permanently Delete...</a>
                                    </li>
             
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">
                        <td class="checkbox">
                             <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508724">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc">
                        <!-- 2. PROPERTY Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508724" class="ng-binding">ContainedInspection1</a></h4>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding">asdfasdfasdf</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>
                       
                            <p class="projectTooltip truncate_140px ng-binding ng-hide" ng-show="project.marketDisplay" title=": ">
                                
                            </p>
                            <br>
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding ng-hide"></span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                   
                    <td class="status">
                        <!-- 3. Status...  -->
                        <p class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>
                        <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508724" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508724" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    

                   <!--  <td class="priority" ng-style="project.priorityStyle">
                        <p>{{project.priority}}</p>
                    </td> -->
                 <!--    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle">{{project.dateDueDisplay}}</span>
                    </td> -->
               <!--      <td class="assigned">
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && project.assignedUser.isCompany && fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/{{project.assignedUser.relationId}}">
                            {{project.assignedUser.userRealName}}</a></span>
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            {{project.assignedUser.userRealName}}</span>
                   </td> -->
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <td class="dateCreated">
        
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 3:24 AM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, ADMIN)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment ng-binding"></p>
                                        </div>
                                       <!--  <div ng-hide="project.lastComment">
                                            <p class="author">No comments yet...</p>
                                        </div> -->
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" style="opacity: .3;" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown"><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">Archive</a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp; !project.isArchived" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">Copy...</a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                       
                                        <a class="edit" ng-click="unarchiveProject(project)"> Unarchive</a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                     <!--    <a class="edit"  ng-click="deleteProject(project)" style="color:red;">Permanently Delete</a>
                                      
                                        <!-- container delete -->
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">Permanently Delete...</a>
                                    </li>
             
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">
                        <td class="checkbox">
                             <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508726">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc">
                        <!-- 2. PROPERTY Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508726" class="ng-binding">ContainedInspection3OfInspection2</a></h4>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>
                       
                            <p class="projectTooltip truncate_140px ng-binding ng-hide" ng-show="project.marketDisplay" title=": ">
                                
                            </p>
                            <br>
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding">sam_stage_vendor_company2</span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                   
                    <td class="status">
                        <!-- 3. Status...  -->
                        <p class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>
                        <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508726" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508726" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    

                   <!--  <td class="priority" ng-style="project.priorityStyle">
                        <p>{{project.priority}}</p>
                    </td> -->
                 <!--    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle">{{project.dateDueDisplay}}</span>
                    </td> -->
               <!--      <td class="assigned">
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && project.assignedUser.isCompany && fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/{{project.assignedUser.relationId}}">
                            {{project.assignedUser.userRealName}}</a></span>
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            {{project.assignedUser.userRealName}}</span>
                   </td> -->
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <td class="dateCreated">
        
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 3:27 AM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, ADMIN)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment ng-binding"></p>
                                        </div>
                                       <!--  <div ng-hide="project.lastComment">
                                            <p class="author">No comments yet...</p>
                                        </div> -->
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" style="opacity: .3;" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown"><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">Archive</a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp; !project.isArchived" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">Copy...</a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                       
                                        <a class="edit" ng-click="unarchiveProject(project)"> Unarchive</a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                     <!--    <a class="edit"  ng-click="deleteProject(project)" style="color:red;">Permanently Delete</a>
                                      
                                        <!-- container delete -->
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">Permanently Delete...</a>
                                    </li>
             
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id --><tr ng-hide="loadingList" ng-repeat="project in projects track by project.id" ng-class="{selectedRow:project.selected}" class="ng-scope">
                        <td class="checkbox">
                             <input ng-show="isPortalAdmin()" type="checkbox" name="your-group" value="unit-in-group" ng-model="project.selected" ng-change="countSelected()" class="ng-pristine ng-untouched ng-valid">
                        </td>
                        <td class="displayImg">
                            <!-- 1. Thumbnail  -->
                            <a href="/app/#/project/show/508736">
                                <div class="typeThumb">
                                    <img ng-show="project.projectMedia" class="img ng-hide">
                                </div>
                            </a>
                        </td>
                    <td class="titleDesc">
                        <!-- 2. PROPERTY Title and other display fields  -->
                        <div class="typeDesc">
                            <h4><a href="/app/#/project/show/508736" class="ng-binding">InspectionContainer1</a></h4>
                            <p class="ng-binding">234234</p>
                            <p class="ng-binding">asdfasdfa</p>
                            <p class="ng-binding"></p>
                            <p class="ng-binding" style="margin-bottom: 4px;"></p>
                       
                            <p class="projectTooltip truncate_140px ng-binding ng-hide" ng-show="project.marketDisplay" title=": ">
                                
                            </p>
                            <br>
                            <p class="managerCustomer projectTooltip" ng-show="fn.userHasViewAssign() &amp;&amp; fn.hasPermission('VIEW_CUSTOMER_MANAGER')" title="Manager">
                                <span ng-show="project.assignedManager.userRealName" class="ng-binding ng-hide"></span><span ng-show="(project.assignedManager &amp;&amp; project.assignedCustomer)" class="ng-hide">, </span><span ng-show="project.assignedCustomer.userRealName" class="ng-binding ng-hide"></span>
                            </p>
                        </div>
                    </td>
                   
                    <td class="status">
                        <!-- 3. Status...  -->
                        <p class="ng-binding">New<br>
                            <span class="daysIn ng-binding" ng-show="project.daysInStatus != 1"> 2 days</span>
                            <span class="daysIn ng-binding ng-hide" ng-show="project.daysInStatus == 1"> 2 day</span>
                        </p>
                        <div ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.lastPushAction" class="ng-hide">
                            <a ng-hide="project.lastPushAction.status == 'ERROR'" class="edit ng-scope" bs-tooltip="''" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508736" data-original-title="" title="">
                                <i class="ikon ikon-integration hoverFadeAnimation"></i>
                            </a>
                            <a ng-show="project.lastPushAction.status == 'ERROR'" class="edit ng-scope ng-hide" bs-tooltip="':'" data-placement="bottom" data-delay="750" href="/app/#/integration/list/508736" data-original-title="" title="">
                                <i class="ikon ikon-integration-error "></i>
                            </a>
                        </div>
                        <!-- ngIf: project.sentToConsumer -->
                        <p class="isArchived ng-hide" ng-show="project.isArchived"><span class="label">Archived</span></p>
                    </td>
                    <td class="statusLastUpdated">
                        <!-- 3. Status...  -->
                        <span aria-labelledby="dateCreated-label" class="ng-binding"> </span>
                    </td>
                    

                   <!--  <td class="priority" ng-style="project.priorityStyle">
                        <p>{{project.priority}}</p>
                    </td> -->
                 <!--    <td class="dateDue">
                        <span aria-labelledby="dateCreated-label" ng-style="project.dateDueStyle">{{project.dateDueDisplay}}</span>
                    </td> -->
               <!--      <td class="assigned">
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && project.assignedUser.isCompany && fn.hasPermission('ADMIN_USERS')"><a href="/app/#/vendor/show/{{project.assignedUser.relationId}}">
                            {{project.assignedUser.userRealName}}</a></span>
                        <span class="assignedUser" aria-labelledby="dateCreated-label" ng-show="fn.userHasViewAssign() && (!project.assignedUser.isCompany || !fn.hasPermission('ADMIN_USERS'))">
                            {{project.assignedUser.userRealName}}</span>
                   </td> -->
                    <td class="tags" ng-show="isPortalAdmin()">
                        <!-- ngRepeat: tag in project.tags track by tag.id -->
                    </td>
                    <td class="templateSource ng-binding">
                        InspectionTemplate2 v1<span class="type ng-binding">Inspection</span>
                    </td>
                    <td class="dateCreated">
        
                        <span aria-labelledby="dateCreated-label" class="ng-binding">1/14/23 6:49 PM</span>
                    </td>
                    <td class="utility">

                        <ul class="list-utility-menu">
                            <!-- comments -->
                            <li ng-show="fn.userCan(project, ADMIN)" class="">
                                <a ng-show="project.lastComment" class="commentPreview ng-hide" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-yes hoverFadeAnimation partialFade"></i>
                                    <div class="fn-tp">
                                        <div>
                                        <h3>Last Comment</h3>
                                        <p class="author ng-binding"><strong class="ng-binding"></strong>  </p>
                                        <p class="comment ng-binding"></p>
                                        </div>
                                       <!--  <div ng-hide="project.lastComment">
                                            <p class="author">No comments yet...</p>
                                        </div> -->
                                    </div>
                                </a>
                                <a ng-hide="project.lastComment" class="" style="opacity: .3;" ng-click="showAllComments(project)">
                                    <i class="ikon ikon-open-comments-none hoverFadeAnimation"></i>
                                </a>
                            </li>
                            <!-- more menu -->
                            <li class="dropdown more" ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id)">
                                <a class="dropdown-toggle" data-toggle="dropdown"><i class=" ikon ikon-show-controls-more hoverFadeAnimation share"></i></a>
                                    <ul class="dropdown-menu pull-right">
                                    <!-- integration -->
                                   
                                    <!-- archive -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp;    !project.isArchived" class="">
                                        <a class="edit" ng-click="archiveProject(project)">Archive</a>
                                    </li>
                                    <!-- clone -->
                                    <li ng-show="(fn.userCan(project, ADMIN) || project.creator.id == fn.currentUser.id) &amp;&amp; !project.isArchived" class="">
                                        <a class="edit" ng-click="showCopyProjectModal(project)">Copy...</a>
                                    </li>
                                    <!-- restore -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived" class="ng-hide">
                                       
                                        <a class="edit" ng-click="unarchiveProject(project)"> Unarchive</a>
                                    </li>
                                    <!-- perm del -->
                                    <li ng-show="fn.userCan(project, ADMIN) &amp;&amp; project.isArchived &amp;&amp; userCanDo(ADMIN_PERMANENTLY_DELETE_PROJECTS)" class="ng-hide">
                                     <!--    <a class="edit"  ng-click="deleteProject(project)" style="color:red;">Permanently Delete</a>
                                      
                                        <!-- container delete -->
                                        <a class="edit" ng-click="permanentlyDeleteProperty(project)">Permanently Delete...</a>
                                    </li>
             
                                </ul>
                            </li>
                        </ul>
                    </td>
                    </tr><!-- end ngRepeat: project in projects track by project.id -->
                </tbody>
            </table>








            


            <!-- </div>  /no results wrapper: this is hidden when the results are 0 -->



        </div><!-- /list wrapper -->

    </div><!-- /fn_type_list_inner -->



        



    </div><!-- /mainContent     -->




    <!-- For PETER if he wants to add some space for non paging case
    <div ng-hide="showPaging" class="container">
    </div>
    -->
    
</div>
  <!-- close project-list -->


        <div id="save-search-modal" class="fn_modal modal hide fade ng-scope" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-header">
                <h3 ng-show="!forceNewSearch">Save View</h3>
                <h3 ng-show="forceNewSearch" class="ng-hide">Save As New View</h3>
            </div>
            <form id="saveSearchResultsForm" method="post" class="ng-pristine ng-valid">
                <div class="modal-body">
                    <div class="controls">
                        <label>Name:</label>
                        <input type="text" ng-model="searchOptions.newSearchName " focus-on="savingNewSearchModal" class="ng-pristine ng-untouched ng-valid">
                    </div>
                    <div class="controls ng-hide" ng-show="showCreateNewSearch &amp;&amp; searchOptions.savedSearchId">
                        <label>
                            <input ng-model="isCreateNewSearch" id="isCreateNewSearch" name="isCreateNewSearch" type="checkbox" class="ng-pristine ng-untouched ng-valid">
                            Save as a copy
                        </label>
                    </div>
                    <div ng-show="fn.hasPermission('SPECIFY_SEARCH_TYPE')">
                        <label bs-tooltip="'Who can see this view'" class="ng-scope" data-original-title="" title="">Who can see this view:</label>
                        <div class="styled-select">
                            <select ng-model="searchOptions.savedSearchType" class="ng-pristine ng-untouched ng-valid">
                                <option value="ADMIN">Users with Admin and Manager Roles - ADMIN</option>
                                <option value="EVERYONE">All Users - EVERYONE</option>
                                <option ng-hide="(searchOptions.savedSearchId) &amp;&amp; (fn.currentSearchConfiguration.savedSearch.creator.id != fn.currentUser.id)" value="PRIVATE">Just me - PRIVATE</option>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div ng-show="fn.hasPermission('SPECIFY_SEARCH_TYPE') &amp;&amp; searchOptions.savedSearchId" class="ng-hide">
                        <p class="ng-binding">(This view was created by: sam_stage_vendor_company2)</p>
                    </div>
                    <div ng-show="!fn.hasPermission('SPECIFY_SEARCH_TYPE')" class="ng-hide">
                        <p>This will be seen by just me.</p>
                    </div>

                    </div><!-- /modal-body -->
                <div class="modal-footer">
                    <div class="form-actions-proto">
                        <a class="btn btn-cancel" ng-click="hideSaveNewSearch()">Cancel</a>
                    <a class="btn btn-primary" ng-click="saveSearch()">Save</a>
                    </div>
                </div>
            </form>
        </div>


    <div id="manage-views-modal" class="fn_modal modal hide fade manage-views-modal ng-scope" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-header">                
            <h3 class="ng-binding">Manage Work Views</h3>
            <p>Manage all views. Rename, drag rows to re-order views.  This will re-order views for all users.</p>
        </div>
        <div class="modal-body">
            <table class="table fn-table userList scroll">
                <thead>
                    <tr>
                        <th class="move">&nbsp;</th>
                        <th class="name">Name</th>
                        <th class="kind">Kind</th>
                        <th class="delete">Delete</th>
                    </tr>
                </thead>
                <tbody ng-show="fn.hasPermission('ADMIN_ADVANCED_SEARCH')" ui:sortable="" ui-options="searchSortableOptions" ng-model="fn.currentSearchConfiguration.savedSearches" class="ng-pristine ng-untouched ng-valid ui-sortable">
                    <!-- ngRepeat: search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id --><tr ng-repeat="search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id" class="ng-scope">
                        <th class="myHandleWrap move"><div class="myHandle" title="drag to reorder"></div></th>
                        <td class="name">                
                            <!-- ngIf: newName.targetView != search.id --><div ng-if="newName.targetView != search.id" class="renameOff ng-scope">
                                <span class="ng-binding">All Properties</span> 
                                <!-- ngIf: !newName.renameOn --><a ng-click="showRenameView(search)" ng-if="!newName.renameOn" class="btn btn-small ng-scope" title="Rename...">&nbsp;</a><!-- end ngIf: !newName.renameOn -->
                            </div><!-- end ngIf: newName.targetView != search.id -->

                            <!-- ngIf: newName.targetView == search.id -->
                        </td>
                        <td class="kind ng-binding">EVERYONE</td>
                        <td class="delete " style="text-align: center;"><a ng-click="showDeleteSearch(search)"><i class="ikon ikon-delete"></i></a></td>
                    </tr><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id --><tr ng-repeat="search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id" class="ng-scope">
                        <th class="myHandleWrap move"><div class="myHandle" title="drag to reorder"></div></th>
                        <td class="name">                
                            <!-- ngIf: newName.targetView != search.id --><div ng-if="newName.targetView != search.id" class="renameOff ng-scope">
                                <span class="ng-binding">All Inspections</span> 
                                <!-- ngIf: !newName.renameOn --><a ng-click="showRenameView(search)" ng-if="!newName.renameOn" class="btn btn-small ng-scope" title="Rename...">&nbsp;</a><!-- end ngIf: !newName.renameOn -->
                            </div><!-- end ngIf: newName.targetView != search.id -->

                            <!-- ngIf: newName.targetView == search.id -->
                        </td>
                        <td class="kind ng-binding">EVERYONE</td>
                        <td class="delete " style="text-align: center;"><a ng-click="showDeleteSearch(search)"><i class="ikon ikon-delete"></i></a></td>
                    </tr><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id --><tr ng-repeat="search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id" class="ng-scope">
                        <th class="myHandleWrap move"><div class="myHandle" title="drag to reorder"></div></th>
                        <td class="name">                
                            <!-- ngIf: newName.targetView != search.id --><div ng-if="newName.targetView != search.id" class="renameOff ng-scope">
                                <span class="ng-binding">All Punchlists</span> 
                                <!-- ngIf: !newName.renameOn --><a ng-click="showRenameView(search)" ng-if="!newName.renameOn" class="btn btn-small ng-scope" title="Rename...">&nbsp;</a><!-- end ngIf: !newName.renameOn -->
                            </div><!-- end ngIf: newName.targetView != search.id -->

                            <!-- ngIf: newName.targetView == search.id -->
                        </td>
                        <td class="kind ng-binding">EVERYONE</td>
                        <td class="delete " style="text-align: center;"><a ng-click="showDeleteSearch(search)"><i class="ikon ikon-delete"></i></a></td>
                    </tr><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id --><tr ng-repeat="search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id" class="ng-scope">
                        <th class="myHandleWrap move"><div class="myHandle" title="drag to reorder"></div></th>
                        <td class="name">                
                            <!-- ngIf: newName.targetView != search.id --><div ng-if="newName.targetView != search.id" class="renameOff ng-scope">
                                <span class="ng-binding">All</span> 
                                <!-- ngIf: !newName.renameOn --><a ng-click="showRenameView(search)" ng-if="!newName.renameOn" class="btn btn-small ng-scope" title="Rename...">&nbsp;</a><!-- end ngIf: !newName.renameOn -->
                            </div><!-- end ngIf: newName.targetView != search.id -->

                            <!-- ngIf: newName.targetView == search.id -->
                        </td>
                        <td class="kind ng-binding">EVERYONE</td>
                        <td class="delete " style="text-align: center;"><a ng-click="showDeleteSearch(search)"><i class="ikon ikon-delete"></i></a></td>
                    </tr><!-- end ngRepeat: search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' track by search.id -->
                </tbody>
                <tbody ng-show="!fn.hasPermission('ADMIN_ADVANCED_SEARCH')" ui:sortable="" ui-options="searchSortableOptions" ng-model="fn.currentSearchConfiguration.savedSearches" class="ng-pristine ng-untouched ng-valid ui-sortable ng-hide">
                <!-- ngRepeat: search in fn.currentSearchConfiguration.savedSearches | orderBy:'sortOrder' | filter: {'typeName':'Private'} track by search.id -->
                </tbody>

            </table>

        </div>
        <div class="modal-footer">
            <div class="form-actions-proto">
                <a class="btn btn-primary" ng-click="orderSearches()" data-dismiss="modal" aria-hidden="true">Close</a>
            </div>
        </div>
    </div>





    <div id="manage-favorites-modal" class="fn_modal modal hide fade manage-favorites-modal ng-scope" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-header">
            <h3>Manage Favorite Views</h3>
            <p>Manage your favorites. Rename, drag rows to reorder, click the stars to remove from your favorites.</p>
        </div>
        <div class="modal-body">
            <table class="table fn-table scroll userList">
                <thead>
                    <tr><th class="move">&nbsp;</th>
                    <th class="name">Name</th>
                    <th class="kind"><span class="favCol">&nbsp;</span></th>
                </tr></thead>
                <tbody ui:sortable="" ui-options="favoriteSortableOptions" ng-model="fn.currentSearchConfiguration.favoriteSearches" class="ng-pristine ng-untouched ng-valid ui-sortable">
                    <!-- ngRepeat: search in fn.currentSearchConfiguration.favoriteSearches | orderBy:'favoriteOrder' track by search.id -->
                </tbody>
            </table>
        </div>
        <div class="modal-footer">
            <div class="form-actions-proto">
                <a class="btn btn-primary" ng-click="orderFavorites()" data-dismiss="modal" aria-hidden="true">Close</a>
            </div>
        </div>
    </div>


<div id="batchTagModal" class="fn_modal modal hide fade ng-scope">
    <div class="modal-header">
        <h3>Add Tags to Projects</h3>
    </div>
    <div class="modal-body">
        <!-- class="saveSearch deleteSearch" -->
        <!-- <p>Select tags to add:</p> -->
        <form class="ng-pristine ng-valid">
            <div class="control-group">
                <div class="controls batch-tag-list">
                    <!-- ngRepeat: tag in tags track by tag.id -->
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <div class="form-actions-proto">
            <a class="btn btn-cancel" ng-click="hideBatchTagModal()">Cancel</a>
            <a class="btn btn-submit btn-primary" ng-click="doBatchTagProjects()" style="padding: 10px 25px;">Add Tags</a>
        </div>
    </div>
</div>

<div id="batchRemoveTagModal" class="fn_modal modal hide fade ng-scope">
    <div class="modal-header">
        <h3>Remove Tags from Projects</h3>
    </div>
    <div class="modal-body">
        <!-- class="saveSearch deleteSearch" -->
        <!-- <p>Select tags to remove:</p> -->
        <form class="ng-pristine ng-valid">
            <div class="control-group">
                <div class="controls batch-tag-list">
                    <!-- ngRepeat: tag in tags track by tag.id -->
                </div>
            </div>
        </form>
    </div>
    <div class="modal-footer">
        <div class="form-actions-proto">
            <a class="btn btn-cancel" ng-click="hideBatchRemoveTagModal()">Cancel</a>
            <a class="btn btn-submit btn-primary" ng-click="doBatchRemoveTagProjects()">Remove Tags</a>
        </div>
    </div>
</div>



    <div id="deleteSearchModal" class="fn_modal modal hide fade ng-scope">
        <div class="modal-header">
            <h3>Delete view</h3>
        </div>
        <div class="modal-body">
            <!-- class="saveSearch deleteSearch" -->
            <p>Are you sure you want to delete: <strong class="ng-binding"></strong>?</p>

            <p style="color:red;" class="ng-binding"></p>

            <p ng-show="usersWithMobileSearch > 0" class="ng-binding ng-hide">
                 user is currently configured to use this as their mobile view.
                If you delete it, they will revert to the default view on mobile.
            </p>

            <p>This can not be undone.</p>
        </div>
        <div class="modal-footer">
            <div class="form-actions-proto">
                <a class="btn btn-cancel" ng-click="hideDeleteSearch()">Cancel</a>
                <a class="btn btn-danger" ng-click="deleteSavedSearch()">Delete</a>
            </div>
        </div>
    </div>

<!-- delete project multi select version -->
    <div id="permDeleteProjectModal" class="fn_modal modal hide fade ng-scope">
        <div class="modal-header">
            <h3 class="ng-binding">Permanently Delete Work</h3>
        </div>
        <div class="modal-body">
            <p><strong class="ng-binding">Are you sure you want to permanently delete 0 items? </strong></p>
            <div class="container-warning ng-hide" ng-show="fn.currentSearchConfiguration.containerSearch">
                <h4>Caution!</h4>
                <p class="ng-binding">When deleting a Work, all Work (e.g., work orders, inpections) attached to it will also be deleted.</p>  
            </div>
            <p>This action will delete all: </p>
            <ul style="list-style-type: disc;">
                <li ng-show="fn.currentSearchConfiguration.containerSearch" class="ng-hide">projects</li>
                <li>data</li>
                <li>photos</li>
                <li>documents</li>
                <li>contained items</li>
            </ul>    
            <p><strong>This action cannot be undone.</strong></p>
        </div>
        <div class="modal-footer">
            <div class="form-actions-proto">
                <a class="btn btn-cancel" ng-click="hidePermDelProjectModal()">Cancel</a>
                <a class="btn btn-danger" ng-click="doPermDelete();hidePermDelProjectModal()">Permanently Delete</a>
            </div>
        </div>
    </div>



    <!-- delete project line item version -->
    <div id="permDeleteProjectModal2" class="fn_modal modal hide fade form-actions-proto ng-scope" role="dialog" data-backdrop="static" data-keyboard="false" aria-hidden="true" style="    margin-left: -225px;width: 450px;}">
         <div class="modal-header">
            <h3>Permanently Delete
            </h3>
        </div>
        <div class="modal-body">
            <p><strong class="ng-binding">Are you sure you want to permanently delete ""?</strong></p>
            <div class="container-warning ng-hide" ng-show="fn.currentSearchConfiguration.containerSearch">
                <h4>Caution!</h4>
                <p class="ng-binding">When deleting a Work, all Work (e.g., work orders, inpections) attached to it will also be deleted.</p>  
            </div>
            <p>This action will delete all: </p>
            <ul style="list-style-type: disc;">
                <li ng-show="fn.currentSearchConfiguration.containerSearch" class="ng-hide">projects</li>
                <li>data</li>
                <li>photos</li>
                <li>documents</li>
                <li>comments</li>
            </ul>    
            <p><strong>This action cannot be undone.</strong></p>
        </div>
        <div class="modal-footer">
            <div class="form-actions-proto">
                <button type="button" class="btn btn-cancel " ng-click="hidePermanentlyDeleteProperty()">Cancel</button>
                <button type="submit" class="btn btn-danger" ng-disabled="createUserForm.$invalid" ng-click="deleteProperty(deleteProject);hidePermanentlyDeleteProperty()">Delete
                </button>
            </div>
        </div>
    </div>



</div>
            <div id="spinner" class="spinner" style="display:none;">
                <img src="/images/spinner.gif" alt="Spinner">
            </div>

        <!-- <div ng-include src="'/angular-app/chat/chat-messages-modal.html'"></div> -->

    </div>   <!-- close wrap  -->


    
	
<div id="cb-container" style="position: fixed; inset: 0px; z-index: 2147483647; display: none; overflow-y: hidden;"><div id="cb-loader" style="z-index: 99999; visibility: hidden; transition: all 0.5s ease 0s; background: rgb(244, 245, 249); position: absolute; left: 0px; right: 0px; box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 9px 0px, rgba(0, 0, 0, 0.15) 0px 20px 30px 1px, rgba(0, 0, 0, 0.15) 0px 40px 40px 1px;"><div style="overflow: hidden;"><div id="cb-loader-header" style="padding: 12px 40px; background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 1px 2px 0px; text-align: center; min-height: 64px; box-sizing: border-box;"><div style="min-height: 46px; display: flex; align-items: center; margin-top: 1px;"><img id="cb-header-logo" style="max-height: 40px; max-width: 240px; vertical-align: middle; width: auto; margin: 3px auto;"></div></div><div id="cb-loading-bar" style="height: 2px; background: rgb(72, 231, 154); transition-duration: 0.5s; transition-timing-function: ease-in-out; visibility: hidden;"></div><div style="padding: 24px 36px;"><div class="cb-placeholder" id="cb-placeholder"><div class="wavering" style="height: 20px; width: 100px; background: linear-gradient(to right, rgb(238, 238, 238) 8%, rgb(221, 221, 221) 18%, rgb(238, 238, 238) 33%) 0% 0% / 800px 104px; margin-bottom: 10px;"></div><div class="wavering" style="height: 40px; width: 200px; background: linear-gradient(to right, rgb(238, 238, 238) 8%, rgb(221, 221, 221) 18%, rgb(238, 238, 238) 33%) 0% 0% / 800px 104px; margin-bottom: 10px;"></div><div class="wavering" style="height: 10px; width: 150px; background: linear-gradient(to right, rgb(238, 238, 238) 8%, rgb(221, 221, 221) 18%, rgb(238, 238, 238) 33%) 0% 0% / 800px 104px; margin-bottom: 10px;"></div><div class="wavering" style="height: 10px; width: 150px; background: linear-gradient(to right, rgb(238, 238, 238) 8%, rgb(221, 221, 221) 18%, rgb(238, 238, 238) 33%) 0% 0% / 800px 104px; margin-bottom: 10px;"></div><div class="wavering" style="height: 10px; width: 150px; background: linear-gradient(to right, rgb(238, 238, 238) 8%, rgb(221, 221, 221) 18%, rgb(238, 238, 238) 33%) 0% 0% / 800px 104px; margin-bottom: 10px;"></div></div><div id="cb-error" style="font-size: 18px; line-height: 27px; color: rgb(248, 48, 48); text-align: center; display: none;"></div></div><div id="cb-modal-close" style="position: absolute; background: rgb(57, 57, 65); height: 24px; width: 24px; border-radius: 50%; right: -12px; top: -12px; font-size: 20px; color: rgba(255, 255, 255, 0.7); text-align: center; cursor: pointer; display: table; font-weight: 400; line-height: 24px;">×</div></div></div><iframe id="cb-frame" style="width: 100%; height: 100%; z-index: 999999; visibility: hidden; position: relative; border: 0px;"></iframe><iframe id="cb-master-frame" name="cb-master-frame" src="https://js.chargebee.com/v2/master-48f2b70f17c08c4546e497459e423fb3.html#stage.fotonotes.com" style="margin: 0px; padding: 0px; border: none; overflow: hidden; display: block; min-width: 100%; width: 1px; height: 1.2em;"></iframe></div><script src="/js/stream/bundle.js" type="module"></script></body>


js?project=fotonotes.com:api-project-1056877032439&key=AIzaSyC6Z4MSnEm4-MMvKxB3AOi9FJT3e0Ugy9M

https://maps.googleapis.com/maps/api/js?project=fotonotes.com:api-project-1056877032439&key=AIzaSyC6Z4MSnEm4-MMvKxB3AOi9FJT3e0Ugy9M
# com.sitecapture.app.sitecapture.dev:id/floating_add_button
# com.sitecapture.app.sitecapture.dev:id/status_name

# com.sitecapture.app.sitecapture.dev:id/status_name

driver.quit()