import  sys, os, time, signal, random, json, websocket, ssl, socket, ctypes
import  multiprocessing as mp
import  multiprocessing.managers as mpm
import  multiprocessing.connection as mpc
import  cdp
from    websocket import ABNF
from    ChromeLauncher import ChromeLauncher
from    util import *
from    colorama import Fore, Back, Style, init as colorama_init
from    ChromeClient import *

class Foo:
    ...
    
class ChromeClientApp():

    def __init__( self, Config = None ):

        signal.signal( signal.SIGINT,   self.OSSignalHandler )
        signal.signal( signal.SIGBREAK, self.OSSignalHandler )
        signal.signal( signal.SIGABRT,  self.OSSignalHandler )

        self.CDPClient = ChromeClient()


    def AddJavaScriptInjection( self ):
        
        ScriptFile = '.\JavaScriptInjections.js'
        ScriptText = None
        
        with open(ScriptFile, 'r', newline='', encoding='utf-8') as InputFile:
            ScriptText = ''.join(InputFile.readlines())

        if not ScriptText:
            print('Failed to load: ', ScriptFile)
            os.exit(0)
        
        ReturnValue = self.CDPClient.ExecuteMethod( 
                        cdp.page.add_script_to_evaluate_on_new_document,
                        source = ScriptText, 
                        world_name = None, 
                        include_command_line_api = True)
                        
        ReturnValue.Print()

        
    def InitializeCDP( self ):
        
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.log.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.page.enable ) 
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.page.set_lifecycle_events_enabled, enabled = True )
        
        JavaScriptObject.GetGlobalThisObjectID( self.CDPClient )
        JavaScriptObject.GetWindowObjectID( self.CDPClient )
        self.AddJavaScriptInjection()
        
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.dom.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.dom_snapshot.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.dom_storage.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.debugger.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.runtime.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.css.enable )
        # ReturnValue = self.CDPClient.ExecuteMethod( cdp.network.enable )
        # ReturnValue = self.CDPClient.ExecuteMethod( cdp.fetch.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.accessibility.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.audits.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.inspector.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.overlay.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.profiler.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.performance.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.service_worker.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.layer_tree.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.media.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.console.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.database.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.animation.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.indexed_db.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.heap_profiler.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.security.enable )
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.web_authn.enable )

        ReturnValue = self.CDPClient.ExecuteMethod( cdp.dom.get_document,
                                                 depth = -1, pierce = True )
                              
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.dom.request_child_nodes,
                                                 node_id = cdp.dom.NodeId( 0) , 
                                                 depth = -1, pierce = True )
        
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.browser.get_version )
        ReturnValue.Print()

        ... # done initializing
        
    def Test( self ):
    
        #URL = 'https://localhost:8834/#/'
        URL = 'file:///C:/python/sam/html/main.html'
        ReturnValue = self.CDPClient.ExecuteMethod( cdp.page.navigate, url = URL )
        #ReturnValue.Print()
        
        JavaScriptObject.GetGlobalThisObjectID( self.CDPClient )
        JavaScriptObject.GetWindowObjectID( self.CDPClient )
        self.AddJavaScriptInjection()
        
        time.sleep(5)
        
        Pause()
        
        #time.sleep(30)
        
        
        #print("Waiting for PageReadyEvent")
        #self.CDPClient.PageReadyEvent.wait()
        #self.CDPClient.PageReadyEvent.clear()
        #print("Got PageReadyEvent!")
        
        
        #ReturnValue = self.CDPClient.ExecuteMethod( cdp.dom.get_document,
        #                                        depth = -1, pierce = True )
                                            
        #ReturnValue.Print()
        
        
        # new mouseevent object __proto__ = MouseEvent
        # MouseEvent class __proto__ = UIEvent () function
        
                    
                    #"new MouseEvent('click') instanceof Event; " )
                    
                    #"Object.setPrototypeOf(MyEvent, UIEvent); " +
                    #"Object.setPrototypeOf(MyEvent.__proto__, Event); " +
                    #"Object.setPrototypeOf(MyEvent.prototype, MouseEvent ); " +
                    #"Object.setPrototypeOf(MyEvent.prototype.__proto__, MouseEvent.prototype.__proto__); " +
                    #"MyEvent.constructor = MouseEvent.constructor; " +
                    #"MyEvent.prototype.constructor = MouseEvent.prototype.constructor; " +
                    #"MyEvent.__proto__.constructor = MouseEvent.prototype.__proto__.constructor; " +
                    #"new MyEvent.__proto__.constructor('click');" )
    
        # MouseEvent == internapProps = UIEvent, MouseEvent() Function class name, prototype is MouseEvent
        # MouseEvent.prototype == No IsTrusted, internalProps = UIEvent, main className = MouseEvent object, constructor = MouseEvent()
        # MouseEvent.__proto__ =  No IsTrusted  internalProps = Event, not UIEVent, main class is Function UIEvent(), prototype var is UIEvent, constructor some generic Function
        # instance.prototype == undefined
        # instance.__proto__ == internalProps = UIEvent, main class is MouseEvent, constructor is MouseEvent(), 
        # instance == internapProps = MouseEvent object, main class is MouseEvent, constructor is MouseEvent()
        # js/event_tracker.js
        # extensions.mojom.EventDispatcher extensions.mojom.EventRouter mojom.ModuleEventSink
        # events_view.js
        # user_events.js
        #  this.trustEvent_(e)  e.isTrustedForTesting
        # events.getRules events.Event.getRules
        #Script = "window.Mojo;"
        #Script = "let blob_registry_ptr = new blink.mojom.BlobRegistryPtr();"
        #Script = "Matrix = new window.DOMMatrix(); Matrix;"
        #Script = "window.Handlebars.VM;"
        #Script = "window.Handlebars.helpers;"
        #Script = "window._License;"
        #Script = 'window._License.setPurchaseProSucceeded(1);'
        #Script = 'window._License.setRefreshLicenseResult(1);'
        #Script = "window._License.showUpgradeModal();"
        #Script = "ABC = new window.webkitRTCPeerConnection();"
        #Script = "window._Iron;" 
        #Script = "window._Iron.core;" 
        #Script = "window.Director(_);" 
        #Script = "MojoInterface = new window.MojoInterfaceInterceptor(1); MojoInterface.start();"
        #Script = "window.navigator.permissions.USBConfiguration; "
#<script src="/gen/layout_test_data/mojo/public/js/mojo_bindings.js"></script>
#<script src="/gen/mojo/public/mojom/base/string16.mojom.js"></script>
#<script src="/gen/mojo/public/mojom/base/time.mojom.js"></script>
#<script src="/gen/third_party/blink/public/platform/modules/idle/idle_manager.mojom.js"></script>        
        # Script = "chrome;"
        # PerfettoUIExtension ID:  lfmkphfpdbjijhpomgecfikhfohaoine
        
        # internals.runtimeFlags
        
        '''
        ReturnByValue = False
        GenerateWebDriverValue = False
        
        
        ReturnValue = self.CDPClient.ExecuteScript( 
                            Script, 
                            ReturnByValue = False,
                            GenerateWebDriverValue = GenerateWebDriverValue )
        
        ReturnValue.Print(FileName = "out3.txt")
        
        ObjectID    = None
        ClassName   = None
        Result      = None
        
        if Result := ReturnValue.Result.get('result'):
            print(type(Result))
            if isinstance(Result, dict):
                ObjectID = Result.get('objectId')
                ClassName = Result.get('className')
                print()
                print(ClassName, ObjectID)
                print()
        '''
        
  
                    
            
                
        '''
        ObjectID = None
        if ReturnValue.Result:
            if Result := ReturnValue.Result.get('internalProperties'):
                if isinstance(Result, list):
                    for Item in Result:
                        if 'PromiseResult' in Item.get('name'):
                            ObjectID = Item.get('value').get('objectId')
                            break
        
        if ObjectID:
       
            ReturnValue = self.GetProperties(ObjectID)
            ReturnValue.Print( FileName = "out3.txt" )
        '''    
        
        '''
        Script = ( "class MyEvent { " +
                 " static get [Symbol.species]() { " +
                 " return MouseEvent; }};  " +
                 " Object.setPrototypeOf( MyEvent, MouseEvent ); " +
                 " Object.setPrototypeOf( MyEvent.prototype, MouseEvent.prototype); " +
                 " MyEvent.__proto__ = MouseEvent; " +
                 " MyEvent.prototype = MouseEvent; " +
                 " MyEvent.prototype.__proto__ = MouseEvent; " +
                 " ABC = new MouseEvent('click'); JSON.stringify(ABC);" )
        '''
        # Script = ( "dispatchEvent(new MouseEvent('click'));")
        
        
        # Script = ( "KeyStr = Object.keys(window).join(','); Hash = KeyStr.split(',').map(v=>v.charCodeAt(0)).reduce((a,v)=>a+((a<<7)+(a<<3))^v).toString(16); Hash;" )
        
        # Script = "new MyTestClass1();"
        
        

        #Script = "TestDictionaryHashing();"
        '''
        Script = "TestMap();"
        ReturnValue = self.CDPClient.ExecuteScript( 
                        expression = Script, 
                        return_by_value = False )
    
        ReturnValue.Print()
        Props = self.GetProperties(ReturnValue)
        print(json.dumps(Props, indent=2))
        Entries = { 'result' : Props
                                .get('result')
                                .get('properties')
                                .get('[[Entries]]')
                                .get('value') }
                                
        print(json.dumps(Entries, indent=2))
        Pause()
        EntriesProps = self.GetProperties(Entries)
        print(json.dumps(EntriesProps, indent=2))
        Pause()
        '''
        
        
        #Script = "globalThis.TestArray;"
        
        #ReturnValue = self.CDPClient.ExecuteScript( 
        #                expression = Script, 
        #                return_by_value = False )
    
        #ReturnValue.Print()
        
        #TestObject = JavaScriptObject.CreateFromReturnValue( 
        #             ReturnValue, self.CDPClient)


        #TestObject.GetArrayObjects( self.CDPClient )                     
        #TestObject.GetPropertyObjects( self.CDPClient )
        
        
        #TestObject.Print()
        
        #for PropertyObject in PropertyObjects:
            #print(PropertyObjects[PropertyObject])
        #    SubPropertyObjects = PropertyObjects[PropertyObject].GetPropertyObjects( self.CDPClient )
            
            
        #print( json.dumps(TestObject, indent = 2, default = JavaScriptObjectSerializer ))
        
        #print( str( TestObject.__dict__))
        #print()
        #Pause()
  
        #Props = self.GetProperties(ReturnValue)
        #print(json.dumps(Props, indent=2))
        
        #os._exit(1)
        #ReturnValue = self.GetProperties( ReturnValue )
        #ReturnValue.Print()
        #Pause()

        # my_string.split(',').map(v=>v.charCodeAt(0)).reduce((a,v)=>a+((a<<7)+(a<<3))^v).toString(16);
        

        #self.GetProtoTypeInstances( Evaluation = "Object(Symbol.prototype);" )
        #self.GetProtoTypeInstances( Evaluation = "Object.create(null);" )
        
        Script = "debugger"
        
        ReturnValue = self.CDPClient.ExecuteScript( 
                        expression = Script, 
                        return_by_value = False )
    
        ReturnValue.Print()
        
        #ReturnValue = self.CDPClient.ExecuteMethod( cdp.dom.get_document,
        #                                            depth = -1, pierce = True)        
        
        #ReturnValue.Print()
        
        TestObject = JavaScriptObject.CreateFromReturnValue( 
                     ReturnValue, self.CDPClient)        
        
        TestObject.Print( Verbose = True )
        TestObject.PropertyObjects = TestObject.GetPropertyObjects()
        TestObject.ArrayObjects = TestObject.GetArrayObjects()
        TestObject.Print( Verbose = True )
        
        print(TestObject.ObjectID)
        
        #ReturnObject = self.CallCreateEvent( TestObject.ObjectID )
        
        #print("Call Create Event Return Object:")
        
        #ReturnObject.Print()
        
        Pause()
        return
        
        #self.GetProtoTypeInstances( Evaluation = "Object.prototype" )
        #self.GetProtoTypeInstances( Evaluation = "Navigator" )
        
        #self.RecurseAllObjects(  TestObject )
        
        #ReturnList = self.CallGetGlobalTestMap()
        
        #if ReturnList:
        #    self.GetProtoTypeInstances( NextInstance = ReturnList )
        
        '''
        if ReturnList and ReturnList.IsArrayObject():
            if ReturnList.ArrayObjects:
                print("Length = ", ReturnList.GetArrayObjectLength())
                for ArrayObject in ReturnList.ArrayObjects:
                
                        ArrayObject.PropertyObjects = ArrayObject.GetPropertyObjects()
                        ArrayObject.ArrayObjects = ArrayObject.GetArrayObjects()
                        ArrayObject.Print( Verbose = False, FileName="final.txt" )
        '''                

    def CallAddToGlobalTestMap( self, MyObject ):

        FunctionImpl    = "globalThis.AddToGlobalTestMap"
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          JavaScriptObject.GlobalThisObjectID )
        Argument1       = cdp.runtime.CallArgument(
                          object_id = cdp.runtime.RemoteObjectId( 
                          MyObject.ObjectID ))
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                          function_declaration = FunctionImpl,
                          object_id = TargetObject,
                          arguments = [ Argument1 ],
                          return_by_value = False )
            
        ReturnObject    = JavaScriptObject.CreateFromReturnValue(
                          ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to create ReturnObject')
            Pause()
            return None
            
        return( ReturnObject.Value )



    def CallCreateEvent( self, DocumentObjectID ):

        print("CALL CREATE EVENT")
        print(DocumentObjectID)
        
        FunctionImpl    = "function () { this.Permissions(); }"
        
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          DocumentObjectID )
        
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                            function_declaration = FunctionImpl,
                            object_id = TargetObject,
                            return_by_value = True )
        
        # ReturnValue.Print()
        
        ReturnObject    = JavaScriptObject.CreateFromReturnValue(
                          ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to create ReturnObject')
            Pause()
            return None
        
        #ReturnObject.Print()
        
        return( ReturnObject )
        
    def CallGlobalTestMapHas( self, MyObject ):

        FunctionImpl    = "globalThis.GlobalTestMapHas"
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          JavaScriptObject.GlobalThisObjectID )
        Argument1       = cdp.runtime.CallArgument(
                          object_id = cdp.runtime.RemoteObjectId( 
                          MyObject.ObjectID ))
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                          function_declaration = FunctionImpl,
                          object_id = TargetObject,
                          arguments = [ Argument1 ],
                          return_by_value = False )
        
        ReturnObject    = JavaScriptObject.CreateFromReturnValue(
                          ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to create ReturnObject')
            Pause()
            return None
            
        return( ReturnObject.Value )

    
    def CallGetGlobalTestMap( self ):

        FunctionImpl    = "globalThis.GetGlobalTestMap"
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          JavaScriptObject.GlobalThisObjectID )
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                          function_declaration = FunctionImpl,
                          object_id = TargetObject,
                          return_by_value = False )
        ReturnObject    = JavaScriptObject.CreateFromReturnValue(
                          ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to create ReturnObject')
            Pause()
            return None
            
        return( ReturnObject )    
        
    
    def RecurseAllObjects( self, MyJavaScriptObject, Level = None, Label=None ):
    
        if Level == None:
            Level = 0
            
        if Label == None:
            Label = ''
            
        Indent = ( '     ' * Level )
        
        if not MyJavaScriptObject.ObjectID:
            return
        
        if MyJavaScriptObject.IsArrayObject():
            if not MyJavaScriptObject.GetArrayObjectLength():
                return
        else:
        
            #ObjectProperties = MyJavaScriptObject.GetPropertyObjects()
            #if ObjectProperties:
                #UniqueID = ObjectProperties.get('__UniqueID__')
                #if UniqueID and ( UniqueID.Value != None ):
                    #print("SEEN BEFORE: " + str(UniqueID.Value), Decorate=False, FileName="seen.txt")
                    #MyJavaScriptObject.Print( Verbose = False, FileName="seen.txt")
                    
        
            if self.CallGlobalTestMapHas( MyJavaScriptObject ):
                return
                
            if not self.CallAddToGlobalTestMap( MyJavaScriptObject ):
                print("Failed to add MyJavaScriptObject to GlobalTestMap", Decorate=False)
                MyJavaScriptObject.Print( Verbose = False )
                #Pause()
                return
                

            print( Label, Decorate = False, end = '', FileName="seen.txt" )
            MyJavaScriptObject.PropertyObjects = MyJavaScriptObject.GetPropertyObjects()
            MyJavaScriptObject.Print( Verbose = False, FileName="seen.txt" )   
                
        if MyJavaScriptObject.IsArrayObject():
            
            if not MyJavaScriptObject.ArrayObjects:
                MyJavaScriptObject.ArrayObjects = MyJavaScriptObject.GetArrayObjects()
        
            if MyJavaScriptObject.ArrayObjects:
            
                for Idx, ArrayObject in enumerate( MyJavaScriptObject.ArrayObjects ):
                                        
                    if not ArrayObject.ObjectID:
                        continue
                        
                    if (( MyJavaScriptObject.Name == '[[Scope]]' ) or 
                        ( 'Scope' in MyJavaScriptObject.Description )):
                       continue
                    
                    self.RecurseAllObjects( ArrayObject, Level = (Level + 1), Label = f"A-{Idx}: " )
                    
                return

                        
        if not MyJavaScriptObject.PropertyObjects:
            MyJavaScriptObject.PropertyObjects = MyJavaScriptObject.GetPropertyObjects()
        
        if MyJavaScriptObject.PropertyObjects:
        
            for Idx, (PropertyName, PropertyObject) in enumerate(
                                                       list( MyJavaScriptObject.PropertyObjects.items() )):

                if not PropertyObject.ObjectID:
                    continue
                                                       
                self.RecurseAllObjects( PropertyObject, Level = (Level + 1), Label = f"P-{Idx}: " )
            
            return

        return


    def GetProtoTypeInstances( self, Evaluation = None, NextInstance = None ):
        
        ReturnValue         = None
        EvalObject          = None
        ProtoTypeList       = []
        
        
        print("************* START ****************" )
        
        if Evaluation != None:
        
            ReturnValue =   self.CDPClient.ExecuteScript( 
                            expression = Evaluation,
                            return_by_value = False )

            ReturnValue.Print()
            #if ( not ReturnValue ) or ( ReturnValue.Error ):
            #    print( 'Failed to execute Evaluation' )
            #    Pause()
            #    return None
            
            EvalObject = JavaScriptObject.CreateFromReturnValue( 
                         ReturnValue, self.CDPClient )
            
            if not EvalObject:
                print('Failed to create EvalObject')
                Pause()
                return None        

            #if (( 'prototype' in Evaluation )   or 
            #    ( '__proto__' in Evaluation )):
            #        ProtoTypeList.append( EvalObject )
        
        else:

            if ( NextInstance != None ):
                #print("Setting EvalObject to NextInstance")
                EvalObject = NextInstance
        
        
        if EvalObject.Type == 'symbol':
            print( 'ObjectType cannot be symbol' )
            Pause()
            return None
        
        
        Exclusions = [  'GlobalSeenData', 'CallProtoProperty', 'CallGetProtoTypeOf',
                        'GetGlobalSeenData', 'IsSeenProtoType', 'AddSeenProtoType',
                        'IsSeenInstance', 'AddSeenInstance', 'GlobalEventListener',
                        'AddListenerToAllEvents', 'EventTypesAdded', 'TestObject',
                        'TestClass', 'GetObjectInfo' ]
        
        for Exclusion in Exclusions:
            if (( EvalObject.Description ) and 
                ( Exclusion in EvalObject.Description )):
                    return

        if EvalObject.ObjectID:
            if not EvalObject.IsArrayObject():
                # ProtoTypeList.append( EvalObject )
                ProtoTypeOfObject = self.CallGetProtoTypeOf( EvalObject )
                if ProtoTypeOfObject:
                    ProtoTypeList.append( ProtoTypeOfObject )
        
        if EvalObject.ArrayObjects:
            for ArrayObject in EvalObject.ArrayObjects:
                if ArrayObject.ObjectID:
                    #ArrayObject.Print()
                    ProtoTypeOfObject = self.CallGetProtoTypeOf( ArrayObject )
                    if ProtoTypeOfObject:                    
                        ProtoTypeList.append( ProtoTypeOfObject )
    
        elif EvalObject.PropertyObjects:
            for PropertyName, PropertyObject in EvalObject.PropertyObjects.items():
                if PropertyObject.ObjectID:
                    ProtoTypeOfObject = self.CallGetProtoTypeOf( PropertyObject )
                    if ProtoTypeOfObject:
                        ProtoTypeList.append( ProtoTypeOfObject )
        
        print("Total ProtoTypes Before Calling QueryObjects: ", len(ProtoTypeList))
        
        RecurseList = []
        InstanceMap = {}
        
        for ProtoIdx, ProtoTypeObject in enumerate(ProtoTypeList):
        
            for Exclusion in Exclusions:
                if (( ProtoTypeObject.Description ) and 
                    ( Exclusion in ProtoTypeObject.Description )):
                        #print(  ProtoIdx, ": Skipping ProtoType because Exclusion: ", 
                        #        ProtoTypeObject.Name, ProtoTypeObject.ClassName, 
                        #        ProtoTypeObject.Type, ProtoTypeObject.ObjectID )                    
                        continue
                    
            if ProtoTypeObject.ObjectID == None:
                #print( ProtoIdx, ": Skipping ProtoType because No ObjectID: ", 
                #        ProtoTypeObject.Name, ProtoTypeObject.ClassName, 
                #        ProtoTypeObject.Type, ProtoTypeObject.ObjectID )                    
                continue
            
            if self.IsSeenProtoType( ProtoTypeObject.ObjectID ):
                #print( ProtoIdx, ": Skipping ProtoType because IsSeenProtoType: ", 
                #        ProtoTypeObject.Name, ProtoTypeObject.ClassName, 
                #        ProtoTypeObject.Type, ProtoTypeObject.ObjectID )
                continue
                
            if not self.AddToSeenProtoTypeMap( ProtoTypeObject.ObjectID ):
                print( ProtoIdx, ": Failed to AddToSeenProtoTypeMap")
                
            print( ProtoIdx, ": Calling QueryObjects for ProtoType: ", 
                    ProtoTypeObject.Name, ProtoTypeObject.ClassName, 
                    ProtoTypeObject.Type, ProtoTypeObject.ObjectID )
            
            ReturnValue =   self.CDPClient.ExecuteMethod(  
                                cdp.runtime.query_objects,
                                object_group = "mygroup",
                                prototype_object_id = 
                                cdp.runtime.RemoteObjectId(
                                ProtoTypeObject.ObjectID ))
            
            InstanceArrayObject = JavaScriptObject.CreateFromReturnValue( 
                                   ReturnValue, self.CDPClient )            
        
            if not InstanceArrayObject:
                ReturnValue.Print()
                print('Failed to create InstanceArrayObject')
                Pause()
                continue
        
            if not InstanceArrayObject.IsArrayObject():
                InstanceArrayObject.Print()
                print('InstanceArrayObject from QueryObjects is not an array')
                Pause()
                continue
                
            InstanceArrayLength = InstanceArrayObject.GetArrayObjectLength()
            
            if not InstanceArrayLength:
                print( ProtoIdx, ": No Instances Returned for ProtoType: ", 
                        ProtoTypeObject.Name, ProtoTypeObject.ClassName, 
                        ProtoTypeObject.Type, ProtoTypeObject.ObjectID )
                continue

            print(ProtoIdx, ": QueryObjects returned ", InstanceArrayLength, " instances")
            
            InstanceMap[ProtoTypeObject] = InstanceArrayObject.ArrayObjects
            
            
        for ProtoTypeOfInstance, InstanceObjectList in InstanceMap.items():
   
            InstanceObjectLength = len(InstanceObjectList)
            
            for Idx, InstanceObject in enumerate(InstanceObjectList):
            
                for Exclusion in Exclusions:
                    if (( InstanceObject.Description ) and 
                        ( Exclusion in InstanceObject.Description )):
                            print("Instance is Excluded, skipping")
                            continue
            
                print()
                print( "Checking Instance Idx #", Idx, " of ", InstanceObjectLength)
                print( "Proto: ", Decorate=False, end='')
                ProtoTypeOfInstance.Print( Verbose = False )
                print( "Inst: ", Decorate=False, end='')
                InstanceObject.Print( Verbose = False )
                        
                    
                if self.IsSeenInstance( ProtoTypeOfInstance.ObjectID,
                                        InstanceObject.ObjectID ):
                                        
                    print("ProtoType-Instance pair is seen already, skipping")
                    continue
            
                if not self.AddToSeenInstanceSet( 
                            ProtoTypeOfInstance.ObjectID,
                            InstanceObject.ObjectID ):
                
                    print('Failed to add to SeenInstanceSet: ')
                    continue

                RecurseList.append( InstanceObject )
                    
        
        RecurseListLength = len(RecurseList)
        # print("Length of RecurseList: " + str(RecurseListLength) )
        #Pause()
        
        for Idx, InstanceObject in enumerate(RecurseList):
        
            if InstanceObject.IsArrayObject():
                ArrayLength = InstanceObject.GetArrayObjectLength()
                if not ArrayLength:
                    #InstanceObject.Print()
                    #print("Length = ", ArrayLength)
                    #Pause('NOT Recursing into empty array')
                    continue
                else:
                    print('Recursing into array of length: ', ArrayLength)
            
            if (( InstanceObject.Name == '[[Scopes]]' ) or
                ( 'Scopes' in str(InstanceObject.Description) )):
                    print('NOT Recursing into [[Scopes]]')
                    #Pause()
                    continue
                
            if not InstanceObject.PropertyObjects:
                InstanceObject.PropertyObjects = InstanceObject.GetPropertyObjects()
            
            if not InstanceObject.ArrayObjects:
                InstanceObject.ArrayObjects = InstanceObject.GetArrayObjects()
            
            print(  "Recursing Instance Idx #", Idx, " of ", RecurseListLength, "(",
                    InstanceObject.Name, InstanceObject.Type, 
                    InstanceObject.ClassName, InstanceObject.Description, 
                    InstanceObject.ObjectID, ")")
            
            self.GetProtoTypeInstances( NextInstance = InstanceObject )
            print(  "Popped out of recursion" )
    
    
    def CallGetProtoTypeOf( self, MyObject ):

        FunctionImpl    = "globalThis.CallGetProtoTypeOf"
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          JavaScriptObject.GlobalThisObjectID )
        Argument1       = cdp.runtime.CallArgument(
                          object_id = cdp.runtime.RemoteObjectId( 
                          MyObject.ObjectID ))
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                          function_declaration = FunctionImpl,
                          object_id = TargetObject,
                          arguments = [ Argument1 ],
                          return_by_value = False )
            
        ProtoTypeObject = JavaScriptObject.CreateFromReturnValue(
                          ReturnValue, self.CDPClient )

        if not ProtoTypeObject:
            print('Failed to get ProtoTypeObject')
            Pause()
            return None
            
        return( ProtoTypeObject )

    def CallGetObjectInfo( self, MyObject ):

        FunctionImpl    = "globalThis.GetObjectInfo"
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          JavaScriptObject.GlobalThisObjectID )
        Argument1       = cdp.runtime.CallArgument(
                          object_id = cdp.runtime.RemoteObjectId( 
                          MyObject.ObjectID ))
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                          function_declaration = FunctionImpl,
                          object_id = TargetObject,
                          arguments = [ Argument1 ],
                          return_by_value = False )
        
        if not ReturnValue or not ReturnValue.Result:
            return None
            
        ReturnValue.Print()
        
        ReturnObject = JavaScriptObject.CreateFromReturnValue(
                          ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to get ReturnObject')
            Pause()
            return None
            
        return( ReturnObject )


    def CallProtoProperty( self, ObjectID ):

        FunctionImpl    = "globalThis.CallProtoProperty"
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          JavaScriptObject.GlobalThisObjectID )
        Argument1       = cdp.runtime.CallArgument(
                          object_id = cdp.runtime.RemoteObjectId( 
                          ObjectID ))
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                          function_declaration = FunctionImpl,
                          object_id = TargetObject,
                          arguments = [ Argument1 ],
                          return_by_value = False )
        
        ProtoTypeObject = JavaScriptObject.CreateFromReturnValue(
                          ReturnValue, self.CDPClient )

        if not ProtoTypeObject:
            print('Failed to get ProtoTypeObject')
            Pause()
            return None
            
        return( ProtoTypeObject )
        
    
    def AddToSeenInstanceSet( self, ProtoTypeObjectID, InstanceObjectID ):
    
        FunctionImpl = "globalThis.AddSeenInstance"
        Argument1    = cdp.runtime.CallArgument(
                       object_id = cdp.runtime.RemoteObjectId( 
                       ProtoTypeObjectID ))
        Argument2    = cdp.runtime.CallArgument(
                       object_id = cdp.runtime.RemoteObjectId( 
                       InstanceObjectID )) 
        TargetObject = cdp.runtime.RemoteObjectId( 
                       JavaScriptObject.GlobalThisObjectID )
        ReturnValue  = self.CDPClient.ExecuteFunctionOn(
                       function_declaration = FunctionImpl,
                       object_id            = TargetObject,
                       arguments            = [ Argument1, Argument2 ],
                       return_by_value      = False )

            
        ReturnObject = JavaScriptObject.CreateFromReturnValue(
                       ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to get ReturnObject')
            Pause()
            return None
        
        return( ReturnObject.Value )
        
                    
    def AddToSeenProtoTypeMap( self, ProtoTypeObjectID ):
        
        FunctionImpl    = "globalThis.AddSeenProtoType"                
        TargetObject    = cdp.runtime.RemoteObjectId( 
                          JavaScriptObject.GlobalThisObjectID )
        Argument1       = cdp.runtime.CallArgument(
                          object_id = cdp.runtime.RemoteObjectId( 
                          ProtoTypeObjectID ))
        ReturnValue     = self.CDPClient.ExecuteFunctionOn(
                          function_declaration = FunctionImpl,
                          object_id = TargetObject,
                          arguments = [ Argument1 ],
                          return_by_value = False )
    
            
        ReturnObject = JavaScriptObject.CreateFromReturnValue(
                       ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to get ReturnObject')
            Pause()
            return None
            
        return( ReturnObject.Value )
        
        
    def IsSeenProtoType( self, ProtoTypeObjectID ):
    
        FunctionImpl        =   "globalThis.IsSeenProtoType"
        Argument1           =   cdp.runtime.CallArgument(
                                object_id = cdp.runtime.RemoteObjectId( 
                                ProtoTypeObjectID ))
        TargetObject        =   cdp.runtime.RemoteObjectId( 
                                JavaScriptObject.GlobalThisObjectID )
        ReturnValue         =   self.CDPClient.ExecuteFunctionOn(
                                function_declaration = FunctionImpl,
                                object_id = TargetObject,
                                arguments = [ Argument1 ],
                                return_by_value = False )
        
        ReturnObject = JavaScriptObject.CreateFromReturnValue(
                       ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to get ReturnObject')
            Pause()
            return None
            
        return( ReturnObject.Value )
        
    def IsSeenInstance( self, ProtoTypeObjectID, InstanceObjectID ):
    
        FunctionImpl = "globalThis.IsSeenInstance"
        Argument1    = cdp.runtime.CallArgument(
                       object_id = cdp.runtime.RemoteObjectId( 
                       ProtoTypeObjectID ))
        Argument2    = cdp.runtime.CallArgument(
                       object_id = cdp.runtime.RemoteObjectId( 
                       InstanceObjectID )) 
        TargetObject = cdp.runtime.RemoteObjectId( 
                       JavaScriptObject.GlobalThisObjectID )
        ReturnValue  = self.CDPClient.ExecuteFunctionOn(
                       function_declaration = FunctionImpl,
                       object_id            = TargetObject,
                       arguments            = [ Argument1, Argument2 ],
                       return_by_value      = False )
            
        ReturnObject = JavaScriptObject.CreateFromReturnValue(
                       ReturnValue, self.CDPClient )

        if not ReturnObject:
            print('Failed to get ReturnObject')
            Pause()
            return None
            
        return( ReturnObject.Value )
        
        
    def CallJSONStringify( self, ObjectID ):
    
        FunctionImpl = "globalThis.CallJSONStringify"
        Argument1    = cdp.runtime.CallArgument(
                       object_id = cdp.runtime.RemoteObjectId( 
                       ObjectID ))
        TargetObject = cdp.runtime.RemoteObjectId( 
                       JavaScriptObject.GlobalThisObjectID )
        ReturnValue  = self.CDPClient.ExecuteFunctionOn(
                       function_declaration = FunctionImpl,
                       object_id            = TargetObject,
                       arguments            = [ Argument1 ],
                       return_by_value      = True )

        #ReturnValue.Print()
        if not ReturnValue:
            return None
            
        ReturnObject = JavaScriptObject.CreateFromReturnValue(
                       ReturnValue, self.CDPClient )

        #ReturnObject.Print()
        
        if not ReturnObject:
            print('Failed to get ReturnObject')
            Pause()
            return None
            
        return( ReturnObject.Value )
        
        
    def DumpGlobalSeenData( self ):
    
        FunctionImpl = 'globalThis.GetGlobalSeenData'
        TargetObject = cdp.runtime.RemoteObjectId( 
                       JavaScriptObject.GlobalThisObjectID )
        ReturnValue  = self.CDPClient.ExecuteFunctionOn(
                       function_declaration = FunctionImpl,
                       object_id = TargetObject,
                       arguments = None,
                       return_by_value = False )
        
        DataObjects =   JavaScriptObject.CreateFromReturnValue( 
                         ReturnValue, self.CDPClient )
        
        print("DataObjects Length: ", len(DataObjects.ArrayObjects))
        
        for ProtoIdx, DataObject in enumerate( DataObjects.ArrayObjects ):
        
            DataObject.PropertyObjects = DataObject.GetPropertyObjects()
            DataObject.ArrayObjects    = DataObject.GetArrayObjects()
            
            ProtoTypeObject = DataObject.PropertyObjects.get('ProtoTypeObject')
            
            ProtoTypeObject.PropertyObjects = ProtoTypeObject.GetPropertyObjects()
            ProtoTypeObject.ArrayObjects    = ProtoTypeObject.GetArrayObjects()
            
            print( '\n', Decorate = False, FileName = "dump.txt" )
            
            ProtoTypeObject.Print( Verbose = False, FileName = "dump.txt" )
                
            InstanceObjects = DataObject.PropertyObjects.get('InstanceObjects')
            
            InstanceObjects.PropertyObjects = InstanceObjects.GetPropertyObjects()
            InstanceObjects.ArrayObjects    = InstanceObjects.GetArrayObjects()
            
            for InstanceIdx, InstanceObject in enumerate(InstanceObjects.ArrayObjects):
                
                InstanceObject.PropertyObjects  = InstanceObject.GetPropertyObjects()
                InstanceObject.ArrayObjects     = InstanceObject.GetArrayObjects()
                
                Indent = '     '
                print( Indent, Decorate = False, FileName = "dump.txt", end='')
                InstanceObject.Print( Verbose = False, FileName = "dump.txt" )  
                
                
        
    def OSSignalHandler( self, Signal, Frame ):
        try:
            print( f'Caught Signal: ' +
                   f'{signal.strsignal(Signal)}' )
                
            os._exit(1)
            
        except SystemExit:
            print('SystemExit')
        except InterruptedError:
            print('InterruptedError')        
        except BaseException as Failure:
            print( GetExceptionInfo(Failure) )
        finally:
            ... #self.CDPClient.CloseChrome()


def main():
        
    try:

        ClientApp = ChromeClientApp()
        
        #ClientApp.CDPClient.StartEventProcessor( PrintToScreen = False )
        
        ClientApp.InitializeCDP()
        
        ClientApp.Test()
        # ClientApp.DumpGlobalSeenData()
        
        #ClientApp.CDPClient.StopEventProcessor()
            
        #if ClientApp.CDPClient.ChromeProcess:
        #    ClientApp.CDPClient.CloseChrome()
            
        #ClientApp.CDPClient.StopMessageReader()            
            
    except BaseException as Failure:
        print( GetExceptionInfo( Failure ) )
    finally:
        ClientApp.CDPClient.CloseChrome()
                
    
    while True:
        print("Looping")
        time.sleep(1)
        
    
if __name__ == '__main__':
    mp.freeze_support()
    colorama_init( autoreset = False )
    main()
    
