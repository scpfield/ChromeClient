import sys, io, json, random, time, requests
from Util import *
from WebDrivers import *
from Sessions import *


def Main():

    
    Driver = AndroidDriver()
    
    Driver.PrintStatus()
    
    if (SessionId := Driver.Session.New()) != False:
        
        print(f'SessionId = {SessionId}')
        
        print(json.dumps(Driver.Session.Capabilities, indent=1))
        
        URL = 'http://www.google.com'
        
        Driver.Session.NavigateTo( URL )
        
        
    quit()
    
    
    '''
    Driver = ChromeDriver()
    
    if (SessionId := Driver.Session.New()) != False:
        
        print(f'SessionId = {SessionId}')
        
        URL = 'http://www.google.com'
        
        Driver.Session.NavigateTo( URL )
        print(f'Current URL = {Driver.Session.GetCurrentURL()}')
        
    
    time.sleep(5)
    Driver.Session.Delete()
    '''

if __name__ == '__main__':
    Main()
    