import sys, io, csv, re, random

Markets = ['Dayton', 'Cincinnati', 'Columbus', 'Indianapolis', 'Jacksonville', '']
#Markets = ['']

AllCategories = [ "Attic Remediation","Insulation Remediation","Back Exterior Remediation","Exterior Remediation","Deck Remediation","Exterior Electrical Remediation","Exterior Remediation","Exterior Door Remediation","Back Exterior Upgrade","Exterior Upgrade","Deck Upgrade","Exterior Electrical Upgrade","Baseline Remediation","Bath Remediation","Interior Door Remediation","Door Remediation","Cabinet Remediation","Interior Electrical Remediation","Bathroom Remediation","Window Remediation","Flooring Remediation","Interior Remediation","Interior Light Remediation","Room HVAC Remediation","Bath Remediation","Interior Door Remediation","Door Remediation","Cabinet Remediation","Interior Electrical Remediation","Bathroom Remediation","Window Remediation","Interior Remediation","Interior Light Remediation","Flooring Remediation","Room HVAC Remediation","Bath Upgrade","Interior Door Upgrade","Door Upgrade","Cabinet Upgrade","Interior Electrical Upgrade","Bathroom Upgrade","Window Upgrade","Room HVAC Upgrade","Cabinet Remediation","Washer Remediation","Interior Door Remediation","Door Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Interior Light Remediation","Window Remediation","Other remediation","plumbing remediation","Cabinet Upgrade","Washer Upgrade","Interior Door Upgrade","Door Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Interior Light Upgrade","Window Upgrade","Electrical Remediation","Interior Electrical Remediation","Exterior Electrical Remediation","Exterior Door Remediation","Interior Door Remediation","Door Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Fireplace Remediation","Interior Light Remediation","Fan Remediation","Window Remediation","Sliding Glass Door Remediation","Other remediation","Exterior Door Remediation","Interior Door Remediation","Door Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Interior Light Remediation","Fan Remediation","Window Remediation","Exterior Door Remediation","Interior Door Remediation","Door Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Interior Light Remediation","Window Remediation","Other remediation","Exterior Door Remediation","Interior Door Remediation","Door Remediation","Interior Electrical Remediation","Garage Remediation","Flooring Remediation","Interior Remediation","Interior Remediation","Masonry Remediation","Interior Light Remediation","Window Remediation","","Exterior Door Remediation","Interior Door Remediation","Door Remediation","Sliding Glass Door Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Fireplace Remediation","Interior Light Remediation","Fan Remediation","Window Remediation","Other remediation","Exterior Door Remediation","Interior Door Remediation","Door Remediation","Sliding Glass Door Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Interior Light Remediation","Window Remediation","Other remediation","Exterior Door Remediation","Sliding Glass Door Remediation","Interior Door Remediation","Door Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Insulation Remediation","Masonry Remediation","Interior Light Remediation","Structural Remediation","Window Remediation","Plumbing Remediation","Exterior Door Upgrade","Interior Door Upgrade","Door Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Fireplace Upgrade","Interior Light Upgrade","Fan Upgrade","Window Upgrade","Sliding Glass Door Upgrade","Exterior Door Upgrade","Interior Door Upgrade","Door Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Interior Light Upgrade","Fan Upgrade","Window Upgrade","Exterior Door Upgrade","Interior Door Upgrade","Door Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Interior Light Upgrade","Window Upgrade","Exterior Door Upgrade","Interior Door Upgrade","Door Upgrade","Interior Electrical Upgrade","Garage Upgrade","Flooring Upgrade","Interior Upgrade","Interior Upgrade","Masonry Upgrade","Interior Light Upgrade","Window Upgrade","Exterior Door Upgrade","Interior Door Upgrade","Door Upgrade","Sliding Glass Door Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Fireplace Upgrade","Interior Light Upgrade","Fan Upgrade","Window Upgrade","Exterior Door Upgrade","Interior Door Upgrade","Door Upgrade","Sliding Glass Door Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Interior Light Upgrade","Window Upgrade","Exterior Door Upgrade","Sliding Glass Door Upgrade","Interior Door Upgrade","Door Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Insulation Upgrade","Masonry Upgrade","Interior Light Upgrade","Structural Upgrade","Window Upgrade","Exterior Remediation","Exterior Electrical Remediation","Exterior Door Remediation","Exterior Remediation","Exterior Electrical Remediation","Exterior Remediation","Exterior Door Remediation","Exterior Upgrade","Exterior Electrical Upgrade","Exterior Upgrade","Exterior Electrical Upgrade","Exterior Upgrade","Front Exterior Remediation","Exterior Remediation","Deck Remediation","Exterior Electrical Remediation","Exterior Remediation","Exterior Door Remediation","Front Exterior Upgrade","Exterior Upgrade","Deck Upgrade","Exterior Electrical Upgrade","General Remediation","HVAC Remediation","Insulation Remediation","Masonry Remediation","Structural Remediation","Crawlspace Remediation","Exterior Remediation","Kitchen Appliance Remediation","Appliance Remediation","Bath Remediation","Exterior Door Remediation","Sliding Glass Door Remediation","Interior Door Remediation","Door Remediation","Cabinet Remediation","Interior Electrical Remediation","Electrical Remediation","Exterior Electrical Remediation","General Remediation","Exterior Remediation","Back Exterior Remeidaitons","Front Exterior Remediation","Back Exterior Remediation","Garage Remediation","Deck Remediation","Flooring Remediation","Stair Remediation","Room HVAC Remediation","HVAC Remediation","Interior Remediation","Other remediation","Fireplace Remediation","Insulation Remediation","Masonry Remediation","Attic Remediation","Kitchen Remediation","Interior Light Remediation","Fan Remediation","Bathroom Remediation","Water Heater Remediation","Washer Remediation","Plumbing Remediation","","Roof Remediation","Structural Remediation","Window Remediation","Kitchen Appliance Remediation","Appliance Remediation","Exterior Door Remediation","Interior Door Remediation","Door Remediation","Sliding Glass Door Remediation","Cabinet Remediation","Interior Electrical Remediation","Flooring Remediation","Room HVAC Remediation","Interior Remediation","Cabinet Remediation","Kitchen Remediation","Interior Light Remediation","Washer Remediation","Window Remediation","Exterior Door Remediation","Other remediation","plumbing remediation","Bathroom Remediation","Kitchen Appliance Upgrade","Appliance Upgrade","Bath Upgrade","Exterior Door Upgrade","Sliding Glass Door Upgrade","Interior Door Upgrade","Door Upgrade","Cabinet Upgrade","Interior Electrical Upgrade","Exterior Electrical Upgrade","General Upgrade","Exterior Upgrade","Back Exterior Remeidaiton","Front Exterior Upgrade","Back Exterior Upgrade","Garage Upgrade","Deck Upgrade","Flooring Upgrade","Stair Upgrade","Room HVAC Upgrade","Interior Upgrade","Other Upgrade","Fireplace Upgrade","Insulation Upgrade","Masonry Upgrade","Attic Upgrade","Kitchen Upgrade","Interior Light Upgrade","Fan Upgrade","Bathroom Upgrade","Window Upgrade","Kitchen Appliance Upgrade","Appliance Upgrade","Exterior Door Upgrade","Interior Door Upgrade","Door Upgrade","Sliding Glass Door Upgrade","Cabinet Upgrade","Interior Electrical Upgrade","Flooring Upgrade","Room HVAC Upgrade","Interior Upgrade","Cabinet Upgrade","Kitchen Upgrade","Interior Light Upgrade","Washer Upgrade","Window Upgrade","Exterior Door Upgrade","Plumbing Remediation","Pool Remediations","Roof Remediation","Stairway Remediation","Interior Remediation","Interior Light Remediation","Window Remediation","Other remediation","Stair Remediation","Stairway Upgrade","Interior Upgrade","Interior Light Upgrade","Window Upgrade","Water Heater Remediation","Plumbing Remediation","Appliances","Carpet","Cleaning","Counter","Counters","Doors","Drywall","Electric","Exterior","Flooring","HVAC","Hardware","Improvement","Improvements","Interior","Land","Landscaping","Light","Lock","Other","Permits","Plumbing","Repair","Roofing","Rubbish","Water" ]


Header = ["name","key","unit","unit_cost","unit_labor_cost","unit_material_cost","can_set_cost","can_set_quantity","default_quantity","description","category","market","tags"]


def RandomString(Length=10):
    RandBytes = bytearray(Length)
    for x in range(Length):
        RandBytes[x] = random.randrange(65,91)
    return(KeyName(RandBytes.decode()))
    
def KeyName(InputString):
    return(InputString.replace(" ", "_").lower());
    
    
def MakeServicesCSV():

    Categories= set(AllCategories)
    
    InputCSVData = []
    OutputCSVData = []
    CSVInputFileName = 'c:\sitecapture\Templates\conrexservices.csv'
    CSVOutputFileName = 'services.csv'
    
    Name = ''
    Key = ''
    Unit = ''
    UnitCost = ''
    UnitLaborCost = ''
    UnitMaterialCost = ''
    CanSetCost = ''
    CanSetQuantity = ''
    DefaultQuantity = ''
    Description = ''
    Category = ''
    Market = ''
    Tags = ''
    
    
    for Market in Markets:

        print(Market)
        
        with open(CSVInputFileName, newline='', encoding="utf-8") as CSVInputFile:
    
            CSVReader = csv.reader(CSVInputFile, strict=True, delimiter=',', doublequote=False, quoting=csv.QUOTE_ALL)
            
            if Market == '':
                CSVOutputFileName = 'services-Default.csv'
            else:
                CSVOutputFileName = 'services-' + Market + '.csv'
            
            print("Writing to file: " + CSVOutputFileName)            
            with open(CSVOutputFileName, newline='', mode='w+', encoding="utf-8") as CSVOutputFile:

                CSVWriter = csv.writer(CSVOutputFile, strict=True, delimiter=',', doublequote=False, quoting=csv.QUOTE_ALL, escapechar='\\')
                CSVWriter.writerow(Header)
                
                for row in CSVReader:
                
                    if (CSVReader.line_num == 1):
                        continue
                    
                    if (CSVReader.line_num > 10):
                        break
            
                    Counter = 0
                    CSVOutputFileName = ''
                    CSVOutputFile = None
                                            
                    for Category in Categories:
                    
                        #print("Category: " + Category)
                        if (Category == ''):
                            #print("Skipping empty category")
                            continue

                        Name                = row[0]
                        Key                 = row[1]
                        Unit                = row[2]
                        UnitCost            = row[3]
                        UnitLaborCost       = row[4]
                        UnitMaterialCost    = row[5]
                        CanSetCost          = row[6]
                        CanSetQuantity      = row[7]
                        DefaultQuantity     = row[8]
                        Description         = row[9]
                        # Category            = row[10]
                        # Market              = row[11]
                        Tags                = row[12]
                        
                        if Unit == '':
                            Unit = 'unit'
                        
                        if UnitCost == '':
                            UnitCost = '100.00'
                        if UnitCost == '0.00':
                            UnitCost = '100.00'
                            
                        if UnitLaborCost == '':
                            UnitLaborCost = '125.00'
                        if UnitLaborCost == '0.00':
                            UnitLaborCost = '125.00'
                            
                        if UnitMaterialCost == '':
                            UnitMaterialCost = '150.00'
                        if UnitMaterialCost == '0.00':
                            UnitMaterialCost = '150.00'

                        if (Counter == 0):
                            CanSetCost = 'true'
                            CanSetQuantity = 'true'
                        if (Counter == 1):
                            CanSetCost = 'true'
                            CanSetQuantity = 'false'
                        if (Counter == 2):
                            CanSetCost = 'false'
                            CanSetQuantity = 'true'
                        if (Counter == 3):
                            CanSetCost = 'false'
                            CanSetQuantity = 'false'
                        
                        if (DefaultQuantity == ''):
                            DefaultQuantity = '1'                            
                        if (DefaultQuantity == '0'):
                            DefaultQuantity = '1'                            

                            
                        Key = KeyName(Name) + '_' + RandomString(10)                        
                        Name = Name + ' (SetCost=' + CanSetCost + ',SetQty=' + CanSetQuantity + ')'

                        if (Description == ''):
                            Description = "Default Description"

                        outputrow = []
                        outputrow.append(Name)
                        outputrow.append(Key)
                        outputrow.append(Unit)
                        outputrow.append(UnitCost)
                        outputrow.append(UnitLaborCost)
                        outputrow.append(UnitMaterialCost)
                        outputrow.append(CanSetCost)
                        outputrow.append(CanSetQuantity)
                        outputrow.append(DefaultQuantity)
                        outputrow.append(Description)
                        outputrow.append(Category)
                        outputrow.append(Market)
                        outputrow.append(Tags)
                        
                        #print(str(outputrow))
                        # print(Name)
                        
                        CSVWriter.writerow(outputrow)
                        
                        if (Counter == 3):
                            Counter = 0
                        else:
                            Counter += 1


#

print("Hello world")
MakeServicesCSV()


