
globalThis.GlobalSeenData   = new Map();
globalThis.GlobalTestMap    = new Map();
globalThis.GlobalTestSet    = new Set();
globalThis.GlobalCounter    = 0;

globalThis.TestClass1 = class {
    constructor( Variable ) {
    this.MyVariable = Variable; } 
};

class TestClass2 {
    constructor( Variable ) 
    {
        this.MyVariable = Variable; 
    }
    
    TestFunction()
    {
        let ABC = typeof(this);
        console.log(ABC);
        return(ABC);
    }
    
};

globalThis.TestObject1 = new globalThis.TestClass1( 1 );
globalThis.TestObject2 = new globalThis.TestClass1( 2 );
globalThis.TestObject3 = new globalThis.TestClass1( 3 );
globalThis.TestObject4 = new globalThis.TestClass1( 4 );


globalThis.TestArray = [ globalThis.TestObject1, globalThis.TestObject2, globalThis.TestObject3, globalThis.TestObject4, globalThis.TestObject5 ];

globalThis.TestFunction = function() {}


globalThis.GetObjectInfo = function( InputObject ) {

    try {
   
        Result = JSON.stringify( InputObject );
        return( Result );
    }
    catch( Bad ) { 
        return( {} );
    }
    

};


globalThis.CallProtoProperty = function( InputObject ) {
    return( InputObject.__proto__ );
};

globalThis.CallGetProtoTypeOf = function( InputObject ) {
    return( Object.getPrototypeOf( InputObject) );
};

globalThis.CallJSONStringify = function( InputObject ) {
    return( JSON.stringify( InputObject ) );
};


globalThis.GetGlobalSeenData = function() {

    DataList      = [];
    DataIterator  = globalThis.GlobalSeenData.entries();
    
    while ( !(Item = DataIterator.next()).done ) {
    
        ProtoTypeObject  = Item.value[0];
        InstanceList     = Item.value[1];
        
        DataItem = { 'ProtoTypeObject' : ProtoTypeObject,
                     'InstanceObjects' : InstanceList };
        
        DataList.push( DataItem );
    }
    
    return( DataList );
        

};

globalThis.GetGlobalTestMap = function() {

    DataList      = [];
    DataIterator  = globalThis.GlobalTestMap.entries();
    
    while (!(Item = DataIterator.next()).done) {
        DataList.push( Item.value[0] );
    }
    
    return( DataList );
        

};

globalThis.IsSameObject = function( Object1, Object2 ) {
    return( Object1 === Object2 );
};

globalThis.AddToGlobalTestSet = function( MyObject ) {
    globalThis.GlobalTestSet.add( MyObject );
    return(globalThis.GlobalTestSet.has( MyObject ));
};

globalThis.GlobalTestSetHas = function( MyObject ) {
    return(globalThis.GlobalTestSet.has( MyObject ));
};

globalThis.GetGlobalTestSet = function( MyObject ) {
    return( Array.from( globalThis.GlobalTestSet ) );
};

globalThis.GlobalTestMapHas = function( MyObject ) {    
    return ( globalThis.GlobalTestMap.has( MyObject ));
};    

globalThis.AddToGlobalTestMap = function( MyObject ) {

    if ( MyObject === globalThis.GlobalTestMap )
    {
        return(false);
    }

    if (!( globalThis.GlobalTestMap.has( MyObject )))
    {
        if (!(Object.hasOwn(MyObject, '__UniqueID__'))) {
        
            if ( Object.isExtensible( MyObject )) {
            
                Result = Reflect.defineProperty( MyObject, '__UniqueID__', 
                        {   writable: false,
                            enumerable: false,
                            configurable: false,
                            value: globalThis.GlobalCounter });
            }
            
            globalThis.GlobalTestMap.set( MyObject, MyObject.__UniqueID__ );
            globalThis.GlobalCounter++;
        }
        else {
        
            if (!( Object.isExtensible( MyObject ))) {
                globalThis.GlobalTestMap.set( MyObject, globalThis.GlobalCounter );
                globalThis.GlobalCounter++;
            }
        }
    }
    
    return( globalThis.GlobalTestMap.has( MyObject ));
};



globalThis.IsSeenProtoType = function( ProtoTypeObject ) {
    return ( globalThis.GlobalSeenData.has( ProtoTypeObject ));
};    

globalThis.AddSeenProtoType = function( ProtoTypeObject ) {
    globalThis.GlobalSeenData.set( ProtoTypeObject, [] );
    return( globalThis.GlobalSeenData.has( ProtoTypeObject ));
};


globalThis.IsSeenInstance = function( ProtoTypeObject, InstanceObject ) {
    InstanceList = globalThis.GlobalSeenData.get( ProtoTypeObject );
    return( InstanceList.includes( InstanceObject ));
};


globalThis.AddSeenInstance = function( ProtoTypeObject, InstanceObject ) {
    InstanceList = globalThis.GlobalSeenData.get( ProtoTypeObject );
    InstanceList.push( InstanceObject );
    return( InstanceList.includes( InstanceObject ));
};


globalThis.GlobalEventListener = function( TheEvent ) {
    console.log( TheEvent );
    return(true);
};


globalThis.AddListenerToAllEvents = function()
{
    Targets = [ window, document ];
    EventTypesAdded = [];
    
    for ( Target of Targets ) {
    
        for ( Key in Target ) {
        
            if ( /^on/.test( Key ) ) {
            
                EventType = Key.substr( 2 );
                
                Target.addEventListener( EventType, 
                                         globalThis.GlobalEventListener, 
                                         false );
                
                EventTypesAdded.push( EventType );
            }
        }
    }
    
    return( EventTypesAdded );
};


// globalThis.EventTypesAdded = globalThis.AddListenerToAllEvents();



