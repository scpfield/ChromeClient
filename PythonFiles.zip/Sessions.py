import sys, io, json, random, time, copy, requests
from abc import *
from Util import *
from WebDrivers import *

_W3C_CAPABILITY_NAMES = frozenset(
    [
        "acceptInsecureCerts",
        "browserName",
        "browserVersion",
        "pageLoadStrategy",
        "platformName",
        "proxy",
        "setWindowRect",
        "strictFileInteractability",
        "timeouts",
        "unhandledPromptBehavior",
        "webSocketUrl",
    ] )

V = 'value'

class Session(ABC):

    @abstractmethod
    def __init__( self, Driver ):
        self.Driver = Driver
        self.CapabilityParameters = {}
        self.Capabilities = {}
        self.Capabilities['capabilities'] = {}
        self.Capabilities['capabilities']['alwaysMatch'] = self.CapabilityParameters
    ...
    
    @abstractmethod
    def New( self ):
    
        if not self.Driver.Ready:
            return False
            
        Path           =  f'/session'
        URL            =  f'{self.Driver.BaseURL}{Path}'
        JSONRequest    =  self.Capabilities
        JSONResponse   =  {}
        DriverResponse =  {}
        HTTPResponse   =  self.Driver.HTTPSession.post(
                           url  = URL, 
                           json = JSONRequest )

        try:
            JSONResponse = HTTPResponse.json()
        except Exception as e:
            ...
        
        if not HTTPResponse.ok:
            ResponseInfo( HTTPResponse )
            return False

        if 'value' in JSONResponse:
            if JSONResponse['value']:
                DriverResponse = JSONResponse['value']
        
        if 'capabilities' in DriverResponse:
            if DriverResponse['capabilities']:
                self.Capabilities = copy.deepcopy(
                                    DriverResponse['capabilities'])
    
        self.Id = None
        
        if 'sessionId' in DriverResponse:
            if DriverResponse['sessionId']:
                self.Id = copy.copy(
                          DriverResponse['sessionId'])
        
        return self.Id if self.Id else False
    ...

    @abstractmethod
    def Delete( self ):
    
        if not self.Id: return False
        
        Path           =  f'/session/{self.Id}'
        URL            =  f'{self.Driver.BaseURL}{Path}'
        JSONResponse   =  {}
        DriverResponse =  {}
        HTTPResponse   =  self.Driver.HTTPSession.delete(
                           url = URL )

        try:
            JSONResponse = HTTPResponse.json()
        except Exception as e:
            ...
        
        if not HTTPResponse.ok:
            ResponseInfo(HTTPResponse)
            return False

        if 'value' in JSONResponse:
            if JSONResponse['value']:
                DriverResponse = JSONResponse['value']
        
        if not DriverResponse:
            self.Id = None
            
        return True
    ...

    @abstractmethod
    def NavigateTo( self, AppURL ):
    
        if not self.Id: return False
        
        Path           =  f'/session/{self.Id}/url'
        URL            =  f'{self.Driver.BaseURL}{Path}'
        JSONRequest    =  { 'url' : AppURL }
        JSONResponse   =  {}
        DriverResponse =  {}
        HTTPResponse   =  self.Driver.HTTPSession.post(
                           url  = URL, 
                           json = JSONRequest )

        try:
            JSONResponse = HTTPResponse.json()
        except Exception as e:
            ...
        
        if not HTTPResponse.ok:
            ResponseInfo( HTTPResponse )
            return False

        if 'value' in JSONResponse:
            if JSONResponse['value']:
                DriverResponse = JSONResponse['value']
                
        if not DriverResponse:
            if self.GetCurrentURL() == AppURL:
                return True
    ...
    
    @abstractmethod
    def GetCurrentURL( self ):
    
        if not self.Id: return False
        
        Path           =  f'/session/{self.Id}/url'
        URL            =  f'{self.Driver.BaseURL}{Path}'
        JSONResponse   =  {}
        DriverResponse =  {}
        HTTPResponse   =  self.Driver.HTTPSession.get(
                           url = URL )

        try:
            JSONResponse = HTTPResponse.json()
        except Exception as e:
            ...
        
        if not HTTPResponse.ok:
            ResponseInfo(HTTPResponse)
            return False

        if 'value' in JSONResponse:
            if JSONResponse['value']:
                DriverResponse = JSONResponse['value']
        
        return str(DriverResponse) if DriverResponse else False
        
    ...

...

class ChromeSession(Session):

    def __init__( self, Driver ):
        super().__init__(Driver)
        
        self.CapabilityParameters['acceptInsecureCerts'] = True
        self.CapabilityParameters['unhandledPromptBehavior'] = 'dismiss'
        self.CapabilityParameters['pageLoadStrategy'] = 'normal'
        
    ...

    def New( self ):
        return( super().New() )
    ...
    
    def Delete( self ):
        return( super().Delete() )
    ...
    
    def NavigateTo( self, AppURL ):
        return( super().NavigateTo( AppURL ))
    ...
    
    def GetCurrentURL( self ):
        return( super().GetCurrentURL() )
    
...


class AndroidSession(Session):

    # adb.exe -P 5037 -s emulator-5554 forward tcp:8200 tcp:6790
    # adb.exe -P 5037 -s emulator-5554 shell am force-stop io.appium.uiautomator2.server.test
    # adb -P 5037 -s emulator-5554 shell am instrument -w -e DISABLE_SUPPRESS_ACCESSIBILITY_SERVICES false -e disableAnalytics true io.appium.uiautomator2.server.test/androidx.test.runner.AndroidJUnitRunner
    # adb -P 5037 -s emulator-5554 shell am start -W -n com.android.settings/com.android.settings.Settings -S
    # adb root
    # adb shell -t uiautomator dump --verbose /dev/tty
    
    def __init__( self, Driver ):
        super().__init__(Driver)
        #self.CapabilityParameters['acceptInsecureCerts'] = True
        #self.CapabilityParameters['unhandledPromptBehavior'] = 'dismiss'
        #self.CapabilityParameters['pageLoadStrategy'] = 'normal'
    ...

    def New( self ):
        return( super().New() )
    ...
    
    def Delete( self ):
        return( super().Delete() )
    ...
    
    def NavigateTo( self, AppURL ):
        return( super().NavigateTo( AppURL ))
    ...
    
    def GetCurrentURL( self ):
        return( super().GetCurrentURL() )
    
...
