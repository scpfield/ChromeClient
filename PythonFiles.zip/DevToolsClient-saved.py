import sys, os, time, subprocess, websocket, requests, signal, functools, threading, cdp, re, keyboard
from util import *



GlobalCloseChrome   = None
BrowserClient       = None
PageClient          = None

class ClientInitException(Exception):
    ...

class ChromeLauncher():

    HostName        = 'localhost'
    DebugPort       = 9222
    ExecCommand     = [ f'chrome.exe',
                        f'--high-dpi-support=1',
                        f'--force-device-scale-factor=1.5',
                        f'--remote-debugging-port={DebugPort}',
                        f'--remote-allow-origins=*']
                        #f'--enable-logging=stderr',
                        #f'--v=1']
    
    ChromeProcess       = None
    TabTargetInfo       = None
    BrowserTargetInfo   = None
    
    
    def __init__( self ):

        ChromeLauncher.ChromeProcess = self.LaunchChrome()
        if not ChromeLauncher.ChromeProcess:
            raise ClientInitException
            
        ChromeLauncher.TargetInfo        = self.GetTabTarget()
        ChromeLauncher.BrowserTargetInfo = self.GetBrowserTarget()
        
    def __del__( self ):
        if ChromeLauncher.ChromeProcess:
            ChromeLauncher.ChromeProcess.terminate()
            
    def LaunchChrome( self ):
        try:
            return subprocess.Popen( 
                ' '.join( ChromeLauncher.ExecCommand ))
        except BaseException as e:
            print('Got exception launching Chrome')
            return None
        ...

    def GetTabTarget( self, TabIdx = 0 ):
        ChromeURL   = ( f'http://{ChromeLauncher.HostName}' + 
                        f':{ChromeLauncher.DebugPort}/json' )
                        
        print('GetTabTarget: Making HTTP Request to: ' + ChromeURL)                        
        
        Response    =  requests.get( url = ChromeURL )
        JSONData    =  None
        try:
            if not Response.ok:
                print( f'Got bad response code: {Response.code}')
                return None
            JSONData  = Response.json()
            if TabIdx > (len(JSONData)-1):
                print('Requested TargetIdx > len(JSONData)')
                return None
            else: return JSONData[TabIdx]
        except Exception as e:
            print('Got exception retrieving WebSocketURL')
            return None
        ...
    
    def GetBrowserTarget( self ):
        ChromeURL   = ( f'http://{ChromeLauncher.HostName}' + 
                        f':{ChromeLauncher.DebugPort}/json/version' )
        
        print('GetBrowserTarget: Making HTTP Request to: ' + ChromeURL)
        
        Response    =  requests.get( url = ChromeURL )
        JSONData    =  None
        try:
            if not Response.ok:
                print( f'Got bad response code: {Response.code}')
                return None
            JSONData  = Response.json()
            return JSONData
        except Exception as e:
            print('Got exception retrieving WebSocketURL')
            return None
        ...
      
      
class CDPClientBase( threading.Thread ):

    def __init__( self, Name = None  ):
        super().__init__()
        self.Name               = Name
        self.TargetInfo         = self.GetTargetInfo()
        self.MethodData         = []
        self.EventData          = {}
        self.MethodCondition    = threading.Condition()
        self.EventCondition     = threading.Condition()
        self.Ready              = False      
        
        self.TargetInfo['MessageCounter'] = 0
                
        self.start()
        ...
        
        
    def __del__( self ):
        ...
        #if ChromeLauncher.ChromeProcess and self.is_alive():
        #    self.Execute( cdp.browser.close )


    def run( self ):
    
    
        def OnOpen( WebSocketApp ):
            print(f'OnOpen called')
            self.Ready = True
            
        def OnClose( WebSocketApp, CloseStatus, CloseMessage ):
            print(f'OnClose called')
            print(f'CloseStatus:  {CloseStatus}')
            print(f'CloseMessage: {CloseMessage}')

        def OnError( WebSocketApp, ExceptionObj ):
            print(f'OnError called')
            # GetExceptionInfo(ExceptionObj)
            print(f'Exception: {ExceptionObj.__class__.__name__}')

        def OnPing( WebSocketApp ):
            print(f'OnPing called')

        def OnPong( WebSocketApp, ByteData ):
            print(f'OnPong called')
            print( ByteData.decode('utf-8') )

        def OnData( WebSocketApp, Data, Format, Cont ):
            print(f'OnData called')
            print(f'Data: {Data}')
            JSONMessage = None            
            if Data != None:
                try:
                    JSONMessage = json.loads( Data )
                except BaseException as e:
                    print('Failed to convert to JSON')
                    return
            if JSONMessage:
                ID = Method = Result = Error = None
                ID      = JSONMessage.get('id')
                Method  = JSONMessage.get('method')
                Result  = JSONMessage.get('result')
                Error   = JSONMessage.get('error')
                if ( Result != None ):
                    print('Got Result, notifying listeners')
                    with self.MethodCondition:
                        self.MethodData.append( Result )
                        self.MethodCondition.notify()
                    print('Notified listeners')
                    return
                if ( Error != None ):
                    print('Got Error, notifying listeners')
                    with self.MethodCondition:
                        self.MethodData.append( Error )
                        self.MethodCondition.notify()
                    print('Notified listeners')
                    return
                if ( ID == None ):
                    with self.EventCondition:
                        if Method not in self.EventData:
                            self.EventData[Method] = []
                        self.EventData[Method].append(JSONMessage)
                        self.EventCondition.notify()
                    return
                    
        def OnContMessage( WebSocketApp, Message, Flag ):
            print(f'OnContMessage called')
            #print(f'Message: {Message}')
            #print(f'Flag: {Flag}')   # 0 = continues to next 
            #Pause()

        def OnMessage( WebSocketApp, Message ):
            print(f'OnMessage called')
            print(f'Message: {Message}')

        print('Thread is alive')
        
        try:
        
            self.WebSocketTarget    = None            
            self.WebSocketTarget    = websocket.WebSocketApp(
                url                 = self.TargetInfo.get(
                                      'webSocketDebuggerUrl'),
                on_open             = OnOpen,
                #on_message          = OnMessage,
                on_cont_message     = OnContMessage,
                on_data             = OnData,                
                on_error            = OnError,
                on_close            = OnClose )
            
            print(f'Opened WS-URL: {self.WebSocketTarget.url}')
            self.WebSocketTarget.run_forever()

        except KeyboardInterrupt as ke:
            print('\nException caught')
            self.__del__()
            GetExceptionInfo(ke)
            return False

        except BaseException as be:
            print('\nException caught')
            self.__del__()
            GetExceptionInfo(be)
            return False
    

    def Execute( self, CDPMethod, **kwargs ):
        Verbose = False
        # this returns a generator initialized with the args
        Generator           = CDPMethod( **kwargs )
        # this yelds a dictionary of the call + args
        # note:  send(None) == next(Generator)
        CDPMethodDict       = Generator.send( None )
        # add the ID to it
        CDPMethodDict['id'] = self.TargetInfo.get('MessageCounter')
        # print nice thing
        MethodColor         = Style.BRIGHT + Back.BLUE + Fore.YELLOW
        Reset               = Style.RESET_ALL
        print( f"CDP Command: {MethodColor}{json.dumps(CDPMethodDict)}{Reset}" )
        # send to WebSocket
        self.WebSocketTarget.send( json.dumps( CDPMethodDict ))
        # increment counter
        self.TargetInfo['MessageCounter'] += 1
        # wait for reply
        Reply = None
        with self.MethodCondition:
            self.MethodCondition.wait_for( 
                ( lambda : len(self.MethodData) > 0 ), timeout=2 )
            if len(self.MethodData) > 0:    
                Reply = self.MethodData.pop()
            else:
                print('This should never happen')
        
        # Reply is a regular dict
        # convert Reply to CDP python object
        # by calling the generator again
        # the converted result is in the exception
        
        
        try:
            CDPObject = Generator.send( Reply )
        except StopIteration as si:
            CDPObject = si.value
        except BaseException as be:
            CDPObject = Reply
            
        
        if Verbose:
            TypeColor       = Style.BRIGHT  + Back.RED    + Fore.WHITE
            DefaultColor    = Style.BRIGHT  + Back.BLACK  + Fore.WHITE
            GreenColor      = Style.BRIGHT  + Back.GREEN  + Fore.WHITE
            BlueColor       = Style.BRIGHT  + Back.BLUE   + Fore.WHITE
            Reset           = Back.BLACK    + Style.RESET_ALL
            ValueStr        = json.dumps(Reply)
            ValueSplit      = re.split(',|=|:', ValueStr)
            if len(ValueSplit) > 0:
                ValueSplit  = [ Value.strip() for Value in ValueSplit ]
                Names       = ValueSplit[0::2]
                Values      = ValueSplit[1::2]
                ValueStr    = ''
                for Name, Value in zip(Names, Values):                         
                    if  (( Value != 'None' )  and 
                         ( Value != "''" )    and 
                         ( Value != None )    and 
                         ( Value != 'None)' )):
                            ValueStr += f'{GreenColor}{Name}='
                            ValueStr += f'{GreenColor}{Value}{Reset},'
                    else:
                        ValueStr += f'{DefaultColor}{Name}='
                        ValueStr += f'{DefaultColor}{Value}{Reset},'
                ValueStr  = ValueStr.strip(',')
                ValueStr += Reset
            else:
                ValueStr = GreenColor + json.dumps(Reply) + Reset

            ReplyType = type(CDPObject).__name__
            print(f'CDP Return Type  : {TypeColor}{ReplyType}{Reset}')
            print(f'CDP Return Value : {BlueColor}{CDPObject}{Reset}')

        return CDPObject



class DevToolsBrowserClient( CDPClientBase ):

    def __init__( self, Name = None ):
        global BrowserClient
        super().__init__( Name = None )
        BrowserClient = self
        
    def GetTargetInfo( self ):
        return ChromeLauncher.BrowserTargetInfo

    def CreateNewBrowserContext( self ):
        global GlobalCloseChrome
        
        while not self.Ready:
            print('Waiting for Ready state')
            time.sleep(0.25)
            ...
            
        print('We are now in Ready state')
        
        if not GlobalCloseChrome:
            GlobalCloseChrome = functools.partial( 
                self.Execute, cdp.browser.close )
                    
        print(self.TargetInfo)
        
        print(ChromeLauncher.BrowserTargetInfo)
        print(ChromeLauncher.TabTargetInfo)

        BrowserContexts = self.Execute( cdp.target.get_browser_contexts )
        
        for BrowserContext in BrowserContexts:            
            Result = self.Execute( cdp.target.dispose_browser_context,
                                   browser_context_id = BrowserContext )
        
        self.BrowserContextID = self.Execute(  
                                cdp.target.create_browser_context,
                                dispose_on_detach = True )

        print("Created new browser context: " + self.BrowserContextID )
        self.ChromeLauncher.BrowserContextID = self.BrowserContextID
        
        
        self.BrowserSessionID = self.Execute(
                                cdp.target.attach_to_browser_target )
        self.ChromeLauncher.BrowserSessionID = self.BrowserSessionID
        print("Attached to new browser context")

        self.PageTargetID =   self.Execute( cdp.target.create_target,
                                 url = "",
                                 browser_context_id = self.BrowserContextID,
                                 enable_begin_frame_control = True )
        self.ChromeLauncher.PageTargetID = self.PageTargetID
        print('Created new target')

        self.PageSessionID = self.Execute( cdp.target.attach_to_target, 
                          target_id = self.PageTargetID,
                          flatten = True )
        self.ChromeLauncher.PageSessionID = self.PageSessionID                          

        self.Execute(  cdp.target.set_auto_attach, 
                        auto_attach = True, 
                        flatten = True,
                        wait_for_debugger_on_start = True )
        
        Result = self.Execute( cdp.target.auto_attach_related,
                            target_id = self.PageTargetID,
                            wait_for_debugger_on_start = True )

              
        ChromeLauncher.BrowserTargetInfo = (
            self.ChromeLauncher.GetBrowserTarget())
        ChromeLauncher.TabTargetInfo = (
            self.ChromeLauncher.GetTabTarget())            
        self.TargetInfo  = self.GetTargetInfo()
        self.TargetInfo['MessageCounter'] = 0
        print("Refreshed Browser TargetInfo: " + str(self.TargetInfo) )
        
        print(ChromeLauncher.BrowserTargetInfo)
        print(ChromeLauncher.TabTargetInfo)

class DevToolsPageClient( CDPClientBase ):

    def __init__( self, Name = None ):
        global PageClient
        super().__init__( Name = None )
        PageClient = self
        
    def GetTargetInfo( self ):
        return ChromeLauncher.TabTargetInfo

    def Test( self ):

        while not self.Ready:
            print('Waiting for Ready state')
            time.sleep(0.25)
            ...
                    
        print('We are now in Ready state')
        
        '''
        ChromeLauncher.TabTargetInfo = (
            self.ChromeLauncher.GetTabTarget())            
        self.TargetInfo  = self.GetTargetInfo()
        self.TargetInfo['MessageCounter'] = 0
        print("Refreshed Browser TargetInfo: " + str(self.TargetInfo) )
        
        print(TargetID)
        print(self.TargetInfo)
        '''
        
        
        #self.Execute( cdp.target.attach_to_target, 
        #             target_id = TargetId(self.TargetInfo.get('id')),
        #             flatten = True)

        self.Execute( cdp.dom.enable )
        self.Execute( cdp.dom_snapshot.enable )
        self.Execute( cdp.debugger.enable )
        self.Execute( cdp.page.enable ) 
        #self.Execute( cdp.runtime.enable )
        #self.Execute( cdp.network.enable )
        #self.Execute( cdp.fetch.enable )
        #self.Execute( cdp.accessibility.enable )
        #self.Execute( cdp.audits.enable )
        #self.Execute( cdp.css.enable )
        #self.Execute( cdp.inspector.enable )
        #self.Execute( cdp.overlay.enable )
        #self.Execute( cdp.performance.enable )
        #self.Execute( cdp.service_worker.enable )
        #self.Execute( cdp.layer_tree.enable )
        self.Execute( cdp.log.enable )

        
        
        URL = 'https://localhost:8834/#/'
        self.Execute( cdp.page.navigate, url = URL )
        
        Pause()
        
        
        self.Execute( cdp.runtime.enable )
        Result = self.Execute( cdp.runtime.set_custom_object_formatter_enabled,
                                enabled = True)
                                
        #Script = "return new XMLSerializer().serializeToString(document);"
        #Script = 'this.location'
        
        Script = 'this.document'  # this gives all the event listeners
        
        
        Result = self.Execute( cdp.runtime.evaluate,
                               expression = Script,
                               include_command_line_api = True,
                               silent = False,
                               return_by_value = True,
                               user_gesture = True,
                               await_promise = True,
                               throw_on_side_effect = False,
                               timeout = cdp.runtime.TimeDelta(60000),
                               disable_breaks = True,
                               generate_web_driver_value = False,
                               repl_mode = True,
                               allow_unsafe_eval_blocked_by_csp = True)
                               # generate_web_driver_value,
                               
        
        print(type(Result))
        print(Result)
        
        Pause()
        
        #print('Installing key hook')
        #keyboard.on_press_key('S', self.RunDOMSnapshot, suppress=False)
        
        
        while True:
            if self.is_alive():
                print('Joining for 1 seconds')
                self.join(1)
            else:  
                break
            
        print('Exiting')
   
    def RunDOMSnapshot(self, Event):
        
        print('DOMSnapshot called')
        
        DocumentSnapshot, Strings  = self.Execute( cdp.dom_snapshot.capture_snapshot,
                                        computed_styles = [],
                                        include_dom_rects = True )

        print()
        print("capture_snapshot, documentsnapshot:")
        print()
        print(type(DocumentSnapshot), Decorate=False)
        print(DocumentSnapshot, Decorate=False)
        print()
        print()
        print(type(Strings), Decorate=False)
        print(Strings, Decorate=False)
        print()
        print()
        
        
        Nodes, Layouts, Styles = self.Execute( cdp.dom_snapshot.get_snapshot,
                                            computed_style_whitelist = [],
                                            include_event_listeners = True )
      

def OSSignalHandler( Signal, Frame ):
    try:
        print( f'Caught Signal: {signal.strsignal(Signal)}')
        if ChromeLauncher.ChromeProcess and GlobalCloseChrome:
            GlobalCloseChrome()
        else:
            ChromeLauncher.ChromeProcess.terminate()
            
        quit()
    except BaseException as be:
        sys.exit(0)
    ...
    

signal.signal( signal.SIGINT,   OSSignalHandler )
signal.signal( signal.SIGBREAK, OSSignalHandler )
signal.signal( signal.SIGABRT,  OSSignalHandler )    
    
    
if __name__ == '__main__':

   # websocket.enableTrace(True)
    

    
    CDPBrowserClient    = None
    CDPPageClient       = None
        
    try:

        MyChromeLauncher    = ChromeLauncher()
        CDPBrowserClient    = DevToolsBrowserClient(Name = "CDPBrowserClient")
        
        CDPBrowserClient.ChromeLauncher = MyChromeLauncher
        CDPBrowserClient.CreateNewBrowserContext()
        
        print('Creating CDPPageClient')
        
        CDPPageClient       = DevToolsPageClient(Name = "CDPPageClient")
        CDPPageClient.ChromeLauncher = MyChromeLauncher
        CDPPageClient.Test()
        
        
    except SystemExit as se:
        ...
    except BaseException as be:
        GetExceptionInfo(be)
        signal.raise_signal(signal.SIGINT)
    

        
