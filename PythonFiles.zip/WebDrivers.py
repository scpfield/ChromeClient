import sys, io, json, random, time, requests
from abc import *
from Util import *
from Sessions import *

class DriverInitFailException(Exception):
    ...

class WebDriver(ABC):

    @abstractmethod
    def __init__( self, Server = 'localhost', Port = None ):
        self.Server         = Server
        self.Protocol       = 'http'
        self.Port           = Port
        self.BaseURL        = f'{self.Protocol}://{self.Server}:{self.Port}'
        self.HTTPSession    = requests.Session()
        self.Session        = None
        self.Ready          = False
        self.Message        = None
    ...
    
    @abstractmethod
    def Status(self):
    
        Path     =  f'/status'
        Response =  self.HTTPSession.get( url = f'{self.BaseURL}{Path}' )
        TextData =  Response.text
        JSONData =  None
        
        try:
            JSONData = Response.json()
        except Exception as e:
            ...

        if not Response.ok:
            ResponseInfo(Response)
            return False
        
        if JSONData:
            self.Message    = JSONData['value']['message']
            self.Ready      = JSONData['value']['ready']
        else:
            self.Message    = None
            self.Ready      = False
            
        return JSONData if JSONData else False
    ...
...


class ChromeDriver(WebDriver):

    def __init__( self, Server = 'localhost', Port = 5000 ):
    
        super().__init__( Server, Port )
        
        if not self.Status():
            raise DriverInitFailException
            
        self.Session = ChromeSession( self )
        
    ...
    
    def Status(self):
    
        Result = super().Status()
        
        if Result:
            self.Build      = Result['value']['build']['version']
            self.OSArch     = Result['value']['os']['arch']
            self.OSName     = Result['value']['os']['name']
            self.OSVersion  = Result['value']['os']['version']
            return Result
        else:
            self.Build      = None
            self.OSArch     = None
            self.OSName     = None
            self.OSVersion  = None
            return False
    ...
    
    def PrintStatus(self):
        print()
        print(f'ChromeDriver Status')
        print(f'-------------------')
        print(f'Ready       : {self.Ready}')
        print(f'Build       : {self.Build.split()[0]}')
        print(f'Message     : {self.Message}')
        print(f'OSArch      : {self.OSArch}')
        print(f'OSName      : {self.OSName}')
        print(f'OSVersion   : {self.OSVersion}')
        return True
    ...
...
    
class AndroidDriver(WebDriver):

    def __init__( self, Server = 'localhost', Port = 8200 ):
    
        super().__init__( Server, Port )
        
        if not self.Status():
            raise DriverInitFailException
            
        self.Session = AndroidSession( self )
        
    ...
    
    def Status(self):
        return( super().Status() )
    ...
    
    def PrintStatus(self):
        print()
        print(f'AndroidDriver Status')
        print(f'-------------------')
        print(f'Ready       : {self.Ready}')
        print(f'Message     : {self.Message}')
        return True
    ...
...