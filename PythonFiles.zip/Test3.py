import sys, os
from util import *
https://www.linkedin.com/in/sam-porterfield-483b66/

class Class1:

    def __init__(self):
        print("This is Class1 init!")
        
    def MyInstanceMethod(self):
        print("This is Class1 instance method!")
    
    @classmethod 
    def MyClassMethod(cls):
        print("This is Class1 classmethod!")
        
    
    @staticmethod
    def MyStaticMethod():
        print("This is Class1 staticmethod!")
        

class Class2(Class1):

    def __init__(self):
        super().__init__()
        print("This is Class2 init!")
    
    def MyInstanceMethod(self):
        super().MyInstanceMethod()
        print("This is Class2 instance method!")
    




if __name__ == '__main__':

    print()
    print("This is module main")
    
    MyClass = Class2()
    
    MyClass.MyInstanceMethod()
    Class1.MyClassMethod()
    MyClass.MyStaticMethod()
    
    

